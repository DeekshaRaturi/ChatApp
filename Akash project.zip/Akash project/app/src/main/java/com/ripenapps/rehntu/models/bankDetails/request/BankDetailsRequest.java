package com.ripenapps.rehntu.models.bankDetails.request;

import com.google.gson.annotations.SerializedName;

public class BankDetailsRequest {

    @SerializedName("bank_name")
    private String bank_name;

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getCountrycode() {
        return countrycode;
    }

    public void setCountrycode(String countrycode) {
        this.countrycode = countrycode;
    }

    @SerializedName("ownerName")
    private String ownerName;


    @SerializedName("iban")
    private String iban;

    @SerializedName("countryCode")
    private String countrycode;


}
