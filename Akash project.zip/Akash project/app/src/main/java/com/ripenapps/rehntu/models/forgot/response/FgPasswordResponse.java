package com.ripenapps.rehntu.models.forgot.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class FgPasswordResponse extends BaseResponse{


    @SerializedName("result")
    private FgPasswordResponseResult result;

    public FgPasswordResponseResult getResult() {
        return result;
    }

    public void setResult(FgPasswordResponseResult result) {
        this.result = result;
    }
}
