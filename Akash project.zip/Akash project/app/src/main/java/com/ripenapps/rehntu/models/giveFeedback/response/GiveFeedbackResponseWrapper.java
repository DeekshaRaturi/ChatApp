package com.ripenapps.rehntu.models.giveFeedback.response;

import com.google.gson.annotations.SerializedName;

public class GiveFeedbackResponseWrapper {

    @SerializedName("data")
    private GiveFeedbackResponse response;

    public GiveFeedbackResponse getResponse() {
        return response;
    }

    public void setResponse(GiveFeedbackResponse response) {
        this.response = response;
    }
}
