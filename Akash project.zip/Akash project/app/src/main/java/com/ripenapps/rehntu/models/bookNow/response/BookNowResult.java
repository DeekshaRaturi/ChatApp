package com.ripenapps.rehntu.models.bookNow.response;

import com.google.gson.annotations.SerializedName;

public class BookNowResult {


    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    @SerializedName("_id")
    public String _id;

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @SerializedName("price")
    public Integer price;

    @SerializedName("status")
    public Integer status;



}
