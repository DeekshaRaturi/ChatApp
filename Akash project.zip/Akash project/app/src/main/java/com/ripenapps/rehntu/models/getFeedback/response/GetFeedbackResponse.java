package com.ripenapps.rehntu.models.getFeedback.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class GetFeedbackResponse extends BaseResponse{


    @SerializedName("result")
    private GetFeedbackResult result;


    public GetFeedbackResult getResult() {
        return result;
    }

    public void setResult(GetFeedbackResult result) {
        this.result = result;
    }
}
