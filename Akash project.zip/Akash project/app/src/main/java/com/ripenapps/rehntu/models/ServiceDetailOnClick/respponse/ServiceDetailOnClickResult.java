package com.ripenapps.rehntu.models.ServiceDetailOnClick.respponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ServiceDetailOnClickResult {
    @SerializedName("images")
    ArrayList<String> images= new ArrayList<>();

    public ArrayList<String> getImages() {
        return images;
    }

    public void setImages(ArrayList<String> images) {
        this.images = images;
    }

    @SerializedName("subcategoryId")
    private ArrayList<String> subcategoryIdList=new ArrayList<>();

    @SerializedName("_id")
    private String Uid;

    @SerializedName("rate_type")
    private String rate_type;

    public String getRate_type() {
        return rate_type;
    }

    public void setRate_type(String rate_type) {
        this.rate_type = rate_type;
    }

    @SerializedName("home_service_available")
    private boolean home_service_available=false;



    @SerializedName("user_id")
    private String userId;

    @SerializedName("name")
    private String name;

    @SerializedName("categoryId")
    private String categoryId;

    @SerializedName("securityDeposite")
    private String securityDeposit;

    @SerializedName("ratePerHour")
    private String rateHour;

    @SerializedName("yearPurchase")
    private String yearPurchase;

    @SerializedName("basePrice")
    private String basePrice;

    @SerializedName("subcategoryName")
    private ArrayList<String> subcategoryName =new ArrayList<String>();

    @SerializedName("description")
    private String description;

    @SerializedName("created_at")
    private String createdAt;

    @SerializedName("categoryName")
    private String categoryName;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }



    public ArrayList<String> getSubcategoryName() {
        return subcategoryName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @com.google.gson.annotations.SerializedName("address")
    @Expose
    Address address = new Address();

    public void setSubcategoryName(ArrayList<String> subcategoryName) {
        this.subcategoryName = subcategoryName;
    }

    public String getSecurityDeposit() {
        return securityDeposit;
    }

    public void setSecurityDeposit(String securityDeposit) {
        this.securityDeposit = securityDeposit;
    }

    public String getRateHour() {
        return rateHour;
    }

    public void setRateHour(String rateHour) {
        this.rateHour = rateHour;
    }

    public String getYearPurchase() {
        return yearPurchase;
    }

    public void setYearPurchase(String yearPurchase) {
        this.yearPurchase = yearPurchase;
    }

    public ArrayList<String> getSubcategoryIdList() {
        return subcategoryIdList;
    }

    public void setSubcategoryIdList(ArrayList<String> subcategoryIdList) {
        this.subcategoryIdList = subcategoryIdList;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(String basePrice) {
        this.basePrice = basePrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isHome_service_available() {
        return home_service_available;
    }

    public void setHome_service_available(boolean home_service_available) {
        this.home_service_available = home_service_available;
    }
}
