package com.ripenapps.rehntu.volley;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.ripenapps.rehntu.models.DeleteServiceProduct.request.DeleteServiceProductRequest;
import com.ripenapps.rehntu.models.DeleteServiceProduct.response.DeleteServiceProductResponseWrapper;
import com.ripenapps.rehntu.models.ServiceDetailOnClick.request.ServiceDetailOnClickRequest;
import com.ripenapps.rehntu.models.ServiceDetailOnClick.respponse.ServiceDetailOnClickWrapper;
import com.ripenapps.rehntu.models.VerifieMobile.REQUEST.VerifiesMobileRequest;
import com.ripenapps.rehntu.models.VerifieMobile.RESPONSE.VerifieMobileResponseWrapper;
import com.ripenapps.rehntu.models.acceptDeclineChat.request.AcceptDeclineRequest;
import com.ripenapps.rehntu.models.acceptDeclineChat.response.AcceptDeclineWrapper;
import com.ripenapps.rehntu.models.balanceWithdraw.request.BalanceWithdrawRequest;
import com.ripenapps.rehntu.models.balanceWithdraw.response.BalanceWithdrawResponseWrapper;
import com.ripenapps.rehntu.models.bankDetails.request.BankDetailsRequest;
import com.ripenapps.rehntu.models.bankDetails.response.BankDetailResponseWrapper;
import com.ripenapps.rehntu.models.bookNow.request.BooknowRequest;
import com.ripenapps.rehntu.models.bookNow.response.BookNowWrapper;
import com.ripenapps.rehntu.models.category.request.CategoryRequest;
import com.ripenapps.rehntu.models.category.response.CategoryResponseWrapper;
import com.ripenapps.rehntu.models.changepassword.response.ForgotPassChangeResponseWrapper;
import com.ripenapps.rehntu.models.changepassword.request.ForgotPassChangeReq;
import com.ripenapps.rehntu.models.chat.request.ChatRequest;
import com.ripenapps.rehntu.models.chat.response.GetChatResponseWrapper;
import com.ripenapps.rehntu.models.checkDocVerificationStatus.request.DocVerificationStatusRequest;
import com.ripenapps.rehntu.models.checkDocVerificationStatus.response.DocVerificationStatusResponseWrapper;
import com.ripenapps.rehntu.models.checkRegistration.request.CheckRegistrationReq;
import com.ripenapps.rehntu.models.checkRegistration.response.CheckRegistrationResponseWrapper;
import com.ripenapps.rehntu.models.forgot.request.ForgotRequest;
import com.ripenapps.rehntu.models.forgot.response.FgPasswordResponseWrapper;
import com.ripenapps.rehntu.models.getAllNotification.request.AllNotificationRequest;
import com.ripenapps.rehntu.models.getAllNotification.response.AllNotificationWrapper;
import com.ripenapps.rehntu.models.getFeedback.request.GetFeedbackRequest;
import com.ripenapps.rehntu.models.getFeedback.response.GetFeedbackResponseWrapper;
import com.ripenapps.rehntu.models.giveFeedback.request.GiveFeedbackRequest;
import com.ripenapps.rehntu.models.giveFeedback.response.GiveFeedbackResponseWrapper;
import com.ripenapps.rehntu.models.homeListingDetail.request.HomeListingDetailRequest;
import com.ripenapps.rehntu.models.homeListingDetail.response.HomeListingDetailResponseWrapper;
import com.ripenapps.rehntu.models.login.request.LoginRequest;
import com.ripenapps.rehntu.models.login.response.LoginResponseWrapper;
import com.ripenapps.rehntu.models.map.reguest.MapRequest;
import com.ripenapps.rehntu.models.map.response.MapResponseWrapper;
import com.ripenapps.rehntu.models.notification.request.NotificationRequest;
import com.ripenapps.rehntu.models.notification.response.NotificationWrapper;
import com.ripenapps.rehntu.models.payment.request.Payment;
import com.ripenapps.rehntu.models.payment.response.PaymentWrapperValue;
import com.ripenapps.rehntu.models.paymentSession.request.PaymentRequest;
import com.ripenapps.rehntu.models.paymentSession.response.PaymentResult;
import com.ripenapps.rehntu.models.paymentSession.response.PaymentWrapper;
import com.ripenapps.rehntu.models.product.request.ProductRequest;
import com.ripenapps.rehntu.models.product.respponse.ProductResponseWrapper;
import com.ripenapps.rehntu.models.registration.request.SignUpRequest;
import com.ripenapps.rehntu.models.registration.respponse.SignUpResponseWrapper;
import com.ripenapps.rehntu.models.sendDate.request.SendDateRequest;
import com.ripenapps.rehntu.models.sendDate.response.SendDateWrapper;
import com.ripenapps.rehntu.models.serviceDetail.request.ServiceDetailRequest;
import com.ripenapps.rehntu.models.serviceDetail.response.ServiceDetailResponseWrapper;
import com.ripenapps.rehntu.models.services.request.ServiceRequest;
import com.ripenapps.rehntu.models.services.respponse.ServiceResponseWrapper;
import com.ripenapps.rehntu.models.showBooking.request.ShowBookingRequest;
import com.ripenapps.rehntu.models.showBooking.response.ShowBookingWrapper;
import com.ripenapps.rehntu.models.subcategory.request.SubCategoryRequest;
import com.ripenapps.rehntu.models.subcategory.response.SubCategoryResponseWrapper;
import com.ripenapps.rehntu.models.transaction.request.GetTransactionRequest;
import com.ripenapps.rehntu.models.transaction.response.GetTransactionResponseWrapper;
import com.ripenapps.rehntu.models.walletamount.request.GetWalletRequest;
import com.ripenapps.rehntu.models.walletamount.response.GetWalletWrapper;
import com.ripenapps.rehntu.my_util.CommonUtils;


public class APIUtility {
    public final String TAG = "VOLLEY ";
    private static final String BASE_URL = "http://18.216.101.125:3000/mobile_api/";


    public APIUtility(Context context) {

    }


    public void showDialog(Context context, boolean isDialog) {
        if (isDialog) {
            ProcessDialog.start(context);
        }
    }

    public void dismissDialog(boolean isDialog) {
        if (isDialog) {
            ProcessDialog.dismiss();
        }
    }

    public interface APIResponseListener<T> {
        void onReceiveResponse(T response);

        void onResponseFailed();

        void onStatusFalse(T response);
    }

    public void userLogin(final Context context, final LoginRequest loginRequest, final boolean showDialog, final APIResponseListener<LoginResponseWrapper> listener) {

        showDialog(context, showDialog);

        final GenericRequest<LoginResponseWrapper> request = new GenericRequest<LoginResponseWrapper>(Request.Method.POST, BASE_URL+"login", LoginResponseWrapper.class,
                loginRequest, new Response.Listener<LoginResponseWrapper>() {
            @Override
            public void onResponse(LoginResponseWrapper response) {
                Gson gson=new Gson();


                Log.e("responsecodeLogin"," "+gson.toJson(response));


                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                Log.e("error"," "+error.networkResponse+" "+error.getMessage());
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }

    public void forgetPassword(final Context context, ForgotRequest fgPasswordRequest, final boolean showDialog, final APIResponseListener<FgPasswordResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<FgPasswordResponseWrapper> request = new GenericRequest<FgPasswordResponseWrapper>(Request.Method.POST, BASE_URL+"forgot_password", FgPasswordResponseWrapper.class,
                fgPasswordRequest, new Response.Listener<FgPasswordResponseWrapper>() {
            @Override
            public void onResponse(FgPasswordResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);

    }


    public void checkRegistration(final Context context, CheckRegistrationReq fgPasswordRequest, final boolean showDialog, final APIResponseListener<CheckRegistrationResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<CheckRegistrationResponseWrapper> request = new GenericRequest<CheckRegistrationResponseWrapper>(Request.Method.POST, BASE_URL+"checkRegistartion", CheckRegistrationResponseWrapper.class,
                fgPasswordRequest, new Response.Listener<CheckRegistrationResponseWrapper>() {
            @Override
            public void onResponse(CheckRegistrationResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                    Gson gson=new Gson();


                    Log.e("test"," "+gson.toJson(response));
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);

    }

    public void signUp(final Context context, SignUpRequest fgPasswordRequest, final boolean showDialog, final APIResponseListener<SignUpResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<SignUpResponseWrapper> request = new GenericRequest<SignUpResponseWrapper>(Request.Method.POST, BASE_URL+"register", SignUpResponseWrapper.class,
                fgPasswordRequest, new Response.Listener<SignUpResponseWrapper>() {
            @Override
            public void onResponse(SignUpResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);

    }


    public void verifyNumber(final Context context, VerifiesMobileRequest fgPasswordRequest, final boolean showDialog, final APIResponseListener<VerifieMobileResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<VerifieMobileResponseWrapper> request = new GenericRequest<VerifieMobileResponseWrapper>(Request.Method.POST, BASE_URL+"mobile_verify", VerifieMobileResponseWrapper.class,
                fgPasswordRequest, new Response.Listener<VerifieMobileResponseWrapper>() {
            @Override
            public void onResponse(VerifieMobileResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);

    }


    public void updatePassword(final Context context, ForgotPassChangeReq updatePasswordRequest, final boolean showDialog, final APIResponseListener<ForgotPassChangeResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<ForgotPassChangeResponseWrapper> request = new GenericRequest< ForgotPassChangeResponseWrapper>(Request.Method.POST, BASE_URL+"forgot_pass_change", ForgotPassChangeResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< ForgotPassChangeResponseWrapper>() {
            @Override
            public void onResponse( ForgotPassChangeResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }



    public void docVerification(final Context context, DocVerificationStatusRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<DocVerificationStatusResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<DocVerificationStatusResponseWrapper> request = new GenericRequest< DocVerificationStatusResponseWrapper>(Request.Method.POST, BASE_URL+"current_status", DocVerificationStatusResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< DocVerificationStatusResponseWrapper>() {
            @Override
            public void onResponse( DocVerificationStatusResponseWrapper response) {

                Gson gson=new Gson();
                Log.e("doc",""+gson.toJson(response));

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }

    public void categoryList(final Context context, CategoryRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<CategoryResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<CategoryResponseWrapper> request = new GenericRequest< CategoryResponseWrapper>(Request.Method.POST, BASE_URL+"category", CategoryResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< CategoryResponseWrapper>() {
            @Override
            public void onResponse( CategoryResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }

    public void subCategoryList(final Context context, SubCategoryRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<SubCategoryResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<SubCategoryResponseWrapper> request = new GenericRequest< SubCategoryResponseWrapper>(Request.Method.POST, BASE_URL+"subcategory", SubCategoryResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< SubCategoryResponseWrapper>() {
            @Override
            public void onResponse( SubCategoryResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }


    public void getPinsData(final Context context, final MapRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<MapResponseWrapper> listener) {
        showDialog(context, showDialog);
        final GenericRequest<MapResponseWrapper> request = new GenericRequest<MapResponseWrapper>(Request.Method.POST, BASE_URL+"services_filter_data", MapResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< MapResponseWrapper>() {
            @Override
            public void onResponse( MapResponseWrapper response) {
                Gson gson=new Gson();
                Log.e("alldatavalue","    "+gson.toJson(response));

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                   dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                   dismissDialog(showDialog);

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }


    public void getServicesProduct(final Context context, ServiceRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<ServiceResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<ServiceResponseWrapper> request = new GenericRequest<ServiceResponseWrapper>(Request.Method.POST, BASE_URL+"get_services", ServiceResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< ServiceResponseWrapper>() {
            @Override
            public void onResponse( ServiceResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }



    public void getProduct(final Context context, ProductRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<ProductResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<ProductResponseWrapper> request = new GenericRequest<ProductResponseWrapper>(Request.Method.POST, BASE_URL+"get_services", ProductResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< ProductResponseWrapper>() {
            @Override
            public void onResponse( ProductResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }


    public void getServicesProductDetail(final Context context, ServiceDetailOnClickRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<ServiceDetailOnClickWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<ServiceDetailOnClickWrapper> request = new GenericRequest<ServiceDetailOnClickWrapper>(Request.Method.POST, BASE_URL+"service_details", ServiceDetailOnClickWrapper.class,
                updatePasswordRequest, new Response.Listener< ServiceDetailOnClickWrapper>() {
            @Override
            public void onResponse( ServiceDetailOnClickWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }


    public void updateServicesProductDetail(final Context context, ServiceDetailRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<ServiceDetailResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<ServiceDetailResponseWrapper> request = new GenericRequest<ServiceDetailResponseWrapper>(Request.Method.POST, BASE_URL+"updated_services", ServiceDetailResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< ServiceDetailResponseWrapper>() {
            @Override
            public void onResponse( ServiceDetailResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }



    public void removeServicesProductDetail(final Context context, DeleteServiceProductRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<DeleteServiceProductResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<DeleteServiceProductResponseWrapper> request = new GenericRequest<DeleteServiceProductResponseWrapper>(Request.Method.POST, BASE_URL+"remove_services", DeleteServiceProductResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< DeleteServiceProductResponseWrapper>() {
            @Override
            public void onResponse( DeleteServiceProductResponseWrapper response) {

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }




    public void homeServicesProductListingDetail(final Context context, HomeListingDetailRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<HomeListingDetailResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<HomeListingDetailResponseWrapper> request = new GenericRequest<HomeListingDetailResponseWrapper>(Request.Method.POST, BASE_URL+"homeListingDetails", HomeListingDetailResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< HomeListingDetailResponseWrapper>() {
            @Override
            public void onResponse( HomeListingDetailResponseWrapper response) {
                Log.e("responselisting"," "+response.toString());

                Gson gson=new Gson();
                Log.e("gsonlisting",gson.toJson(response));

                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }

    public void giveFeedback(final Context context, GiveFeedbackRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<GiveFeedbackResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<GiveFeedbackResponseWrapper> request = new GenericRequest<GiveFeedbackResponseWrapper>(Request.Method.POST, BASE_URL+"feedback", GiveFeedbackResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< GiveFeedbackResponseWrapper>() {
            @Override
            public void onResponse( GiveFeedbackResponseWrapper response) {
                Gson gson=new Gson();
                Log.e("gson_givefeedback",gson.toJson(response));


                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }


    public void getFeedback(final Context context, GetFeedbackRequest updatePasswordRequest, final boolean showDialog, final APIResponseListener<GetFeedbackResponseWrapper> listener) {
        showDialog(context, showDialog);
        GenericRequest<GetFeedbackResponseWrapper> request = new GenericRequest<GetFeedbackResponseWrapper>(Request.Method.POST, BASE_URL+"get_feedback",
                GetFeedbackResponseWrapper.class,
                updatePasswordRequest, new Response.Listener< GetFeedbackResponseWrapper>() {
            @Override
            public void onResponse( GetFeedbackResponseWrapper response) {

                Gson gson=new Gson();
                Log.e("gson_feedback",gson.toJson(response));


                if (response.getResponse().isSuccess()) {
                    listener.onReceiveResponse(response);
                    dismissDialog(showDialog);
                } else {
                    listener.onStatusFalse(response);
                    dismissDialog(showDialog);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onResponseFailed();
                dismissDialog(showDialog);
            }
        });
        AppController.getInstance().addToRequestQueue(request);
    }

    public void getTransactionDetails(final Context context, final GetTransactionRequest getTransactionRequest, final boolean showDialog, final APIResponseListener<GetTransactionResponseWrapper>listener){
        showDialog(context, showDialog);

        final GenericRequest<GetTransactionResponseWrapper>request=new GenericRequest<GetTransactionResponseWrapper>
                (Request.Method.POST, BASE_URL + "get_booking", GetTransactionResponseWrapper.class, getTransactionRequest, new Response.Listener<GetTransactionResponseWrapper>() {
                    @Override
                    public void onResponse(GetTransactionResponseWrapper response) {

                        Gson gson=new Gson();
                        Log.e("TransResponse","    "+gson.toJson(response)+"    "+gson.toJson(getTransactionRequest));


                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            Log.e("ssuccess1","success");
                            dismissDialog(showDialog);

                        }
                        else {
                            listener.onStatusFalse(response);
                            Log.e("ssuccess","success");
                            dismissDialog(showDialog);

                        }



                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dismissDialog(showDialog);


                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }


    public void getAllChats(final Context context, ChatRequest getChatRequest, final boolean showDialog, final APIResponseListener<GetChatResponseWrapper>listener){
       // showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("getchat",""+gson.toJson(getChatRequest));
        GenericRequest<GetChatResponseWrapper>request=new GenericRequest<GetChatResponseWrapper>
                (Request.Method.POST, BASE_URL + "get_chat", GetChatResponseWrapper.class, getChatRequest, new Response.Listener<GetChatResponseWrapper>() {
                    @Override
                    public void onResponse(GetChatResponseWrapper response) {
//
                       Gson gson=new Gson();
                        Log.e("get_chat_resp",""+gson.toJson(response));

                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            //dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                           // Log.e("ssuccess","success");
                            //dismissDialog(showDialog);

                        }



                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.networkResponse);
                        dismissDialog(showDialog);


                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }






    public void getBookNow(final Context context, BooknowRequest getbooknowreques, final boolean showDialog, final APIResponseListener<BookNowWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("hcdjc",""+gson.toJson(getbooknowreques));
        GenericRequest<BookNowWrapper>request=new GenericRequest<BookNowWrapper>
                (Request.Method.POST, BASE_URL + "book_now", BookNowWrapper.class, getbooknowreques, new Response.Listener<BookNowWrapper>() {
                    @Override
                    public void onResponse(BookNowWrapper response) {

                        Gson gson=new Gson();
                        Log.e("gsonChat",""+gson.toJson(response));

                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            Log.e("ssuccess_booknow","success");
                            dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                            Log.e("failbooknow","success");
                            dismissDialog(showDialog);

                        }



                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.networkResponse);
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }

    public void getAcceptDecline(final Context context, AcceptDeclineRequest getacceptdeclinerequest, final boolean showDialog, final APIResponseListener<AcceptDeclineWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("hcdjc",""+gson.toJson(getacceptdeclinerequest));
        GenericRequest<AcceptDeclineWrapper>request=new GenericRequest<AcceptDeclineWrapper>
                (Request.Method.POST, BASE_URL + "booking_status_update", AcceptDeclineWrapper.class, getacceptdeclinerequest, new Response.Listener<AcceptDeclineWrapper>() {

                    @Override
                    public void onResponse(AcceptDeclineWrapper response) {

                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            Log.e("successaccept",""+response);
                            dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                            Log.e("failaccept","success");
                            dismissDialog(showDialog);

                        }



                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }




    public void sendDate(final Context context, final SendDateRequest sendDateRequest, final boolean showDialog, final APIResponseListener<SendDateWrapper>listener){
        showDialog(context, showDialog);
        final Gson gson=new Gson();
        Log.e("hcdjc",""+gson.toJson(sendDateRequest));
        final GenericRequest<SendDateWrapper>request=new GenericRequest<SendDateWrapper>
                (Request.Method.POST, BASE_URL + "edit_booking", SendDateWrapper.class, sendDateRequest, new Response.Listener<SendDateWrapper>() {

                    @Override
                    public void onResponse(SendDateWrapper response) {
                        Gson gson1=new Gson();
                        Log.e("gsonvaklue",gson1.toJson(sendDateRequest));

                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            Log.e("successaccept",""+response.getResponse().getMessage());
                            dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                            Log.e("failaccept",""+response.getResponse().getMessage());
                            Toast.makeText(context,"User not editable",Toast.LENGTH_SHORT).show();
                            dismissDialog(showDialog);

                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }






    public void showBooking(final Context context, ShowBookingRequest showBookingRequest, final boolean showDialog, final APIResponseListener<ShowBookingWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("booking",""+gson.toJson(showBookingRequest));
        GenericRequest<ShowBookingWrapper>request=new GenericRequest<ShowBookingWrapper>
                (Request.Method.POST, BASE_URL + "show_booking", ShowBookingWrapper.class, showBookingRequest, new Response.Listener<ShowBookingWrapper>() {


                    @Override
                    public void onResponse(ShowBookingWrapper response) {
                        Gson gson=new Gson();
                        Log.e("booking",""+gson.toJson(response));


                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            Log.e("successbooking",""+response.getResponse().getMessage());
                            dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                            Log.e("failbooking",""+response.getResponse().getMessage());
                            dismissDialog(showDialog);

                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }








    public void showNotification(final Context context, NotificationRequest showNotificationRequest, final boolean showDialog, final APIResponseListener<NotificationWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("notifyreq",""+gson.toJson(showNotificationRequest));
        GenericRequest<NotificationWrapper>request=new GenericRequest<NotificationWrapper>
                (Request.Method.POST, BASE_URL + "update_device", NotificationWrapper.class, showNotificationRequest, new Response.Listener<NotificationWrapper>() {


                    @Override
                    public void onResponse(NotificationWrapper response) {
                        Gson gson=new Gson();
                        Log.e("notifyresponse",""+gson.toJson(response));


                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }



    public void displayAllNotification(final Context context, AllNotificationRequest allNotificationRequest, final boolean showDialog, final APIResponseListener<AllNotificationWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("notify",""+gson.toJson(allNotificationRequest));
        GenericRequest<AllNotificationWrapper>request=new GenericRequest<AllNotificationWrapper>
                (Request.Method.POST, BASE_URL + "getNotifications", AllNotificationWrapper.class, allNotificationRequest, new Response.Listener<AllNotificationWrapper>() {


                    @Override
                    public void onResponse(AllNotificationWrapper response) {
                        Gson gson=new Gson();
                        Log.e("notify",""+gson.toJson(response));


                        if (response.getResponse().isSuccess()) {
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);
                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }



    public void displayAllPaymentSession(final Context context, final PaymentRequest allpaymentRequest, final boolean showDialog, final APIResponseListener<PaymentWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("paymentReq",""+gson.toJson(allpaymentRequest));
        final GenericRequest<PaymentWrapper>request=new GenericRequest<PaymentWrapper>
                (Request.Method.POST, BASE_URL + "paymentSession", PaymentWrapper.class, allpaymentRequest, new Response.Listener<PaymentWrapper>() {

                    @Override
                    public void onResponse(PaymentWrapper response) {

                        Gson gson=new Gson();
                        Log.e("paymentResp",""+gson.toJson(response));
                        Log.e("paymentReq",""+gson.toJson(allpaymentRequest));

                        // listener.onReceiveResponse(response);

                        if (response.getResponse().isSuccess()){
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);

                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                            }



                    }


                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }




    public void displayAllPayment(final Context context, Payment payment, final boolean showDialog, final APIResponseListener<PaymentWrapperValue>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("paymentReq",""+gson.toJson(payment));
        GenericRequest<PaymentWrapperValue>request=new GenericRequest<PaymentWrapperValue>
                (Request.Method.POST, BASE_URL + "payment", PaymentWrapperValue.class, payment, new Response.Listener<PaymentWrapperValue>() {

                    @Override
                    public void onResponse(PaymentWrapperValue response) {

                        Gson gson=new Gson();
                        Log.e("paymentvalue",""+gson.toJson(response));

                        if (response.getResponse().isSuccess()){
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);

                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                        }


                    }


                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }



    public void displayAllAmount(final Context context, GetWalletRequest walletRequest, final boolean showDialog, final APIResponseListener<GetWalletWrapper>listener){
        showDialog(context, showDialog);
        Gson gson=new Gson();
        Log.e("walletReq",""+gson.toJson(walletRequest));
        GenericRequest<GetWalletWrapper>request=new GenericRequest<GetWalletWrapper>
                (Request.Method.POST, BASE_URL + "transaction_list", GetWalletWrapper.class, walletRequest, new Response.Listener<GetWalletWrapper>() {

                    @Override
                    public void onResponse(GetWalletWrapper response) {

                        Gson gson=new Gson();
                        Log.e("walletvalue",""+gson.toJson(response));

                        if (response.getResponse().isSuccess()){
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);

                        }
                        else if (response.getResponse().isSucessCode()){

                            dismissDialog(showDialog);
                            listener.onReceiveResponse(response);
                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                        }



                    }


                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }








    public void saveAllDetails(final Context context, BankDetailsRequest bankDetailsRequest, final boolean showDialog, final APIResponseListener<BankDetailResponseWrapper>listener){
        showDialog(context, showDialog);

        Gson gson=new Gson();
        Log.e("bankdetails",""+gson.toJson(bankDetailsRequest));

        GenericRequest<BankDetailResponseWrapper>request=new GenericRequest<BankDetailResponseWrapper>
                (Request.Method.POST, BASE_URL + "bank_detail_update", BankDetailResponseWrapper.class, bankDetailsRequest, new Response.Listener<BankDetailResponseWrapper>() {

                    @Override
                    public void onResponse(BankDetailResponseWrapper response) {

                        Gson gson=new Gson();
                        Log.e("walletvalue",""+gson.toJson(response));

                        if (response.getResponse().isSuccess()){
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);

                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                        }


                    }


                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }







    public void balancewithDraw(final Context context, BalanceWithdrawRequest withdrawRequest, final boolean showDialog, final APIResponseListener<BalanceWithdrawResponseWrapper>listener){
        showDialog(context, showDialog);

        Gson gson=new Gson();
        Log.e("withdraw",""+gson.toJson(withdrawRequest));

        GenericRequest<BalanceWithdrawResponseWrapper>request=new GenericRequest<BalanceWithdrawResponseWrapper>
                (Request.Method.POST, BASE_URL + "withdraw", BalanceWithdrawResponseWrapper.class, withdrawRequest, new Response.Listener<BalanceWithdrawResponseWrapper>() {

                    @Override
                    public void onResponse(BalanceWithdrawResponseWrapper response) {

                        Gson gson=new Gson();
                        Log.e("withdraw",""+gson.toJson(response));

                        if (response.getResponse().isSuccess()){
                            listener.onReceiveResponse(response);
                            dismissDialog(showDialog);

                        }
                        else {
                            listener.onStatusFalse(response);
                            dismissDialog(showDialog);

                        }


                    }


                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error",""+error.getMessage());
                        dismissDialog(showDialog);

                    }
                });

        AppController.getInstance().addToRequestQueue(request);


    }











}




