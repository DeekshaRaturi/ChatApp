package com.ripenapps.rehntu.models.notification.response;

import com.google.gson.annotations.SerializedName;

public class NotificationWrapper {

    public NotificationResponse getResponse() {
        return response;
    }

    public void setResponse(NotificationResponse response) {
        this.response = response;
    }

    @SerializedName("data")
    private NotificationResponse response;

}
