package com.ripenapps.rehntu.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.ProductListAdapter;
import com.ripenapps.rehntu.models.product.request.ProductRequest;
import com.ripenapps.rehntu.models.product.respponse.Product;
import com.ripenapps.rehntu.models.product.respponse.ProductResponseWrapper;
import com.ripenapps.rehntu.my_screen.EditServicesAndProductActivity;
import com.ripenapps.rehntu.my_screen.UploadImageActivity;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import java.util.ArrayList;
import java.util.List;

public class ProductFragment extends Fragment implements View.OnClickListener,ProductListAdapter.ProductLIstCallback{

    private View view;
    APIUtility apiUtility;
    private ImageView button;
    private RecyclerView productView;
    private ProductListAdapter adapter;
    List<Product> list= new ArrayList<>();
    private TextView noPRoduct;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_product, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
        return view;
    }

    private void InitView() {
        productView=(RecyclerView)view.findViewById(R.id.rv_product_list);
        button = (ImageView) view.findViewById(R.id.fab_product_btn);
        noPRoduct = (TextView) view.findViewById(R.id.noproduct);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        productView.setLayoutManager(gridLayoutManager);
        adapter=new ProductListAdapter(list,ProductFragment.this);
        productView.setAdapter(adapter);
        button.setOnClickListener(this);
        getServices();
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fab_product_btn:
                Intent intent= new Intent(getActivity(), UploadImageActivity.class);
                Preferences.setPreference(getActivity(), PrefEntity.COMEFROM,"Product");
                startActivity(intent);
        }
    }


    void getServices(){
        ProductRequest request= new ProductRequest();
        request.setServices_type("product");
        request.setUser_id(Preferences.getPreference(getActivity().getApplicationContext(),PrefEntity.USERID));

        apiUtility.getProduct(getActivity(), request, true, new APIUtility.APIResponseListener<ProductResponseWrapper>() {
            @Override
            public void onReceiveResponse(ProductResponseWrapper response) {
                if(response!=null){
                    if(response.getResponse().getResult().getProductList().size()>0) {
                        list.clear();
                        list.addAll(response.getResponse().getResult().getProductList());
                        adapter.notifyDataSetChanged();
                        noPRoduct.setVisibility(View.GONE);
                    }else{
                        list.clear();
                        adapter.notifyDataSetChanged();
                        noPRoduct.setVisibility(View.VISIBLE);
//                        CommonUtils.alert(getActivity(),"No Product has been listed by you.");
                    }
                }
            }

            @Override
            public void onResponseFailed() {
                CommonUtils.alert(getActivity(),getString(R.string.VolleyError));
            }

            @Override
            public void onStatusFalse(ProductResponseWrapper response) {
                CommonUtils.alert(getActivity(),response.getResponse().getMessage());

            }
        });
    }

    @Override
    public void OnItemClick(int pos) {
        Preferences.setPreference(getActivity(), PrefEntity.COMEFROM,"Product");
        Intent intent= new Intent(getActivity(), EditServicesAndProductActivity.class);
        intent.putExtra("serviceID",list.get(pos).getId());
        startActivity(intent);
    }
}
