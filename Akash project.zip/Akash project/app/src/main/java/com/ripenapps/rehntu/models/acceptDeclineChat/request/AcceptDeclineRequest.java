package com.ripenapps.rehntu.models.acceptDeclineChat.request;

import com.google.gson.annotations.SerializedName;

public class AcceptDeclineRequest {

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("transaction_id")
    private String transaction_id;

    @SerializedName("status")
    private String status;

    @SerializedName("_id")
    private String _id;

    public Double getDamage_Amount() {
        return damage_Amount;
    }

    public void setDamage_Amount(Double damage_Amount) {
        this.damage_Amount = damage_Amount;
    }

    @SerializedName("damage_Amount")
    private Double damage_Amount;


    @SerializedName("price")
    private String price;



    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }



}