package com.ripenapps.rehntu.my_screen

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.ripenapps.rehntu.R

import org.json.JSONException
import org.json.JSONObject

import java.net.URISyntaxException

import io.socket.client.IO
import io.socket.client.Socket

class MainActivity : AppCompatActivity() {

    private var buttonSend: Button? = null
    private var editTextMsg: EditText? = null
    private var textViewRcvMsg: TextView? = null
    private var mSocket: Socket? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textViewRcvMsg = findViewById(R.id.tv_msg_rcv)

        try {
            mSocket = IO.socket("http://18.216.101.125:3000")

            Toast.makeText(this@MainActivity, "" + mSocket!!.connected(), Toast.LENGTH_LONG).show()
        } catch (e: URISyntaxException) {
        }

        mSocket!!.connect()
        mSocket!!.emit("join", "group")

        mSocket!!.on("connected") {
            Toast.makeText(this@MainActivity, "connect", Toast.LENGTH_LONG).show()
           // mSocket!!.send(Any())
        }

        Log.e("socketidd",""+mSocket?.id())


        mSocket!!.on("chat") { args ->
            Toast.makeText(this@MainActivity, "chat", Toast.LENGTH_LONG).show()
            try {
                val data = args[0] as JSONObject
                try {
                    textViewRcvMsg!!.text = data.getString("message")
                } catch (e: Exception) {
                    e.printStackTrace()
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        mSocket!!.on("typing") { args ->
            try {
                val data = args[0] as JSONObject
                textViewRcvMsg!!.text = "typing..." + data.getString("name")
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        }

        Log.e("sockeid", "" + mSocket!!.id())

        editTextMsg = findViewById(R.id.et_msg)
        buttonSend = findViewById(R.id.btn_msg)
        buttonSend!!.setOnClickListener {
            val jsonObject = JSONObject()
            val `object` = JsonObject()
            val array = JsonArray()
            try {

                //                    jsonObject.put("name", "ASHISH");
                //                    jsonObject.put("message", editTextMsg.getText().toString().trim());
                jsonObject.put("name", "deeksha")
                jsonObject.put("message", editTextMsg!!.text.toString().trim { it <= ' ' })
                jsonObject.put("user_id", "")
                jsonObject.put("socket_id", "")


            } catch (e: JSONException) {
                e.printStackTrace()
            }





            Toast.makeText(this@MainActivity, "" + editTextMsg!!.text.toString().trim { it <= ' ' } + mSocket!!.connected(), Toast.LENGTH_LONG).show()
            editTextMsg!!.setText("")
            textViewRcvMsg!!.text = ""
            mSocket!!.emit("chat", jsonObject)
        }

        editTextMsg!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val jsonObject = JSONObject()
                try {
                    jsonObject.put("name", "Deeksha")
                } catch (e: JSONException) {
                    e.printStackTrace()
                }

                mSocket!!.emit("typing", jsonObject)
            }

            override fun afterTextChanged(s: Editable) {

            }
        })
    }

    public override fun onDestroy() {
        super.onDestroy()

        mSocket!!.disconnect()
    }
}
