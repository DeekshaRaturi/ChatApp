package com.ripenapps.rehntu.models.balanceWithdraw.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;
import com.ripenapps.rehntu.models.bankDetails.response.BankDetailResult;

public class BalanceWithdrawResponse extends BaseResponse {


    public BalanceWithdrawResult getResult() {
        return result;
    }

    public void setResult(BalanceWithdrawResult result) {
        this.result = result;
    }

    @SerializedName("result")
    private BalanceWithdrawResult result;
}
