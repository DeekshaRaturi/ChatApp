package com.ripenapps.rehntu.models.getAllNotification.request;

import com.google.gson.annotations.SerializedName;

public class AllNotificationRequest {


    @SerializedName("offset")
    private String offset;

    @SerializedName("user_id")
    private String user_id;

    public String getOffset() {
        return offset;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }


}
