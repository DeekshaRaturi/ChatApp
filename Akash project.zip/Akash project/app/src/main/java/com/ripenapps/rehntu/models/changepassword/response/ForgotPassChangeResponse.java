package com.ripenapps.rehntu.models.changepassword.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class ForgotPassChangeResponse extends BaseResponse {

    @SerializedName("result")
    private ForgotPassResult result;

    public ForgotPassResult getResult() {
        return result;
    }

    public void setResult(ForgotPassResult result) {
        this.result = result;
    }
}
