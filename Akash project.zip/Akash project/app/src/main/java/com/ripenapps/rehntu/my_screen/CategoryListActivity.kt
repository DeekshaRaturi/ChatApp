package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.CategoryListAdapter
import com.ripenapps.rehntu.models.category.request.CategoryRequest
import com.ripenapps.rehntu.models.category.response.Category
import com.ripenapps.rehntu.models.category.response.CategoryResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import java.util.ArrayList

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class CategoryListActivity : BaseActivity(), CategoryListAdapter.CategoryListAdapterCallback, View.OnClickListener {
    private var back: ImageView? = null
    private var title: AppCompatTextView? = null
    private var categoryView: RecyclerView? = null
    private var editText: EditText? = null
    private var categoryList: MutableList<Category> = ArrayList()
    private var apiUtility: APIUtility?=null
    private var adapter: CategoryListAdapter?=null
    private var category: TextView?=null
    private var nocategory: TextView?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiUtility = APIUtility(this@CategoryListActivity)
        setContentView(R.layout.activity_category_list)
        initViews()
        if (intent.hasExtra("requestFrom")) {
            getCategory1("", intent.getStringExtra("service"))
        } else {
            getCategory("")
        }
    }


    private fun initViews() {
        nocategory = findViewById<View>(R.id.categoryNo) as TextView
        category = findViewById<View>(R.id.categoryTxt) as TextView
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title!!.text = "Select Category"
        back!!.setOnClickListener(this)
        editText = findViewById<View>(R.id.search) as EditText
        categoryView = findViewById<View>(R.id.rv_category) as RecyclerView
        val gridLayoutManager = GridLayoutManager(this, 3, GridLayoutManager.VERTICAL, false)
        categoryView!!.layoutManager = gridLayoutManager
        adapter = CategoryListAdapter(categoryList, this@CategoryListActivity)
        categoryView!!.adapter = adapter
        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            category?.text = "Ex:Furniture,Electronics etc"
        } else {
            category?.text = "Ex:Home cleaner,Saloon,Tuition etc"
        }

        editText!!.setOnEditorActionListener { v, actionId, event ->
            var handled = false
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                if (intent.hasExtra("requestFrom")) {
                    getCategory1(editText!!.text.toString().toLowerCase().trim { it <= ' ' }, intent.getStringExtra("service"))
                } else {
                    getCategory(editText!!.text.toString().toLowerCase().trim { it <= ' ' })
                }


                handled = true
            }
            handled
        }
    }


    internal fun getCategory(text: String?) {
        val request = CategoryRequest()
        request.userId = Preferences.getPreference(applicationContext, PrefEntity.USERID)
        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            request.serviceType = "product"
        } else {
            request.serviceType = "service"
        }

        if (text != null) {
            request.text = text
        } else {
            request.text = ""
        }

        apiUtility?.categoryList(this@CategoryListActivity, request, true, object : APIUtility.APIResponseListener<CategoryResponseWrapper> {
            override fun onReceiveResponse(response: CategoryResponseWrapper?) {
                if (response != null) {
                    if (response.response.result.categoryList.size > 0) {
                        categoryList.clear()
                        nocategory?.visibility = View.GONE
                        categoryList.addAll(response.response.result.categoryList)
                        adapter?.notifyDataSetChanged()
                    } else {
                        nocategory?.visibility = View.VISIBLE
                        categoryList.clear()
                        adapter?.notifyDataSetChanged()
                    }
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@CategoryListActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: CategoryResponseWrapper) {
                CommonUtils.alert(this@CategoryListActivity, response.response.message)

            }
        })
    }


    internal fun getCategory1(text: String?, serviceType: String) {
        val request = CategoryRequest()
        request.userId = Preferences.getPreference(applicationContext, PrefEntity.USERID)
        request.serviceType = serviceType


        if (text != null) {
            request.text = text
        } else {
            request.text = ""
        }

        apiUtility?.categoryList(this@CategoryListActivity, request, true, object : APIUtility.APIResponseListener<CategoryResponseWrapper> {
            override fun onReceiveResponse(response: CategoryResponseWrapper?) {
                if (response != null) {
                    if (response.response.result.categoryList.size > 0) {
                        categoryList.clear()
                        nocategory?.visibility = View.GONE
                        categoryList.addAll(response.response.result.categoryList)
                        adapter?.notifyDataSetChanged()
                    } else {
                        nocategory?.visibility = View.VISIBLE
                        categoryList.clear()
                        adapter?.notifyDataSetChanged()
                    }
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@CategoryListActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: CategoryResponseWrapper) {
                CommonUtils.alert(this@CategoryListActivity, response.response.message)

            }
        })
    }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun itemClick(Pos: Int) {

        if (intent.hasExtra("category")) {
            val intent = Intent()
            intent.putExtra("cat_id", categoryList[Pos].categoryid)
            Preferences.setPreference(applicationContext, PrefEntity.CATEGORY, categoryList[Pos].name)
            Preferences.setPreference(applicationContext, PrefEntity.CATEGORYID, categoryList[Pos].categoryid)
            setResult(Activity.RESULT_OK, intent)
            finish()
        } else if (intent.hasExtra("requestFrom")) {
            val intent1 = Intent()
            intent1.putExtra("cat_id", categoryList[Pos].categoryid)
            intent1.putExtra("cat_name", categoryList[Pos].name)
            intent1.putExtra("service_type", categoryList[Pos].service_type)
            Preferences.setPreference(applicationContext, PrefEntity.CATEGORY, categoryList[Pos].name)
            Preferences.setPreference(applicationContext, PrefEntity.CATEGORYID, categoryList[Pos].categoryid)
            setResult(Activity.RESULT_OK, intent1)
            finish()
        } else {
            val intent = Intent(this@CategoryListActivity, SubCategoryListActivity::class.java)
            intent.putExtra("cat_id", categoryList[Pos].categoryid)
            Preferences.setPreference(applicationContext, PrefEntity.CATEGORY, categoryList[Pos].name)
            Preferences.setPreference(applicationContext, PrefEntity.CATEGORYID, categoryList[Pos].categoryid)
            startActivity(intent)
        }


    }

    override fun onClick(v: View) {
        finish()
    }
}
