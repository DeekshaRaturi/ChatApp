package com.ripenapps.rehntu.models.chat.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class GetChatResponse extends BaseResponse {

    @SerializedName("result")
    private GetChatResult getChatResult;


    public GetChatResult getGetChatResult() {
        return getChatResult;
    }

    public void setGetChatResult(GetChatResult getChatResult) {
        this.getChatResult = getChatResult;
    }
}
