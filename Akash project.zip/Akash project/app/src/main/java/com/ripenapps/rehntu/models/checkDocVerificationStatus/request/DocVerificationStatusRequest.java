package com.ripenapps.rehntu.models.checkDocVerificationStatus.request;

import com.google.gson.annotations.SerializedName;

public class DocVerificationStatusRequest {
    @SerializedName("user_id")
    private String user_id;

    public DocVerificationStatusRequest(String user_id) {
        this.user_id = user_id;
    }
}
