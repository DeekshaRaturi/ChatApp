package com.ripenapps.rehntu.my_screen

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.View
import android.widget.*
import com.adyen.checkout.base.internal.Api
import com.facebook.appevents.internal.AppEventUtility
import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.acceptDeclineChat.request.AcceptDeclineRequest
import com.ripenapps.rehntu.models.acceptDeclineChat.response.AcceptDeclineWrapper
import com.ripenapps.rehntu.models.bankDetails.request.BankDetailsRequest
import com.ripenapps.rehntu.models.bankDetails.response.BankDetailResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import org.json.JSONObject
import org.w3c.dom.Text
import java.lang.Exception

class BankAccountDetailsActivity : AppCompatActivity(),View.OnClickListener {

    var title:TextView?=null
    var cancle_img:ImageView?=null
    var btn_submit:Button?=null
    var apiUtility:APIUtility?=null
    var edt_bank_name:EditText?=null
    var holder_name:EditText?=null
    var country_code:EditText?=null
    var iban_code:EditText?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bank_account_details)

        init()
    }


    fun init(){
        title = findViewById<View>(R.id.title) as TextView
        title?.text="Enter Bank Account Details"
        cancle_img = findViewById<View>(R.id.img_close) as ImageView
        cancle_img?.setOnClickListener(this)
        btn_submit=findViewById(R.id.btn_submit)
        btn_submit?.setOnClickListener(this)
        apiUtility= APIUtility(applicationContext)
        edt_bank_name=findViewById(R.id.edt_bank_name)
        holder_name=findViewById(R.id.holder_name)
        iban_code=findViewById(R.id.iban_code)
        country_code=findViewById(R.id.country_code)





    }


    fun submitBankDetails() {


        val request = BankDetailsRequest()
        request.ownerName=holder_name?.text.toString()
        request.bank_name=edt_bank_name?.text.toString()
        request.iban=iban_code?.text.toString()
        request.countrycode=country_code?.text.toString()

        var gson = Gson()

        Log.e("submit", "" + gson.toJson(request))

        apiUtility?.saveAllDetails(this@BankAccountDetailsActivity, request, true, object : APIUtility.APIResponseListener<BankDetailResponseWrapper> {
            override fun onReceiveResponse(response: BankDetailResponseWrapper?) {

                finish()


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: BankDetailResponseWrapper?) {

            }


        })


    }

    override fun onClick(v: View?) {
        when(v?.id){

            R.id.img_close->{

                finish()
            }
            R.id.btn_submit->{

                if (country_code?.text.toString()!!.equals("")||iban_code?.text.toString()!!.equals("")
                        ||holder_name?.text.toString()!!.equals("")||edt_bank_name?.text.toString()!!.equals("")){

                    Toast.makeText(applicationContext,"Please enter all fields",Toast.LENGTH_SHORT).show()

                }
                else {

                    submitBankDetails()
                }
            }
        }

    }
}
