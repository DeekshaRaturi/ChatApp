package com.ripenapps.rehntu.preferences;

import com.google.gson.JsonArray;

public class PrefEntity {


    public static final String USERID = "userId";
    public static final String COMEFROM = "COMEFROM!@#";
    public static final String COMEFROM1 = "COMEFROM!!@#@#";
    public static final String COMEFROM2 = "COMEFROM!!@#$$$$@#";
    public static final String servicevalue="";
    public static final String productvalue="";
    public static final String to="";
    public static final String from="";
    public static final String  status_array="";


    public static final String ISFILTER = "facebooklogin";
    public static final String ADDRESS = "ADDRESS";
    public static final String USER_EMAIL = "EMAIL";
    public static final String USER_NAME = "NAME";
    public static final String PROFILE_IMAGE="PROFILE_IMAGE";
    public static final String  DOCVERIFY= "DOCVERIFY";
    public static final String COUNTRYCODE = "COUNTRYCODE1";
    public static final String IS_LOGIN = "IS_LOGIN";
    public static final String PHONE_NUMBER = "PHONE_NUBER";
    public static final String IS_PHONE_VERIFIED = "IS_PHONE_VERIFIED";
    public static final String TYPE="TYPE";
    public static final String LAT="LAT";
    public static final String LONG="LONG";
    public static final String LAT1="LAT1";
    public static final String LONG1="LONG1";
    public static final String CATEGORY="EGORY";
    public static final String CATEGORYID="CATEGORYID";

    public static final String CITY="CATEGORYID";
    public static final String POSTAL="CATEGORYID";







}
