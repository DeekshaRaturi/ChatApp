package com.ripenapps.rehntu.models.showBooking.request;

import com.google.gson.annotations.SerializedName;

public class ShowBookingRequest {

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("transaction_id")
    private String transaction_id;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }



}
