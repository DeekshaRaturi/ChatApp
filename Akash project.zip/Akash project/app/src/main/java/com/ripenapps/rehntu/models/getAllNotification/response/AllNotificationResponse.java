package com.ripenapps.rehntu.models.getAllNotification.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;
import com.ripenapps.rehntu.models.notification.response.NotificationResult;

public class AllNotificationResponse extends BaseResponse {

    @SerializedName("result")
    private AllNotificationResult getallnotificationResult;


    public AllNotificationResult getGetallnotificationResult()
    {
        return getallnotificationResult;
    }

    public void setGetallnotificationResult(AllNotificationResult getallnotificationResult) {
        this.getallnotificationResult = getallnotificationResult;
    }



}
