package com.ripenapps.rehntu.models.balanceWithdraw.response;

import com.google.gson.annotations.SerializedName;

public class BalanceWithdrawResponseWrapper {

    public BalanceWithdrawResponse getResponse() {
        return response;
    }

    public void setResponse(BalanceWithdrawResponse response) {
        this.response = response;
    }

    @SerializedName("data")
    BalanceWithdrawResponse response;

}
