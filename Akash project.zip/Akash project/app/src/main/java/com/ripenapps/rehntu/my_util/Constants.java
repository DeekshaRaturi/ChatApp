package com.ripenapps.rehntu.my_util;

public class Constants {

    public static final boolean isDebug = true;
    public static final String VOLLEY_REQUEST = "VOLLEY REQUEST";
    public static final String VOLLEY_TAG = "VOLLEY RESPONSE";
    public static final String IMG_URL = "http://18.216.101.125:3000/";



    public static final int REQUESTCODE_1=1000;
    public static final int REQUESTCODE_2=1001;



}
