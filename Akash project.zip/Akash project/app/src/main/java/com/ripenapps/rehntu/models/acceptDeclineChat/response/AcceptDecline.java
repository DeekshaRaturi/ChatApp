package com.ripenapps.rehntu.models.acceptDeclineChat.response;

public class AcceptDecline {
}
