package com.ripenapps.rehntu.models.services.respponse;



import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Address {

    @SerializedName("location")
    ArrayList<Locations> locations = new ArrayList<>();

    @SerializedName("fullAddress")
   String fullAddress;

    @SerializedName("city")
    String city;

    @SerializedName("pincode")
    String pincode;


    public ArrayList<Locations> getLocations() {
        return locations;
    }

    public void setLocations(ArrayList<Locations> locations) {
        this.locations = locations;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
