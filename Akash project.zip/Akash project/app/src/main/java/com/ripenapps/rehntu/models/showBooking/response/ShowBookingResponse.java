package com.ripenapps.rehntu.models.showBooking.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class ShowBookingResponse extends BaseResponse {


    @SerializedName("result")
    private ShowBookingResult getBookingresult;


    public ShowBookingResult getGetBookingresult() {
        return getBookingresult;
    }

    public void setGetBookingresult(ShowBookingResult getBookingresult) {
        this.getBookingresult = getBookingresult;
    }


}
