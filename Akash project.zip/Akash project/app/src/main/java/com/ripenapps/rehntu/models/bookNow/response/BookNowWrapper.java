package com.ripenapps.rehntu.models.bookNow.response;

import com.google.gson.annotations.SerializedName;

public class BookNowWrapper {


    @SerializedName("data")
    private BookNowResponse response;

    public BookNowResponse getResponse() {
        return response;
    }

    public void setResponse(BookNowResponse response) {
        this.response = response;
    }



}
