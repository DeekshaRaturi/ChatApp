package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.all.All;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.AllFragment;
import com.ripenapps.rehntu.fragment.FragmentOne;
import com.ripenapps.rehntu.models.transaction.response.Transaction;
import com.ripenapps.rehntu.models.walletamount.response.WalletModel;

import java.util.ArrayList;

public class WalletAdapter extends RecyclerView.Adapter<WalletAdapter.ViewHolder> {

    public ArrayList<WalletModel>walletModels;
    public  Context mcontext;

    public WalletAdapter(Context mcontext, ArrayList<WalletModel> walletModels){
        this.mcontext=mcontext;
        this.walletModels=walletModels;
    }


    @NonNull
    @Override
    public WalletAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new WalletAdapter.ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.wallet_amount_item, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull WalletAdapter.ViewHolder viewHolder, int i) {

       viewHolder.name.setText(walletModels.get(i).getName());
       viewHolder.date.setText(walletModels.get(i).getDate());
       viewHolder.service.setText(walletModels.get(i).getService_name());
        Log.e("payment"," "+walletModels.get(i).getTotalAmount());
       if (walletModels.get(i).getStatus().equals(true)){
           viewHolder.txt_total_amount.setText("Payment Recieved");
           viewHolder.total_amount.setText(walletModels.get(i).getTotalAmount());
       }
       else {
           viewHolder.txt_total_amount.setText("Payment Pending");
           viewHolder.total_amount_price.setVisibility(View.GONE);
           viewHolder.total_amount.setVisibility(View.GONE);

       }

    }

    @Override
    public int getItemCount() {
        return walletModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView total_amount;
        private TextView name;
        private TextView service;
        private TextView date;
        private TextView txt_total_amount;
        private TextView total_amount_price;





        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            total_amount=(TextView)itemView.findViewById(R.id.total_amount);
            name=(TextView)itemView.findViewById(R.id.txt_name);
            service=(TextView)itemView.findViewById(R.id.txt_service);
            date=(TextView)itemView.findViewById(R.id.txt_date);
            txt_total_amount=(TextView)itemView.findViewById(R.id.txt_total_amount);
            total_amount_price=(TextView)itemView.findViewById(R.id.total_amount_price);
        }
    }
}
