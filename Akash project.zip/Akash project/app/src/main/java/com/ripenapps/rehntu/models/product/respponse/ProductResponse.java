package com.ripenapps.rehntu.models.product.respponse;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class ProductResponse extends BaseResponse {



    @SerializedName("result")
    private ProductResponseResult result;


    public ProductResponseResult getResult() {
        return result;
    }

    public void setResult(ProductResponseResult result) {
        this.result = result;
    }
}
