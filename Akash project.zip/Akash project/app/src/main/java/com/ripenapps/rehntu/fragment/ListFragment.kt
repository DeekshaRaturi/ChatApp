package com.ripenapps.rehntu.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.MapListAdapter
import com.ripenapps.rehntu.adapter.MapListAdapter1
import com.ripenapps.rehntu.models.map.reguest.MapRequest
import com.ripenapps.rehntu.models.map.response.MapResponseWrapper
import com.ripenapps.rehntu.models.map.response.Service
import com.ripenapps.rehntu.my_screen.OnLoadMoreListener
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.RhentoSingleton
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import java.util.ArrayList

class ListFragment : Fragment() {
    //  var view: View = null
    //var view:View=View()
    var recyclerView: RecyclerView?=null
     var adapter: MapListAdapter?=null
     var adapter1: MapListAdapter1? = null
     var textView: TextView?=null
     var progressBar: ProgressBar?=null
     var PAGE_STARTED = 1
     var PAGE_REFRESH = 1


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.inflate(R.layout.fragment_list, container, false)
        initViews(view)
        return view
    }

    private fun initViews(view: View) {
        textView = view?.findViewById<View>(R.id.nolist) as TextView
        recyclerView = view?.findViewById<View>(R.id.recycler) as RecyclerView
        progressBar = view?.findViewById<View>(R.id.progress_bar) as ProgressBar
        getData(PAGE_REFRESH)


        val linearLayoutManager = LinearLayoutManager(activity)
        recyclerView?.layoutManager = linearLayoutManager


        //        if (Preferences.getPreferenceProductType(getActivity().getApplicationContext(), PrefEntity.COMEFROM2).equals("product")) {
        //            if (RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().size() <= 0) {
        //                textView.setVisibility(View.VISIBLE);
        //                textView.setText("No Product has matched with your search criteria." + "Please Expand your Horizon and Search again.");
        //            }
        //        } else if (Preferences.getPreferenceProductType(getActivity().getApplicationContext(), PrefEntity.COMEFROM1).equals("service")) {
        //            if (RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().size() <= 0) {
        //
        //                textView.setVisibility(View.VISIBLE);
        //                textView.setText("No Service has matched with your search criteria." + "Please Expand your Horizon and Search again.");
        //
        //            }
        //        }
        //
        //        else {
        //            if (RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().size() <= 0) {
        //
        //                textView.setVisibility(View.VISIBLE);
        //                textView.setText("No Product and Service has matched with your search criteria." + "Please Expand your Horizon and Search again.");
        //
        //            }
        //        }


        // Log.e("getservicelist"," "+RhentoSingleton.getInstance().responseResult.getServiceArrayList().size());

        //            adapter = new MapListAdapter(RhentoSingleton.getInstance().getResponseResult().getServiceArrayList(), ListFragment.this,recyclerView);
        //            recyclerView.setAdapter(adapter);
        //            adapter.notifyDataSetChanged();
        //            adapter.setLoaded();
        //            //adapter.setOnLoadMoreListener(onLoadMoreListener());


    }

    internal fun getData(page: Int?) {
        val serviceRequestPojo: MapRequest
        if (Preferences.getPreference(activity, PrefEntity.ISFILTER) != "1") {
            serviceRequestPojo = MapRequest()

            if (Preferences.getPreference(activity, PrefEntity.COMEFROM1) == "service" && Preferences.getPreference(activity, PrefEntity.COMEFROM2) == "product") {
                serviceRequestPojo.servicesType = " "


            } else if (Preferences.getPreference(activity, PrefEntity.COMEFROM1) == "" && Preferences.getPreference(activity, PrefEntity.COMEFROM2) == "") {
                serviceRequestPojo.servicesType = " "


            } else if (Preferences.getPreference(activity, PrefEntity.COMEFROM1) == "" && Preferences.getPreference(activity, PrefEntity.COMEFROM2) == "product") {
                serviceRequestPojo.servicesType = "product"

            } else if (Preferences.getPreference(activity, PrefEntity.COMEFROM1) == "service" && Preferences.getPreference(activity, PrefEntity.COMEFROM2) == "") {

                serviceRequestPojo.servicesType = "service"

            }

            serviceRequestPojo.lat = Preferences.getPreference(activity, PrefEntity.LAT)
            serviceRequestPojo.lng = Preferences.getPreference(activity, PrefEntity.LONG)
            serviceRequestPojo.maxMile = 200.0f
            serviceRequestPojo.maxPrice = 5000.0f
            serviceRequestPojo.minPrice = 0.0f
            serviceRequestPojo.rating = 0
            serviceRequestPojo.userId = Preferences.getPreference(activity, PrefEntity.USERID)
            serviceRequestPojo.minMile = 0.0f
            serviceRequestPojo.page_size = 150
            serviceRequestPojo.page_number = page

        } else {
            serviceRequestPojo = RhentoSingleton.getInstance().getMapRequest()
            Preferences.removePreference(activity, PrefEntity.ISFILTER)

        }
        APIUtility(activity).getPinsData(activity, serviceRequestPojo, true, object : APIUtility.APIResponseListener<MapResponseWrapper> {
            override fun onReceiveResponse(response: MapResponseWrapper?) {
                if (response != null) {


                    if (Preferences.getPreference(activity, PrefEntity.COMEFROM1) == "product") {
                        if (response.response.result.serviceArrayList.size > 0) {
                            RhentoSingleton.getInstance().setResponseResult(response.response.result)
                        } else {
                            RhentoSingleton.getInstance().getResponseResult().serviceArrayList.clear()
                            RhentoSingleton.getInstance().getResponseResult().productArrayList.clear()
                            CommonUtils.alert(activity, "No Product has matched with your search criteria." + "Please Expand your Horizon and Search again.")
                        }
                    } else if (Preferences.getPreference(activity, PrefEntity.COMEFROM1) == "service") {

                        if (response.response.result.serviceArrayList.size > 0) {
                            RhentoSingleton.getInstance().setResponseResult(response.response.result)

                        } else {
                            RhentoSingleton.getInstance().getResponseResult().productArrayList.clear()
                            RhentoSingleton.getInstance().getResponseResult().serviceArrayList.clear()
                            CommonUtils.alert(activity, "No Service has matched with your search criteria." + "Please Expand your Horizon and Search again.")
                        }
                    } else {
                        if (response.response.result.serviceArrayList.size <= 0) {
                            RhentoSingleton.getInstance().getResponseResult().productArrayList.clear()
                            RhentoSingleton.getInstance().getResponseResult().serviceArrayList.clear()
                            CommonUtils.alert(activity, "No Product and Service has matched with your search criteria." + "Please Expand your Horizon and Search again.")

                        } else {
                            RhentoSingleton.getInstance().setResponseResult(response.response.result)
                            progressBar?.visibility=View.GONE
                        }


                    }
                    adapter = MapListAdapter(RhentoSingleton.getInstance().getResponseResult().serviceArrayList, this@ListFragment, recyclerView)
                    recyclerView?.adapter = adapter
                    adapter?.notifyDataSetChanged()

                   // adapter?.setLoaded()
                    //adapter?.setOnLoadMoreListener(onLoad());

                }
            }

            override fun onResponseFailed() {
                RhentoSingleton.getInstance().getResponseResult().serviceArrayList.clear()
                RhentoSingleton.getInstance().getResponseResult().productArrayList.clear()
                CommonUtils.alert(activity?.applicationContext, "Something went wrong")



            }

            override fun onStatusFalse(response: MapResponseWrapper) {
                RhentoSingleton.getInstance().getResponseResult().serviceArrayList.clear()
                RhentoSingleton.getInstance().getResponseResult().productArrayList.clear()
                CommonUtils.alert(activity?.applicationContext, "Something went wrong")


            }
        })
    }

    fun onLoad():OnLoadMoreListener{

        return object : OnLoadMoreListener {
            override fun onLoadMore() {
               // PAGE_STARTED++
                progressBar?.visibility=View.VISIBLE
                getData(++PAGE_STARTED)
                Log.e("pagestarted",""+PAGE_STARTED)


                Log.e("loadd","more")

            }
        }

    }


    }
