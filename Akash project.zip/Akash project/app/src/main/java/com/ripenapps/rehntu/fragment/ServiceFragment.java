package com.ripenapps.rehntu.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.ServiceListAdapter;
import com.ripenapps.rehntu.models.services.request.ServiceRequest;
import com.ripenapps.rehntu.models.services.respponse.Services;
import com.ripenapps.rehntu.models.services.respponse.ServiceResponseWrapper;
import com.ripenapps.rehntu.my_screen.EditServicesAndProductActivity;
import com.ripenapps.rehntu.my_screen.UploadImageActivity;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import java.util.ArrayList;
import java.util.List;

public class ServiceFragment extends Fragment implements View.OnClickListener, ServiceListAdapter.ServiceLIstAdapterCallback {

    private View view;
    APIUtility apiUtility;
    private ImageView button;
    private RecyclerView productView;
    ServiceListAdapter adapter;
    List<Services> list = new ArrayList<>();
    private TextView noPRoduct;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_service, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
        getServices();
        return view;
    }

    private void InitView() {

        productView = (RecyclerView) view.findViewById(R.id.rv_services_list);
        noPRoduct = (TextView) view.findViewById(R.id.noproduct);
        button = (ImageView) view.findViewById(R.id.fab_product_btn);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        productView.setLayoutManager(gridLayoutManager);
        adapter = new ServiceListAdapter(list, ServiceFragment.this);
        productView.setAdapter(adapter);
        button = (ImageView) view.findViewById(R.id.fab_services_btn);
        button.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fab_services_btn:
                Intent intent = new Intent(getActivity(), UploadImageActivity.class);
                Preferences.setPreference(getActivity(), PrefEntity.COMEFROM, "Service");
                startActivity(intent);
        }
    }


    void getServices() {
        ServiceRequest request = new ServiceRequest();
        request.setServices_type("service");
        request.setUser_id(Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.USERID));

        apiUtility.getServicesProduct(getActivity(), request, true, new APIUtility.APIResponseListener<ServiceResponseWrapper>() {
            @Override
            public void onReceiveResponse(ServiceResponseWrapper response) {
                if (response != null) {
                    if (response.getResponse().getResult().getServicesList().size() > 0) {
                        list.clear();
                        list.addAll(response.getResponse().getResult().getServicesList());
                        adapter.notifyDataSetChanged();
                        noPRoduct.setVisibility(View.GONE);
                    }else{
                        list.clear();
                        adapter.notifyDataSetChanged();
                        noPRoduct.setVisibility(View.VISIBLE);
//                        CommonUtils.alert(getActivity(),"No Service has been listed by you.");
                    }
                }
            }

            @Override
            public void onResponseFailed() {
                CommonUtils.alert(getActivity(),getString(R.string.VolleyError));
            }

            @Override
            public void onStatusFalse(ServiceResponseWrapper response) {
                CommonUtils.alert(getActivity(),response.getResponse().getMessage());

            }
        });
    }


    @Override
    public void OnItemClick(int pos) {
        Preferences.setPreference(getActivity(), PrefEntity.COMEFROM, "Service");
        Intent intent = new Intent(getActivity(), EditServicesAndProductActivity.class);
        intent.putExtra("serviceID", list.get(pos).get_id());
        startActivity(intent);
    }
}
