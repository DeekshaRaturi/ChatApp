package com.ripenapps.rehntu.my_screen;


public interface OnLoadMoreListener {

    void onLoadMore();
}
