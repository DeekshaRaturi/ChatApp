package com.ripenapps.rehntu.models.map.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.product.respponse.Product;

import java.util.ArrayList;

public class MapResponseResult {

    @SerializedName("all")
    private ArrayList<Service> serviceArrayList = new ArrayList<>();

    @SerializedName("product")
    private ArrayList<Product> productArrayList = new ArrayList<>();

    public ArrayList<Product> getProductArrayList() {
        return productArrayList;
    }

    public void setProductArrayList(ArrayList<Product> productArrayList) {
        this.productArrayList = productArrayList;
    }

    public ArrayList<Service> getServiceArrayList() {
        return serviceArrayList;
    }

    public void setServiceArrayList(ArrayList<Service> serviceArrayList) {
        this.serviceArrayList = serviceArrayList;
    }

}
