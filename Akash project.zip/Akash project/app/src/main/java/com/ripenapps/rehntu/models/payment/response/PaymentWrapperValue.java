package com.ripenapps.rehntu.models.payment.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.paymentSession.response.PaymentResponse;

public class PaymentWrapperValue {

    public PaymentResponseValue getResponse() {
        return response;
    }

    public void setResponse(PaymentResponseValue response)
    {
        this.response = response;
    }

    @SerializedName("data")
    private PaymentResponseValue response;
}
