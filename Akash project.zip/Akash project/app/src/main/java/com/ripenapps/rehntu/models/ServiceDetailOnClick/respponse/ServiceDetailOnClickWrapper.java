package com.ripenapps.rehntu.models.ServiceDetailOnClick.respponse;

import com.google.gson.annotations.SerializedName;

public class ServiceDetailOnClickWrapper {

    @SerializedName("data")
    ServiceDetailOnClickResponse response;

    public ServiceDetailOnClickResponse getResponse() {
        return response;
    }

    public void setResponse(ServiceDetailOnClickResponse response) {
        this.response = response;
    }
}
