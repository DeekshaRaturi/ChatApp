package com.ripenapps.rehntu.models.showBooking.response;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.bookNow.response.Booking;

import java.util.ArrayList;

public class ShowBookingResult {


    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    @com.google.gson.annotations.SerializedName("bookings")
    @Expose
    Booking booking = new Booking();




}
