package com.ripenapps.rehntu.models.balanceWithdraw.response;

import com.google.gson.annotations.SerializedName;

public class BalanceWithdrawResult {


    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @SerializedName("amount")
    private Double amount;
}
