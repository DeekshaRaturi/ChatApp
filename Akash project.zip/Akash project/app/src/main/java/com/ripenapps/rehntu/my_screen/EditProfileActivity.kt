package com.ripenapps.rehntu.my_screen

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.widget.AppCompatTextView
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.VollySupport.VolleyMultipartRequest
import com.ripenapps.rehntu.VollySupport.VolleySingleton
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import de.hdodenhof.circleimageview.CircleImageView
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.HashMap

class EditProfileActivity : AppCompatActivity() ,View.OnClickListener{


    private var title:AppCompatTextView?= null
    private var back:ImageView?=null
    private var profile_img:CircleImageView?=null
    var image: ByteArray? = null
    private val GALLERY_IMAGE = 0
    private val CAMERA = 1
    private var save_butn:Button?=null
    private var edt_name:EditText?=null
    private var profile_imgview:String?=null
    private var path:String?=null
    private var imageUri:Uri?=null
    private var edt_email:EditText?= null
    private var edt_phno:EditText?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        init()

    }

    fun init(){

        title = findViewById<View>(R.id.title) as AppCompatTextView
        title?.text="Edit Profile"
        back = findViewById<View>(R.id.img_close) as ImageView
        back?.setOnClickListener(this)
        profile_img=findViewById(R.id.profile_img)
        profile_img?.setOnClickListener(this)
        save_butn=findViewById(R.id.save_butn)
        save_butn?.setOnClickListener(this)
        edt_name=findViewById(R.id.edt_name)
        edt_email=findViewById(R.id.edt_email)
        edt_phno=findViewById(R.id.edt_phno)
        edt_name?.setText(Preferences.getPreference(applicationContext,PrefEntity.USER_NAME))
        edt_email?.setText(Preferences.getPreference(applicationContext,PrefEntity.USER_EMAIL))
        edt_phno?.setText(Preferences.getPreference(applicationContext,PrefEntity.PHONE_NUMBER))



    }
    private fun getImageUri(context: Context, inImage: Bitmap): Uri {
        val bytes = ByteArrayOutputStream()
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path = MediaStore.Images.Media.insertImage(context.contentResolver, inImage, "Title", null)
        image = bytes.toByteArray()

        Log.e("bytearray",""+image+"   "+Uri.parse(path))
        imageUri=Uri.parse(path)

        return Uri.parse(path)
    }

    private fun getRealPathFromURI(contentURI: Uri): String? {
        val cursor = this.contentResolver.query(contentURI, null, null, null, null)
        if (cursor == null) { // Source is Dropbox or other similar local file path
            return contentURI.path
        } else {
            cursor.moveToFirst()
            val idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
            return cursor.getString(idx)
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("reqcode", " " + resultCode + " " + requestCode+"  "+data?.getExtras()?.get("data"))


        if (resultCode == Activity.RESULT_CANCELED) {

            return
        }

        if (resultCode == Activity.RESULT_OK) {
            Log.e("reqcode11111", " $requestCode $resultCode $data")


            if (requestCode == GALLERY_IMAGE) {

               // val imageBitMap = data?.getExtras()!!.get("data") as Bitmap
                val imageBitMap = MediaStore.Images.Media.getBitmap(this@EditProfileActivity.getContentResolver(), data?.getData())
                val uri = getImageUri(this@EditProfileActivity, imageBitMap)
                 path = getRealPathFromURI(uri)
                Log.e("dfgh1", path.toString()+" "+uri)

                profile_img?.setImageURI(uri)


            }

            else if (requestCode == CAMERA) {

                 val imageBitMap = data?.getExtras()!!.get("data") as Bitmap

                //val imageBitMap = MediaStore.Images.Media.getBitmap(this@EditProfileActivity.getContentResolver(), data?.getData())
                val uri = getImageUri(this@EditProfileActivity, imageBitMap)
                path = getRealPathFromURI(uri)
                Log.e("dfgh", path.toString()+" "+uri)
                profile_img?.setImageURI(uri)


            }

        }
    }


    internal fun EditProfile(user_id: String, imageview: String,name:String) {


       var url="http://18.216.101.125:3000/mobile_api/edit_profile"
        APIUtility(this).showDialog(this, true)
        val multipartRequest = object : VolleyMultipartRequest(Request.Method.POST, url, Response.Listener { response ->
            val responseString = String(response.data)
            Log.e("string",responseString)
//
            APIUtility(this@EditProfileActivity).dismissDialog(true)
           try {
                val jObj = JSONObject(responseString)
               val data=jObj.getJSONObject("data")

                val code = data.getInt("code")
                val  result=data.getJSONObject("result")
               Log.e("result",""+code+" "+result)


                if (code == 1) {
                    Log.e("sucess",""+code)
                    APIUtility(this).showDialog(this,false)
                    Toast.makeText(applicationContext,"Uploaded succesfully", Toast.LENGTH_SHORT).show()
                    var name=result.getString("name")
                    Preferences.setPreference(applicationContext,PrefEntity.USER_NAME,name)
                    Preferences.setPreference(applicationContext,PrefEntity.PROFILE_IMAGE,imageUri.toString())

                    var intent = getIntent();
                    intent.putExtra("path", imageUri.toString())

                    intent.putExtra("name",name)
                    setResult(RESULT_OK, intent);
                    finish();

                }

            } catch (e: JSONException) {
                Log.e("exception",""+e.message)
                APIUtility(this@EditProfileActivity).dismissDialog(false)
                CommonUtils.alert(this@EditProfileActivity, e.message.toString())
           }
        }, Response.ErrorListener {
            Log.e("error"," error")

        }) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()

                params.put("user_id",user_id)
                params.put("name",name)

                Log.e("MultipartRequestname", Gson().toJson(params))

                return params

            }

            override fun getByteData(): Map<String, VolleyMultipartRequest.DataPart>? {
                val params = HashMap<String, DataPart>()

                if (image != null) {
                    params["profile_img"] = DataPart("User_profile.jpg", image, "image/jpeg")
                    //uploads/users/id_proof/profile_img-1554102516500-User_profile.jpg
                    Log.e("params",""+params)
                }
                return params
            }

        }

        multipartRequest.retryPolicy = DefaultRetryPolicy(
                40000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)
        VolleySingleton.getInstance(this@EditProfileActivity).addToRequestQueue(multipartRequest)


    }



    private fun selectPicture() {

        val options = arrayOf<CharSequence>("Take Photo", "Choose from Gallery", "Cancel")

        val builder = AlertDialog.Builder(this@EditProfileActivity)
        builder.setTitle("Select Profile Photo From")
        builder.setItems(options) { dialog, item ->
            if (options[item] == "Take Photo") {
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@EditProfileActivity, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
                } else {
                    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    startActivityForResult(cameraIntent, CAMERA)
                }
            } else if (options[item] == "Choose from Gallery") {
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@EditProfileActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2)
                } else {
                    val intent = Intent()
                    intent.type = "image/*"
                    intent.action = Intent.ACTION_GET_CONTENT
                    Log.e("gallert","galleery")
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), GALLERY_IMAGE)
                }
            }
        }
        builder.show()

    }
    override fun onClick(v: View?) {
        when(v?.id){

            R.id.img_close->{

                finish()
            }
            R.id.profile_img->{

                selectPicture()

            }
            R.id.save_butn->{

                EditProfile(Preferences.getPreference(applicationContext,PrefEntity.USERID),"",edt_name?.text.toString())
            }


        }


    }
}
