package com.ripenapps.rehntu.my_screen

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Bundle
import android.view.WindowManager

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class SplashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_splash)
        /* try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "com.gogreen.main",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }*/
        startActivity()
    }


    private fun startActivity() {

        Handler().postDelayed({
            if (Preferences.getPreference_int(applicationContext, PrefEntity.IS_LOGIN) == 1) {
                if (!Preferences.getPreference_boolean(applicationContext, PrefEntity.IS_PHONE_VERIFIED)) {
                    startActivity(Intent(this@SplashActivity, LoginActivity::class.java))

                } else {
                    if (Preferences.getPreference(applicationContext, PrefEntity.LAT) == "") {
                        startActivity(Intent(this@SplashActivity, GetCurrentLocationActivity::class.java))
                    } else {
                        startActivity(Intent(this@SplashActivity, DashBoardActivity::class.java))
                    }
                }
            } else {

                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))

            }
            finish()
        }, 2000)
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }
}
