package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.getFeedback.response.Feedback;
import com.ripenapps.rehntu.my_util.CommonUtils;

import java.util.List;

public class FeedbackAdapter extends RecyclerView.Adapter<FeedbackAdapter.ViewHolder> {

    private Context mContext;
    private List<Feedback> categoryList;


    public FeedbackAdapter(List<Feedback> streetList, Context mContext) {
        this.mContext = mContext;
        this.categoryList = streetList;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.feedbacklist, parent, false));
    }


    @Override
    public void onBindViewHolder(final FeedbackAdapter.ViewHolder holder, final int position) {

        holder.name.setText(categoryList.get(position).getUserDetail().getName());

        holder.date.setText(CommonUtils.dateDifferent(categoryList.get(position).getReviewed_At()));


       // holder.date.setText(CommonUtils.getTimeAgo(Long.valueOf(categoryList.get(position).getReviewed_At())));


        // Log.e("time"," "+CommonUtils.getTimeAgo(Long.valueOf(categoryList.get(position).getReviewed_At())));

        holder.rating.setText(categoryList.get(position).getRating()+" Rating");
        holder.review.setText(categoryList.get(position).getReview());



    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView list;
        TextView name,date,rating,review;


        ViewHolder(View itemView) {
            super(itemView);

            name=(TextView)itemView.findViewById(R.id.name);
            date=(TextView)itemView.findViewById(R.id.date);
            rating=(TextView)itemView.findViewById(R.id.rate);
            review=(TextView)itemView.findViewById(R.id.review);

        }


    }


}





