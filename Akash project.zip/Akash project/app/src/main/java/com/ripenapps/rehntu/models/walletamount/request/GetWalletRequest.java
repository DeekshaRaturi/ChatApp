package com.ripenapps.rehntu.models.walletamount.request;

import com.google.gson.annotations.SerializedName;

public class GetWalletRequest {

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("type")
    private String type;
}
