package com.ripenapps.rehntu.my_screen

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

import com.facebook.AccessToken
import com.facebook.CallbackManager
import com.facebook.FacebookAuthorizationException
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.GraphRequest
import com.facebook.HttpMethod
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.facebook.login.widget.LoginButton
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.GoogleApiClient
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.login.request.LoginRequest
import com.ripenapps.rehntu.models.login.response.LoginResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.volley.APIUtility

import java.util.Arrays

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class LoginActivity1 : BaseActivity(), View.OnClickListener {


    private var facebook_login: ImageView? = null
    private var google_login: ImageView? = null
    private var userEmail: EditText? = null
    private var userPassword: EditText? = null
    private var loginButton: Button? = null
    internal var apiUtility: APIUtility?=null
    private var sign_up: TextView? = null
    private var forgot_password: TextView? = null
    private var fb_login_btn: LoginButton? = null
    private val gmail_signin_Button: SignInButton? = null
    private var callbackManager: CallbackManager? = null
    internal var googleApiClient: GoogleApiClient? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        apiUtility = APIUtility(this@LoginActivity1)
        initViews()
    }

    private fun initViews() {

        facebook_login = findViewById<View>(R.id.facebook_login) as ImageView
        google_login = findViewById<View>(R.id.google_login) as ImageView
        userEmail = findViewById<View>(R.id.login_email_mobile) as EditText
        userPassword = findViewById<View>(R.id.login_password) as EditText
        forgot_password = findViewById<View>(R.id.forgot_password) as TextView
        loginButton = findViewById<View>(R.id.login_button) as Button
        sign_up = findViewById<View>(R.id.sign_up) as TextView

        facebook_login!!.setOnClickListener(this)
        google_login!!.setOnClickListener(this)
        forgot_password!!.setOnClickListener(this)
        loginButton!!.setOnClickListener(this)
        sign_up!!.setOnClickListener(this)
        facebookInit()
    }

    override fun onClick(v: View) {
        when (v.id) {

            R.id.sign_up -> {
                val intent = Intent(this@LoginActivity1, SignupActivity::class.java)
                startActivity(intent)
            }

            R.id.login_button -> validation()


            R.id.forgot_password -> {
                val intent1 = Intent(this@LoginActivity1, ForgetPassActivity::class.java)
                startActivity(intent1)
            }
        }
    }

    private fun validation() {
        if (!TextUtils.isEmpty(userEmail!!.text.toString().trim { it <= ' ' })) {
            if (CommonUtils.isEmailValid(userEmail!!.text.toString().trim { it <= ' ' }) || CommonUtils.isValidMobile(userEmail!!)) {
                if (!TextUtils.isEmpty(userPassword!!.text.toString().trim { it <= ' ' })) {
                    if (userPassword!!.text.toString().trim { it <= ' ' }.length >= 6 && userPassword!!.text.toString().trim { it <= ' ' }.length >= 6) {

                        userLogin("EM", "", userEmail!!.text.toString().trim { it <= ' ' }, userPassword!!.text.toString().trim { it <= ' ' }, "", "", "")

                    } else {
                        userPassword!!.error = getString(R.string.password_length)

                    }
                } else {
                    userPassword!!.error = getString(R.string.alert_password)

                }
            } else {

                userEmail!!.error = getString(R.string.alert_email_mobile_valid)

            }
        } else {
            userEmail!!.error = getString(R.string.alert_email)

        }
    }

    private fun userLogin(loginType: String, name: String, email: String, password: String, mobile: String, countryCode: String, socailID: String) {

        val request = LoginRequest()
        request.email = email
        request.mobile = mobile
        request.loginType = loginType
        request.name = name
        request.password = password
        request.socialID = socailID


        apiUtility?.userLogin(this@LoginActivity1, request, true, object : APIUtility.APIResponseListener<LoginResponseWrapper> {
            override fun onReceiveResponse(response: LoginResponseWrapper?) {
                if (response != null) {

                    setUserDetails(response.response.result.email, response.response.result.mobile, response.response.result.name, response.response.result.id, response.response.result.isVerified, response.response.result.doc_Verify, response.response.result.country_code)

                    if (!response.response.result.isVerified) {
                        val intent = Intent(this@LoginActivity1, VerificationActivity::class.java)
                        intent.putExtra("activity", "Login")
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                    } else {
                        val intent = Intent(this@LoginActivity1, GetCurrentLocationActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                    }

                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@LoginActivity1, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: LoginResponseWrapper) {
                if (response.response.status == 4) {
                    val intent = Intent(this@LoginActivity1, UpdatePasswordActivity::class.java)
                    intent.putExtra("email", email)
                    startActivity(intent)
                    finish()
                } else {
                    CommonUtils.alert(this@LoginActivity1, response.response.message)
                }
            }
        })
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }




    override fun onBackPressed() {
        AlertDialog.Builder(this@LoginActivity1)
                .setMessage("Are you sure want to Exit? ")
                .setTitle(R.string.app_name)
                .setCancelable(false)
                .setNegativeButton("Cancel") { dialog, which -> dialog.dismiss() }
                .setPositiveButton(android.R.string.ok
                ) { dialog, whichButton ->
                    dialog.dismiss()
                    finish()
                }.show()
    }


    internal fun facebookInit() {

        callbackManager = CallbackManager.Factory.create()
        fb_login_btn = findViewById<View>(R.id.facebook_login_button) as LoginButton
        fb_login_btn!!.setReadPermissions(Arrays.asList("public_profile", "email"))
        fb_login_btn!!.registerCallback(callbackManager, object : FacebookCallback<LoginResult> {
            override fun onSuccess(loginResult: LoginResult) {
                CommonUtils.log(applicationContext, "Facebook ID", loginResult.accessToken.userId)
                getGraphData(loginResult.accessToken.userId)
                Log.d("RESPONSE FACEBOOK : ", loginResult.toString())
            }

            override fun onCancel() {
                if (AccessToken.getCurrentAccessToken() != null) {
                    LoginManager.getInstance().logOut()
                }
            }

            override fun onError(exception: FacebookException) {
                Log.d("RESPONSE FACEBOOK EXP: ", exception.toString())
                if (exception is FacebookAuthorizationException) {
                    if (AccessToken.getCurrentAccessToken() != null) {
                        LoginManager.getInstance().logOut()
                    }
                }
                exception.printStackTrace()
            }
        })

    }


    private fun getGraphData(userID: String) {
        val request = GraphRequest(
                AccessToken.getCurrentAccessToken(),
                "/$userID", null,
                HttpMethod.GET,
                GraphRequest.Callback { response ->
                    try {
                        var id = ""
                        var email = ""
                        var firstname = ""
                        var lastname = ""
                        val country = ""
                        val `object` = response.jsonObject
                        Log.d("OBJECT", `object`.toString())
                        if (`object`.has("id")) {
                            id = `object`.getString("id")
                        }
                        if (`object`.has("first_name")) {
                            firstname = `object`.getString("first_name")
                        }
                        if (`object`.has("last_name")) {
                            lastname = `object`.getString("last_name")
                        }
                        if (`object`.has("email")) {
                            email = `object`.getString("email")
                        }


                        if (CommonUtils.isEmailValid(email)) {

                            userLogin("FB", firstname + lastname, email, "", "", "", id)

                        }

                    } catch (e: Exception) {
                        e.printStackTrace()
                        CommonUtils.alert(this@LoginActivity1, getString(R.string.VolleyError))
                        Log.d("RESPONSEFACEBOOKGRAPH: ", e.toString())
                    }
                })
        val parameters = Bundle()
        parameters.putString("fields", "email,first_name,last_name")
        request.parameters = parameters
        request.executeAsync()
    }


    /*public void showDialogMobileNumber(Activity activity, final String loginType) {
        numberDialog = new Dialog(activity);
        final LayoutInflater inflater = LayoutInflater.from(activity);
        final View view = inflater.inflate(R.layout.add_mobile_no_dialog, null, false);
        numberDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        numberDialog.setCancelable(false);
        numberDialog.setContentView(view);
        numberDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        editTextMobile = view.findViewById(R.id.edit_text_mobile);
        editTextMobile.setHint("Enter Mobile Number");

        Button sendData = (Button) view.findViewById(R.id.dialogButtonOK);
        ImageView close = (ImageView) view.findViewById(R.id.closeDialogue);
        final CountryCodePicker countryCodePicker = (CountryCodePicker) view.findViewById(R.id.ccp_dialog);

        countryCodePicker.setCountryForPhoneCode(+1);
        RhentoSingleton.getInstance().setCountryCodeAndroid(countryCodePicker.getDefaultCountryCodeWithPlus());
        ;

        countryCodePicker.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected() {
                RhentoSingleton.getInstance().setCountryCodeAndroid(countryCodePicker.getSelectedCountryCodeWithPlus());
            }
        });

        sendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stringNumber = editTextMobile.getText().toString();
                editTextMobile.setError(null);
                if (stringNumber.equals("") || stringNumber.isEmpty()) {
                    editTextMobile.setError("Enter Mobile Number");
                } else {
                    editTextMobile.setError(null);
                    numberDialog.dismiss();
                    RhentoSingleton.getInstance().setMobile_num(editTextMobile.getText().toString());
                    isNewUser = true;
                    LoginValidation(loginType);

                }
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                    Toast.makeText(getApplicationContext(),"Okay" ,Toast.LENGTH_SHORT).show();
                numberDialog.dismiss();
            }
        });

        numberDialog.show();
    }

    public void showDialogEmail(Activity activity, final String loginType) {
      Dialog  dialog = new Dialog(activity);
        final LayoutInflater inflater = LayoutInflater.from(activity);
        final View view = inflater.inflate(R.layout.entre_email_dialoge, null, false);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(view);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        final EditText editTextemail = view.findViewById(R.id.dialog_mobile);
        editTextemail.setError(null);
        editTextemail.setHint("Enter Email id");

        Button sendData = (Button) dialog.findViewById(R.id.dialog_send);
        sendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             String   stringEmail = editTextemail.getText().toString();
                editTextemail.setError(null);
                if (stringEmail.equals("") || stringEmail.isEmpty()) {
                    editTextemail.setError("Enter Email id");
                } else if (!CommonUtils.isEmailValid(stringEmail)) {
                    editTextemail.setError("Enter Valid Email address");
                } else {
                    editTextemail.setError(null);



                }

            }
        });

        ImageView close = (ImageView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();

    }


    void LoginValidation(String login_type) {
        if (login_type.equals("EM")) {
            LoginAttempt(login_type, "", RhentoSingleton.getInstance().getEmail(), RhentoSingleton.getInstance().getPassword(), "", "", "");

        } else if (login_type.equals("FB")) {
            if (RhentoSingleton.getInstance().getEmail().equals("")) {
                showDialogEmail(LoginActivity1.this, "FB");
            } else if (RhentoSingleton.getInstance().getMobile_num().equals("")) {
                showDialogMobileNumber(LoginActivity1.this, "FB");
            } else if (isNewUser) {
                CheckRegistration(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), "");
            } else {
                LoginAttempt(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), "", RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), RhentoSingleton.getInstance().getSocial_id());

            }

        } else if (login_type.equals("G+")) {
            if (RhentoSingleton.getInstance().getEmail().equals("") || RhentoSingleton.getInstance().getEmail().equals(null)) {
                showDialogEmail(LoginActivity1.this, "G+");
            } else if (RhentoSingleton.getInstance().getMobile_num().equals("") || RhentoSingleton.getInstance().getMobile_num().equals(null)) {
                showDialogMobileNumber(LoginActivity1.this, "G+");
            } else if (isNewUser) {
                CheckRegistration(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), "");
            } else {
                LoginAttempt(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), "", RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), RhentoSingleton.getInstance().getSocial_id());
            }

//            LoginAttempt(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), "", RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), RhentoSingleton.getInstance().getSocial_id());

        } else {
            CommonUtils.alert(LoginActivity1.this, "Something Went Wrong ! Try again.");
        }
    }*/

}

