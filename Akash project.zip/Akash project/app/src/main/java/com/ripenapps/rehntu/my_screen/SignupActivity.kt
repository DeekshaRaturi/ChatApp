package com.ripenapps.rehntu.my_screen

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView

import com.google.gson.Gson
import com.hbb20.CountryCodePicker
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.checkRegistration.request.CheckRegistrationReq
import com.ripenapps.rehntu.models.checkRegistration.response.CheckRegistrationResponseWrapper
import com.ripenapps.rehntu.models.notification.request.NotificationRequest
import com.ripenapps.rehntu.models.notification.response.NotificationWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class SignupActivity : BaseActivity(), View.OnClickListener {

    private var nameT: EditText? = null
    private var emailT: EditText? = null
    private var phoneT: EditText? = null
    private var passT: EditText? = null
    private var sign_up_btn: Button? = null
    private var apiUtility: APIUtility? = null
    private var ccp: CountryCodePicker? = null
    private var back: ImageView? = null
    private var countryCodeAndroid = "+91"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        apiUtility = APIUtility(this)
        initViewS()
    }


    private fun initViewS() {
        ccp = findViewById<View>(R.id.ccp) as CountryCodePicker
        nameT = findViewById<View>(R.id.sign_name) as EditText
        emailT = findViewById<View>(R.id.sign_email) as EditText
        phoneT = findViewById<View>(R.id.sign_phone) as EditText
        back = findViewById<View>(R.id.back_sign_up) as ImageView
        passT = findViewById<View>(R.id.sign_password) as EditText
        sign_up_btn = findViewById(R.id.sign_up_btn)
        sign_up_btn!!.setOnClickListener(this)
        back!!.setOnClickListener(this)

        ccp!!.setCountryForPhoneCode(+91)
        countryCodeAndroid = ccp!!.defaultCountryCodeWithPlus
        ccp!!.setOnCountryChangeListener {
            countryCodeAndroid = ccp!!.selectedCountryCodeWithPlus
            Log.d("CountryCode", countryCodeAndroid)
        }
    }


    override fun onClick(v: View) {
        when (v.id) {

            R.id.sign_up_btn -> {
                signUp()
            }

            R.id.back_sign_up -> finish()
        }
    }


    private fun signUp() {

        if (!TextUtils.isEmpty(nameT!!.text.toString().trim { it <= ' ' })) {
            /* if (nameT.getText().toString().trim().length() >= 3) {*/
            if (!TextUtils.isEmpty(emailT!!.text.toString().trim { it <= ' ' })) {
                if (CommonUtils.isEmailValid(emailT!!.text.toString().trim { it <= ' ' })) {
                    if (!TextUtils.isEmpty(phoneT!!.text.toString().trim { it <= ' ' })) {
                        if (CommonUtils.isValidMobNumber(phoneT!!.text.toString().trim { it <= ' ' })) {

                            if (!TextUtils.isEmpty(passT!!.text.toString().trim { it <= ' ' })) {
                                if (passT!!.text.toString().trim { it <= ' ' }.length >= 8) {
                                    checkRegistration(nameT!!.text.toString().trim { it <= ' ' }, emailT!!.text.toString().trim { it <= ' ' }, phoneT!!.text.toString().trim { it <= ' ' }, countryCodeAndroid, passT!!.text.toString().trim { it <= ' ' })
                                } else {
                                    CommonUtils.alert(this@SignupActivity, getString(R.string.password_length))

                                    //                                        passT.setError(getString(R.string.password_length));
                                }
                            } else {
                                CommonUtils.alert(this@SignupActivity, getString(R.string.alert_password))

                                //                                    passT.setError(getString(R.string.alert_password));
                            }
                        } else {
                            CommonUtils.alert(this@SignupActivity, getString(R.string.alert_mobile_valid))

                            //                                emailT.setError(getString(R.string.alert_email_valid));
                        }
                    } else {

                        CommonUtils.alert(this@SignupActivity, getString(R.string.alert_mobile))

                        //                            emailT.setError(getString(R.string.alert_mobile));
                    }
                } else {
                    CommonUtils.alert(this@SignupActivity, getString(R.string.alert_email_valid))

                    //                        phoneT.setError(getString(R.string.alert_mobile_valid));
                }
            } else {
                CommonUtils.alert(this@SignupActivity, getString(R.string.alert_email))

                //                    phoneT.setError(getString(R.string.alert_mobile));
            }
        } /*else {
                CommonUtils.alert(SignupActivity.this, getString(R.string.alert_name_size));


//                nameT.setError(getString(R.string.alert_name_size));
            }*/
        else {
            CommonUtils.alert(this@SignupActivity, getString(R.string.alert_name))


            //            nameT.setError(getString(R.string.alert_name));
        }/*}*/
    }


    private fun checkRegistration(name: String, email: String, phone: String, county_code: String, pass: String) {
        val checkRegistrationReq = CheckRegistrationReq(name, email, phone, county_code, pass)
        apiUtility!!.checkRegistration(this@SignupActivity, checkRegistrationReq, true, object : APIUtility.APIResponseListener<CheckRegistrationResponseWrapper> {
            override fun onReceiveResponse(response: CheckRegistrationResponseWrapper?) {
                if (response != null) {
                    val gson = Gson()
                    Log.e("gsonsignup", "" + gson.toJson(response))


                    val intent = Intent(this@SignupActivity, VerificationActivity::class.java)
                    intent.putExtra("comeFrom", "LOGIN")
                    intent.putExtra("mobile", phone)
                    intent.putExtra("name", name)
                    intent.putExtra("email", email)
                    intent.putExtra("pass", pass)
                    intent.putExtra("county_code", county_code)
                    startActivity(intent)
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@SignupActivity, getString(R.string.VolleyError))

            }

            override fun onStatusFalse(response: CheckRegistrationResponseWrapper) {
                CommonUtils.alert(this@SignupActivity, response.response.message)
            }
        })
    }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }
}
