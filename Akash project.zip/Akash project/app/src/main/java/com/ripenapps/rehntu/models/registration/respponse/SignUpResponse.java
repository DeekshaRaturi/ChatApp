package com.ripenapps.rehntu.models.registration.respponse;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class SignUpResponse extends BaseResponse {



    @SerializedName("result")
    private SignUpResponseResult result;


    public SignUpResponseResult getResult() {
        return result;
    }

    public void setResult(SignUpResponseResult result) {
        this.result = result;
    }
}
