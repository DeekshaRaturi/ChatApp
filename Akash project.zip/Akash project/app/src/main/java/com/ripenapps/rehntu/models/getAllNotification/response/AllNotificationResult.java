package com.ripenapps.rehntu.models.getAllNotification.response;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


public class AllNotificationResult {

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    @SerializedName("_id")
    private String _id;



    public ArrayList<JsonObject> getNotifications() {
        return notifications;
    }

    public void setNotifications(ArrayList<JsonObject> notifications) {
        this.notifications = notifications;
    }

    @SerializedName("notifications")

    private ArrayList<JsonObject>notifications=new ArrayList<>();








}
