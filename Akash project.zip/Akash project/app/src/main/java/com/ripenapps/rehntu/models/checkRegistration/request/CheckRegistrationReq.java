package com.ripenapps.rehntu.models.checkRegistration.request;

import com.google.gson.annotations.SerializedName;

public class CheckRegistrationReq {

    @SerializedName("name")
    private String name;

    @SerializedName("email")
    private String email;

    @SerializedName("password")
    private String password;

    @SerializedName("country_code")
    private String country_code;

    @SerializedName("mobile_no")
    private String mobile_no;

    public CheckRegistrationReq(String name, String email, String mobile_no, String country_code, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.country_code = country_code;
        this.mobile_no = mobile_no;
    }
}
