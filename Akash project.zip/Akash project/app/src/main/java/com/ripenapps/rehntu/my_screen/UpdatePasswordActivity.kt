package com.ripenapps.rehntu.my_screen

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.changepassword.response.ForgotPassChangeResponseWrapper
import com.ripenapps.rehntu.models.changepassword.request.ForgotPassChangeReq
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.volley.APIUtility

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class UpdatePasswordActivity : BaseActivity(), View.OnClickListener {
    private var btn_submit: Button? = null
    private var new_password: EditText? = null
    private var confirm_password: EditText? = null
    private var apiUtility: APIUtility? = null
    private var email_id: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_password)
        apiUtility = APIUtility(this@UpdatePasswordActivity)
        initViews()
    }

    private fun initViews() {
        btn_submit = findViewById<View>(R.id.btn_submit) as Button
        new_password = findViewById<View>(R.id.new_password) as EditText
        confirm_password = findViewById<View>(R.id.confirm_password) as EditText
        btn_submit!!.setOnClickListener(this)

        if (intent != null) {
            email_id = intent.getStringExtra("email")
        }

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_submit -> validation()
        }

    }

    private fun validation() {

        if (!TextUtils.isEmpty(new_password!!.text.toString().trim { it <= ' ' })) {

            if (new_password!!.text.toString().trim { it <= ' ' }.length >= 8) {

                if (!TextUtils.isEmpty(confirm_password!!.text.toString().trim { it <= ' ' })) {

                    if (confirm_password!!.text.toString().trim { it <= ' ' }.length >= 8) {

                        if (new_password!!.text.toString().trim { it <= ' ' } == confirm_password!!.text.toString().trim { it <= ' ' }) {

                            changePassword(new_password!!.text.toString(), email_id)


                        } else {
                            CommonUtils.alert(this@UpdatePasswordActivity, getString(R.string.samePasswordAlert))
                            //                            confirm_password.setError(getString(R.string.samePasswordAlert));
                        }

                    } else {
                        CommonUtils.alert(this@UpdatePasswordActivity, getString(R.string.password_length))

                        //                        confirm_password.setError(getString(R.string.password_length));
                    }
                } else {
                    CommonUtils.alert(this@UpdatePasswordActivity, getString(R.string.alert_password))

                    //                    confirm_password.setError(getString(R.string.alert_password));
                }

            } else {
                CommonUtils.alert(this@UpdatePasswordActivity, getString(R.string.password_length))

                //                new_password.setError(getString(R.string.password_length));
            }
        } else {
            CommonUtils.alert(this@UpdatePasswordActivity, getString(R.string.alert_password))


            //            new_password.setError(getString(R.string.alert_password));
        }


    }

    private fun changePassword(password: String, email_id: String?) {
        val request = ForgotPassChangeReq(email_id, password)

        apiUtility!!.updatePassword(this@UpdatePasswordActivity, request, true, object : APIUtility.APIResponseListener<ForgotPassChangeResponseWrapper> {
            override fun onReceiveResponse(response: ForgotPassChangeResponseWrapper?) {
                if (response != null) {

                    setUserDetails(response.response.result.email, response.response.result.mobile, response.response.result.name, response.response.result.id, response.response.result.isVerified, response.response.result.doc_Verify, response.response.result.country_code)

                    val intent = Intent(this@UpdatePasswordActivity, GetCurrentLocationActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@UpdatePasswordActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: ForgotPassChangeResponseWrapper) {
                CommonUtils.alert(this@UpdatePasswordActivity, response.response.message)

            }
        })
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }
}

