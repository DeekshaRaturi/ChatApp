package com.ripenapps.rehntu.my_screen

import android.app.DatePickerDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.*
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.JsonArray

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.fragment.FragmentOne
import com.ripenapps.rehntu.models.transaction.request.GetTransactionRequest
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import com.ripenapps.rehntu.volley.AppController

import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.activity_transaction_filter.*
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashSet

class TransactionFilterActivity : AppCompatActivity(), View.OnClickListener {

    private var img_close: ImageView? = null
    private var img_from: EditText? = null
    private var img_to: EditText? = null
    private var mYear: Int = 0
    private var mMonth: Int = 0
    private var mDay: Int = 0
    private var title: AppCompatTextView? = null

    private var apiUtility:APIUtility?=null
    private var converted_date:String?=null
    private var from_date:String?=null
    private var to_date:String?=null
    private var buyer:String?=null
    private var service_type:String?=null
    private var butn_apply:Button?=null
    internal var isServiceSelected = false
    internal var isProductSelected = false
    var isnegotiationselected=false
    var isProgressSelected=false
    var isCancleSelected=false
    var isCompletedSelected=false
    var checkbox_services:ImageView?=null
    var checkbox_product:ImageView?= null
    var checkbox_negotiation:ImageView?=null
    var checkbox_inprogress:ImageView?= null
    var checkbox_cancled:ImageView?=null
    var checkbox_completed:ImageView?=null
    var status_list:ArrayList<Int>?= ArrayList()
    var array:JsonArray= JsonArray()
    var to_variable:String?=null
    var from_variable:String?=null
    var status_list_value_variable:JsonArray= JsonArray()
    var service_type_variable:String?=null
    var convertedTime:String?=null
    var total_array:ArrayList<Int>?= ArrayList()
    var txt_clear_all:TextView?=null
    var globalVariable= AppController()
    var fromdate:Long?=null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_transaction_filter)


        initView()


    }

    private fun initView() {

        apiUtility=APIUtility(this@TransactionFilterActivity)
        globalVariable= (applicationContext as AppController)


        img_close = findViewById<View>(R.id.img_close) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title!!.text = "Apply Filter"
        txt_clear_all=findViewById(R.id.txt_clear_all)
        txt_clear_all!!.text="Clear all"

        checkbox_services=findViewById(R.id.checkbox_services)
        checkbox_product=findViewById(R.id.checkbox_product)
        checkbox_negotiation=findViewById(R.id.checkbox_negotiation)
        checkbox_inprogress=findViewById(R.id.checkbox_inprogress)
        checkbox_cancled=findViewById(R.id.checkbox_cancled)
        checkbox_completed=findViewById(R.id.checkbox_completed)




        img_to = findViewById<View>(R.id.img_to) as EditText
        img_from = findViewById<View>(R.id.img_from) as EditText



        butn_apply=findViewById(R.id.butn_apply)

        img_to!!.setOnClickListener(this)
        img_from!!.setOnClickListener(this)
        img_close!!.setOnClickListener(this)

        checkbox_services?.setOnClickListener(this)
        checkbox_product?.setOnClickListener(this)

        checkbox_negotiation?.setOnClickListener(this)
        checkbox_inprogress?.setOnClickListener(this)
        checkbox_cancled?.setOnClickListener(this)
        checkbox_completed?.setOnClickListener(this)

        butn_apply?.setOnClickListener(this)
        txt_clear_all?.visibility=View.VISIBLE

        txt_clear_all?.setOnClickListener(this)


        from_variable= (applicationContext as AppController).getFrom()
        to_variable = (applicationContext as AppController).getTo()
        status_list_value_variable = (applicationContext as AppController).getStatus_value()
        service_type_variable = (applicationContext as AppController).getService_type()
        status_list=(applicationContext as AppController).getTotal_array()
        Log.e("status_list",""+status_list)


        if (!from_variable.equals(null)){
            getConvertedTimeReverse(from_variable!!)

            img_from?.setText(convertedTime)


        }
        if (!to_variable.equals(null)){
            getConvertedTimeReverse(to_variable!!)
            img_to?.setText(convertedTime)

        }
        if (status_list?.size!=0 || status_list?.size!=null){

            for (i in 0 until status_list!!.size){

                if (status_list!!.get(i)==0){
                    checkbox_negotiation?.setImageResource(R.mipmap.check)
                     isnegotiationselected=true

                }
                if(status_list!!.get(i)==1||status_list!!.get(i)==2||status_list?.get(i)==4){
                    checkbox_inprogress?.setImageResource(R.mipmap.check)
                    isProgressSelected=true


                }
                if (status_list!!.get(i)==5||status_list!!.get(i)==6){
                    checkbox_cancled?.setImageResource(R.mipmap.check)
                    isCancleSelected=true


                }
                if (status_list!!.get(i)==7){
                    checkbox_completed?.setImageResource(R.mipmap.check)
                    isCompletedSelected=true
                } }
            }



        if (!service_type_variable.equals("")){

            if (service_type_variable.equals("service")){
                checkbox_services?.setImageResource(R.mipmap.check)
                isServiceSelected = true



            }
            else if (service_type_variable.equals("product")){
                checkbox_product?.setImageResource(R.mipmap.check)
                isProductSelected = true



            }
            else if (service_type_variable.equals("all")){
                checkbox_services?.setImageResource(R.mipmap.check)
                checkbox_product?.setImageResource(R.mipmap.check)
                isServiceSelected = true
                isProductSelected = true

            }

        }
        else{

        }

    }

    fun getConvertedTimeReverse(strDate: String) {

        try {

            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("dd-MM-yyyy");
            convertedTime=targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }

    fun getConvertedTime(strDate: String) {

        try {
            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");

            val date: Date = sourceDateFormat.parse(strDate);

            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            converted_date=targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }



    override fun onClick(v: View) {
        when (v.id) {

            R.id.img_close -> {

                finish()
            }
            R.id.checkbox_services->{

                resetButton()

            }
            R.id.checkbox_product->{

                resetButton1()
            }
            R.id.checkbox_negotiation->{

                negotiationBtn()
            }
            R.id.checkbox_inprogress->{

                inProgressBtn()
            }
            R.id.checkbox_cancled->{

                cancelledBtn()
            }
            R.id.checkbox_completed->{

                completedBtn()
            }
            R.id.txt_clear_all->{

                clear_all()

            }

            R.id.butn_apply->{

                getAllTransactionFilter()

            }


            R.id.img_to -> {

                if (!img_from?.text.toString().equals("")!!) {


                    img_to!!.isFocusable = false
                    CommonUtils.closeKeyboard(applicationContext, img_to!!.windowToken)


                    val c = Calendar.getInstance()
                    mYear = c.get(Calendar.YEAR)
                    mMonth = c.get(Calendar.MONTH)
                    mDay = c.get(Calendar.DAY_OF_MONTH)


                    val datePickerDialog = DatePickerDialog(this,
                            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                                img_to!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                                val datenew: String = "" + year + "-" + String.format("%02d", (monthOfYear + 1)) + "-" + String.format("%02d", dayOfMonth)
                                getConvertedTime(datenew)
                                to_date = converted_date
                                globalVariable.setTo(to_date)

                            }, mYear, mMonth, mDay)
                    datePickerDialog.show()

                    datePickerDialog.getDatePicker().minDate = fromdate!!


                }
                else {

                    Toast.makeText(applicationContext, "Please Select from date", Toast.LENGTH_SHORT).show()
                }
            }


            R.id.img_from -> {

                img_from!!.isFocusable = false

                CommonUtils.closeKeyboard(applicationContext, img_from!!.windowToken)


                val c = Calendar.getInstance()
                mYear = c.get(Calendar.YEAR)
                mMonth = c.get(Calendar.MONTH)
                mDay = c.get(Calendar.DAY_OF_MONTH)


                val datePickerDialog = DatePickerDialog(this,
                        DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                            img_from!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                            val datenew:String = ""+year+"-"+String.format("%02d", (monthOfYear+1))+"-"+String.format("%02d", dayOfMonth)
                            getConvertedTime(datenew)
                            from_date=converted_date
                            globalVariable?.setFrom(from_date)

                            var formatter =  SimpleDateFormat("yyyy-MM-dd");
                            var date = formatter!!.parse(datenew)

                            fromdate=date.time


                        }, mYear, mMonth, mDay)
                datePickerDialog.show()
                datePickerDialog.getDatePicker().minDate=System.currentTimeMillis()-1000


            }
        }

    }

    private fun clear_all() {

        checkbox_inprogress?.setImageResource(R.mipmap.uncheck)
        checkbox_completed?.setImageResource(R.mipmap.uncheck)
        checkbox_inprogress?.setImageResource(R.mipmap.uncheck)
        checkbox_cancled?.setImageResource(R.mipmap.uncheck)
        checkbox_negotiation?.setImageResource(R.mipmap.uncheck)
        checkbox_product?.setImageResource(R.mipmap.uncheck)
        img_from?.setHint("From")
        img_to?.setHint("To")
        var globalVariable= (applicationContext as AppController)
        globalVariable.setTotal_array(null)
        globalVariable.setTo("")
        globalVariable.setFrom("")
        globalVariable.setStatus_value(array)
        globalVariable.setService_type("")
        finish()





    }

    private fun resetButton() {

        if (!isServiceSelected) {
            checkbox_services?.setImageResource(R.mipmap.check)
            isServiceSelected = true


        } else {
            Preferences.removePreference(applicationContext, PrefEntity.servicevalue)
            isServiceSelected = false
            checkbox_services?.setImageResource(R.mipmap.uncheck)

        }
    }


    private fun resetButton1() {

        if (!isProductSelected) {
            isProductSelected = true
            checkbox_product?.setImageResource(R.mipmap.check)

        } else {
            checkbox_product?.setImageResource(R.mipmap.uncheck)
            isProductSelected = false

        }


    }

    private fun negotiationBtn(){

        if (!isnegotiationselected) {
            isnegotiationselected = true
            checkbox_negotiation?.setImageResource(R.mipmap.check)
            status_list?.add(0)

        } else {
            checkbox_negotiation?.setImageResource(R.mipmap.uncheck)
            isnegotiationselected = false
            status_list?.remove(0)

        }



    }

    private fun inProgressBtn(){

        if (!isProgressSelected) {
            isProgressSelected = true
            checkbox_inprogress?.setImageResource(R.mipmap.check)
            status_list?.add(1)
            status_list?.add(2)
            status_list?.add(4)



        } else {
            checkbox_inprogress?.setImageResource(R.mipmap.uncheck)
            isProgressSelected = false
            status_list?.remove(1)
            status_list?.remove(2)
            status_list?.remove(4)




        }

    }
    private fun cancelledBtn(){


        if (!isCancleSelected) {
            isCancleSelected = true
            checkbox_cancled?.setImageResource(R.mipmap.check)
            status_list?.add(5)
            status_list?.add(6)


        } else {
            checkbox_cancled?.setImageResource(R.mipmap.uncheck)
            isCancleSelected = false
            status_list?.remove(5)
            status_list?.remove(6)



        }


    }

    private fun completedBtn(){


        if (!isCompletedSelected) {
            isCompletedSelected = true
            checkbox_completed?.setImageResource(R.mipmap.check)
            status_list?.add(7)



        } else {
            checkbox_completed?.setImageResource(R.mipmap.uncheck)
            isCompletedSelected = false
            status_list?.remove(7)


        }

    }

    fun getAllTransactionFilter() {

        var request = GetTransactionRequest()

        request.from = from_date

        if (isServiceSelected == true && isProductSelected == true) {

            request.service_type = "all"
            service_type = "all"

        }
        else if (isProductSelected == true && isServiceSelected == false) {

            request.service_type = "product"
            service_type = "product"

        }
        else if (isProductSelected == false && isServiceSelected == true) {

            request.service_type = "service"
            service_type = "service"


        }

        request.service_type = service_type

        globalVariable.setService_type(service_type)

       globalVariable?.setTotal_array(status_list)

        if(status_list?.size!=null) {
            for (i in 0 until status_list!!.size) {
                array.add(status_list?.get(i))

            }
        }
        globalVariable?.setStatus_value(array)

        request.user_id = Preferences.getPreference(this@TransactionFilterActivity, PrefEntity.USERID)
        request.to = to_date


        var gson = Gson()
        finish()

    }

    }
