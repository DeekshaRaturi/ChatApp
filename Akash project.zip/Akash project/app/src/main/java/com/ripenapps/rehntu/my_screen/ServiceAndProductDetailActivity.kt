package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.support.v7.widget.AppCompatTextView
import android.util.Log
import android.view.View
import android.widget.*

import com.google.gson.Gson
import com.ripenapps.rehntu.R

import com.ripenapps.rehntu.adapter.HomeListingImageViewPagerAdapter
import com.ripenapps.rehntu.models.homeListingDetail.request.HomeListingDetailRequest
import com.ripenapps.rehntu.models.homeListingDetail.response.HomeListingDetailResponseWrapper
import com.ripenapps.rehntu.models.homeListingDetail.response.HomeListingDetailResult
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.Constants
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper
import java.text.SimpleDateFormat
import java.util.*

class ServiceAndProductDetailActivity : BaseActivity(), View.OnClickListener {
    private var about: TextView? = null
    private var info: TextView? = null
    private var address: TextView? = null
    private var bestPrice: TextView? = null
    private var addressData: TextView? = null
    private var member: TextView? = null
    private var rate_type:String?=null
    private var jobCompleted: TextView? = null
    private var aboutData: TextView? = null
    private var reviews: TextView? = null
    private var rating: TextView? = null
    private var security: TextView? = null
    private var year: TextView? = null
    private var homeService: ImageView? = null
    private var verfiedBYRhentu: ImageView? = null
    private var chat: ImageView? = null
    private var back: ImageView? = null
    private var addImg: ImageView? = null
    private var aboutImg: ImageView? = null
    private var infoImg: ImageView? = null
    private var title: AppCompatTextView? = null
    private var booknow: Button? = null
    private var rl_about: RelativeLayout? = null
    private var rl_member: RelativeLayout? = null
    private var rl_job: RelativeLayout? = null
    private var rl_bestPrice: RelativeLayout? = null
    private var rl_adress: RelativeLayout? = null
    private var rl_hmService: RelativeLayout? = null
    private var rl_verify: RelativeLayout? = null
    private var rl_year: RelativeLayout? = null
    private var rl_security: RelativeLayout? = null
    var apiUtility: APIUtility? = null
    var tabLayout: TabLayout? = null
    var viewPager: ViewPager? = null
    var imagesList: ArrayList<String>? = ArrayList()
    var feedbackPage: LinearLayout? = null
    private var serviceType: String? = null
    private var userid: String? = null
    private var transaction_id: String? = null
    private var producttype: String? = null
    private var serviceId: String? = null
    private var service_name: String? = null
    private var service_provider_name: String? = null
    private var user_id: String? = null
    private var status: Int? = null
    private var price: Int? = null
    private var securityDeposite: String? = null
    private  var  INTERVAL:Long = 1000 * 60*10 // 1 day
    private var timestamp:TextView?=null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_service_product_detail)

        apiUtility = APIUtility(this@ServiceAndProductDetailActivity)

        init()
        homeListingDetail(intent.getStringExtra("id"), intent.getStringExtra("productType"))
        homeListingDetail(intent.getStringExtra("userid"), intent.getStringExtra("userid"))
        userid = intent.getStringExtra("userid")
        Log.e("userid", " " + userid!!+"   "+Preferences.getPreference(applicationContext,PrefEntity.USERID)+"  "+userid.equals(Preferences.getPreference(applicationContext,PrefEntity.USERID)))
        producttype = intent.getStringExtra("productType")

        if (userid.equals(Preferences.getPreference(applicationContext,PrefEntity.USERID))){

            chat?.visibility=View.GONE
            booknow?.visibility=View.GONE

        }



    }

    private fun homeListingDetail(id: String, productType: String) {

        val request = HomeListingDetailRequest()
        request.setServiceId(id)
        request.setUserId(Preferences.getPreference(applicationContext, PrefEntity.USERID))
        request.setServicesType(productType)

        val gson = Gson()
        Log.e("requestlist", " " + gson.toJson(request))

        apiUtility?.homeServicesProductListingDetail(this@ServiceAndProductDetailActivity, request, true, object : APIUtility.APIResponseListener<HomeListingDetailResponseWrapper> {
            override fun onReceiveResponse(response: HomeListingDetailResponseWrapper?) {
                val gson = Gson()


                Log.e("getresplisting", " " + gson.toJson(response))

                if (response != null) {
                    imagesList?.clear()
                    imagesList?.addAll(response.response.result.images)
                    setData(response.response.result)
                }

            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@ServiceAndProductDetailActivity, getString(R.string.VolleyError))

            }

            override fun onStatusFalse(response: HomeListingDetailResponseWrapper) {
                // CommonUtils.alert(ServiceAndProductDetailActivity.this, response.getResponse().getMessage());

            }
        })
    }

    private fun setData(result: HomeListingDetailResult) {

        setViewPagerAdapter()
        title!!.text = result.name
        member!!.text = result.memberSince
        reviews!!.text = result.total_review + " Reviews"
        transaction_id = result.transection_id
        user_id = result.userId
        status = result.status
        price = result.price
        securityDeposite = result.securityDeposit
        rate_type=result.rate_type

        Log.e("idgddddd", "" + transaction_id + " " + status + price+" "+securityDeposite+"  "+rate_type)


        serviceId = result.uid
        service_name = result.name
        service_provider_name = result.service_provider_name

        if (status!! > 0) {
            booknow?.visibility = View.GONE

        }

        Log.e("transid", " " + transaction_id)

        val ratings = java.lang.Float.parseFloat(result.average_rating)
        val y = Math.round(ratings)
        Log.e("rating", "" + y)

        rating!!.text = y.toString() + " Ratings"

        serviceType = result.services_type

        aboutData!!.text = result.description
        if (intent.getStringExtra("productType") == "product") {
            rl_security!!.visibility = View.VISIBLE
            rl_year!!.visibility = View.VISIBLE
            rl_hmService!!.visibility = View.GONE
            bestPrice!!.text = result.rateHour + "/h"
            security!!.text = result.securityDeposit
            year!!.text = result.yearPurchase
        } else {
            rl_security!!.visibility = View.GONE
            rl_year!!.visibility = View.GONE
            rl_hmService!!.visibility = View.VISIBLE
            bestPrice!!.text = "$ " + result.basePrice + " +"
        }

        addressData!!.text = result.address.fullAddress
        if (result.rehntuVerify == "2") {
            verfiedBYRhentu!!.setImageResource(R.drawable.tick)

        } else {
            verfiedBYRhentu!!.setImageResource(R.drawable.tick)
        }

        if (!result.isIs_deleted) {
            homeService!!.setImageResource(R.drawable.tick)
        }

        jobCompleted!!.text = "0"

    }


    private fun init() {

        aboutImg = findViewById(R.id.about_img) as ImageView
        addImg = findViewById(R.id.add_img) as ImageView
        infoImg = findViewById(R.id.info_img) as ImageView
        viewPager = findViewById(R.id.viewpage) as ViewPager
        reviews = findViewById(R.id.reviews) as TextView
        feedbackPage = findViewById(R.id.reveiewPage) as LinearLayout
        rating = findViewById(R.id.rating) as TextView
        about = findViewById(R.id.about) as TextView
        security = findViewById(R.id.security) as TextView
        year = findViewById(R.id.year) as TextView
        info = findViewById(R.id.info) as TextView
        address = findViewById(R.id.adress) as TextView
        bestPrice = findViewById(R.id.et_best_price) as TextView
        addressData = findViewById(R.id.tv_address) as TextView
        member = findViewById(R.id.memberSinceDate) as TextView
        jobCompleted = findViewById(R.id.jobCompletedDate) as TextView
        aboutData = findViewById(R.id.about_data) as TextView
        homeService = findViewById(R.id.iv_home_service_ablable) as ImageView
        verfiedBYRhentu = findViewById(R.id.verify) as ImageView
        chat = findViewById(R.id.chat) as ImageView
        back = findViewById(R.id.back) as ImageView
        title = findViewById(R.id.title) as AppCompatTextView
        booknow = findViewById(R.id.bookNow) as Button
        rl_about = findViewById(R.id.rl_about) as RelativeLayout
        rl_adress = findViewById(R.id.rl_address) as RelativeLayout
        rl_bestPrice = findViewById(R.id.rl_best) as RelativeLayout
        rl_hmService = findViewById(R.id.rl_home) as RelativeLayout
        rl_job = findViewById(R.id.rl_job) as RelativeLayout
        rl_member = findViewById(R.id.rl_member) as RelativeLayout
        rl_verify = findViewById(R.id.rl_verify) as RelativeLayout
        rl_security = findViewById(R.id.rl_security) as RelativeLayout
        rl_year = findViewById(R.id.rl_year) as RelativeLayout

        tabLayout = findViewById(R.id.tab_layout) as TabLayout
        about!!.setOnClickListener(this)
        info!!.setOnClickListener(this)
        address!!.setOnClickListener(this)
        chat!!.setOnClickListener(this)
        booknow!!.setOnClickListener(this)
        back!!.setOnClickListener(this)
        feedbackPage?.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.about -> {
                onClickAbout()
            }

            R.id.info -> onClickInfo()

            R.id.reveiewPage -> {
                val intent = Intent(this@ServiceAndProductDetailActivity, FeedbackActivity::class.java)
                intent.putExtra("id", getIntent().getStringExtra("id"))
                intent.putExtra("productType", getIntent().getStringExtra("productType"))
                intent.putExtra("name", title!!.text.toString().trim { it <= ' ' })
                startActivity(intent)
            }

            R.id.adress -> {
                onClickAddress()
            }

            R.id.chat -> {
                val intent1 = Intent(this, ChatActivity::class.java)

                intent1.putExtra("buyer_id", userid)
                //intent1.putExtra("service_type",producttype)

                intent1.putExtra("serviceId", serviceId)
                intent1.putExtra("service_name", service_name)
                intent1.putExtra("serviceprovidername", service_provider_name)
                intent1.putExtra("service_type", serviceType)
                intent1.putExtra("transaction_id", transaction_id)
                intent1.putExtra("status", status.toString())
                intent1.putExtra("recievername", service_provider_name)
                intent1.putExtra("isbuyer", "true")
                intent1.putExtra("price", price)
                intent1.putExtra("rate_type",rate_type)

                intent1.putExtra("securityDeposite", securityDeposite)
                Log.e("tranisddd", " " + transaction_id + "" + service_provider_name + " " + serviceType + " " + serviceId + " " + price)
                startActivityForResult(intent1,1111)
            }

            R.id.bookNow -> {

                if (serviceType == "product") {
                    val intent2 = Intent(this, ProductBookingActivity::class.java)
                    intent2.putExtra("service_name", service_name)
                    intent2.putExtra("transaction_id", transaction_id)
                    intent2.putExtra("service_type", serviceType)
                    intent2.putExtra("serviceId", serviceId)
                    intent2.putExtra("status", status.toString())
                    intent2.putExtra("securityDeposite", securityDeposite)

                    intent2.putExtra("user_id", user_id)
                    intent2.putExtra("value", 0)
                    intent2.putExtra("rate_type",rate_type)
                    intent2.putExtra("serviceprovidername", service_provider_name)
                    startActivityForResult(intent2,11111)

                } else {

                    val intent2 = Intent(this, ServiceBookingActivity::class.java)
                    intent2.putExtra("service_name", service_name)
                    intent2.putExtra("transaction_id", transaction_id)
                    intent2.putExtra("service_type", serviceType)
                    intent2.putExtra("serviceId", serviceId)
                    intent2.putExtra("user_id", user_id)
                    intent2.putExtra("value", 0)
                    intent2.putExtra("status", status.toString())
                    intent2.putExtra("serviceprovidername", service_provider_name)
                    startActivityForResult(intent2,11111)
                }
            }

            R.id.back -> finish()
        }
    }

    private fun onClickAddress() {
        address!!.setTextColor(resources.getColor(R.color.colorPrimary))
        about!!.setTextColor(resources.getColor(R.color.black))
        info!!.setTextColor(resources.getColor(R.color.black))
        rl_verify!!.visibility = View.GONE
        rl_member!!.visibility = View.GONE
        rl_job!!.visibility = View.GONE
        rl_bestPrice!!.visibility = View.GONE
        rl_hmService!!.visibility = View.GONE
        rl_about!!.visibility = View.GONE
        rl_adress!!.visibility = View.VISIBLE
        rl_year!!.visibility = View.GONE
        rl_security!!.visibility = View.GONE
        addImg!!.visibility = View.VISIBLE
        aboutImg!!.visibility = View.GONE
        infoImg!!.visibility = View.GONE

    }

    private fun onClickInfo() {

        addImg!!.visibility = View.GONE
        aboutImg!!.visibility = View.GONE
        infoImg!!.visibility = View.VISIBLE
        info!!.setTextColor(resources.getColor(R.color.colorPrimary))
        about!!.setTextColor(resources.getColor(R.color.black))
        address!!.setTextColor(resources.getColor(R.color.black))

        rl_member!!.visibility = View.VISIBLE
        rl_job!!.visibility = View.VISIBLE
        rl_bestPrice!!.visibility = View.VISIBLE

        if (Preferences.getPreferenceProductType(applicationContext, PrefEntity.COMEFROM1) == "product") {
            rl_hmService!!.visibility = View.GONE
            rl_year!!.visibility = View.VISIBLE
            rl_security!!.visibility = View.VISIBLE
            rl_verify!!.visibility = View.GONE
        } else {
            rl_year!!.visibility = View.GONE
            rl_security!!.visibility = View.GONE
            rl_hmService!!.visibility = View.VISIBLE
            rl_verify!!.visibility = View.VISIBLE
        }
        rl_adress!!.visibility = View.GONE
        rl_about!!.visibility = View.GONE
    }

    private fun onClickAbout() {
        addImg!!.visibility = View.GONE
        aboutImg!!.visibility = View.VISIBLE
        infoImg!!.visibility = View.GONE
        about!!.setTextColor(resources.getColor(R.color.colorPrimary))
        address!!.setTextColor(resources.getColor(R.color.black))
        info!!.setTextColor(resources.getColor(R.color.black))
        rl_verify!!.visibility = View.GONE
        rl_member!!.visibility = View.GONE
        rl_job!!.visibility = View.GONE
        rl_bestPrice!!.visibility = View.GONE
        rl_hmService!!.visibility = View.GONE
        rl_adress!!.visibility = View.GONE
        rl_about!!.visibility = View.VISIBLE
        rl_year!!.visibility = View.GONE
        rl_security!!.visibility = View.GONE
    }


    private fun setViewPagerAdapter() {
        Log.e("imglist", " " + imagesList!!.size);
        viewPager?.adapter = HomeListingImageViewPagerAdapter(imagesList, this@ServiceAndProductDetailActivity)
        tabLayout?.setupWithViewPager(viewPager, true)
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("statusreq",""+requestCode+" "+resultCode)

        if (requestCode == 11111 && resultCode== Activity.RESULT_OK) {
            Log.e("req",""+requestCode+" "+resultCode)


                Log.e("statuss",""+data?.getIntExtra("status",0))
            status=data?.getIntExtra("status",0)
            if (status!=0){
                booknow?.visibility=View.GONE

            }


        }
    }
}
