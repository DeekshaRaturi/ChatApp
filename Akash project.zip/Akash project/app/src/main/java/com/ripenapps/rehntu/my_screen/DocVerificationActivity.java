package com.ripenapps.rehntu.my_screen;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.VollySupport.VolleyMultipartRequest;
import com.ripenapps.rehntu.VollySupport.VolleySingleton;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class DocVerificationActivity extends BaseActivity implements View.OnClickListener {

    Button btn_submit;
    ImageView upload_image, imageView;
    Spinner document_type_spinner;
    byte[] image = null;
    private AppCompatTextView title;
    private ImageView back;

    BroadcastReceiver uploadDoc = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            UploadDocument(Preferences.getPreference(DocVerificationActivity.this, PrefEntity.USERID), document_type_spinner.getSelectedItem().toString());

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_verification);
        initViews();
        LocalBroadcastManager.getInstance(DocVerificationActivity.this).registerReceiver(uploadDoc, new IntentFilter("startUpload"));

    }

    private void initViews() {
        back = (ImageView) findViewById(R.id.back);
        title = (AppCompatTextView) findViewById(R.id.title);
        title.setText("Upload Document");
        back.setOnClickListener(this);
        btn_submit = (Button) findViewById(R.id.btn_submit);
        upload_image = (ImageView) findViewById(R.id.upload_image);
        imageView = (ImageView) findViewById(R.id.imageView);
        upload_image.setOnClickListener(this);
        btn_submit.setOnClickListener(this);
        document_type_spinner = (Spinner) findViewById(R.id.document_type_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.document_array,/*R.layout.spinnertext*/ android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        document_type_spinner.setAdapter(adapter);

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_submit:
                validation();
                break;

            case R.id.upload_image:
                selectPicture();
                break;

            case R.id.back:
                finish();
                break;
        }
    }

    private void validation() {
        if (image == null) {
            CommonUtils.alert(DocVerificationActivity.this, "Please upload Document");
        } else if (document_type_spinner.getSelectedItem().toString().equals("Select Document")) {

            CommonUtils.alert(DocVerificationActivity.this, "Please select document type.");
        } else {

            Preferences.setPreference(getApplicationContext(), PrefEntity.TYPE, document_type_spinner.getSelectedItem().toString());

//            UploadDocument(Preferences.getPreference(DocVerificationActivity.this, PrefEntity.USERID),document_type_spinner.getSelectedItem().toString());


            Intent intent = new Intent(DocVerificationActivity.this, VerificationActivity.class);
            String mobile_no = Preferences.getPreference(DocVerificationActivity.this, PrefEntity.PHONE_NUMBER);
            String user_id = Preferences.getPreference(DocVerificationActivity.this, PrefEntity.USERID);
            String country_code = Preferences.getPreference(DocVerificationActivity.this, PrefEntity.COUNTRYCODE);
            intent.putExtra("comeFrom1", "VERIFI_DOCUMENT");
            intent.putExtra("mobile", mobile_no);
            intent.putExtra("user_Id", user_id);
            intent.putExtra("county_code", country_code);
            startActivity(intent);


        }


    }


    void UploadDocument(final String user_id, final String documentType) {


        final String url = "http://18.216.101.125:3000/mobile_api/upload_id";
        new APIUtility(this).showDialog(this, true);
        VolleyMultipartRequest multipartRequest = new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {

            @Override
            public void onResponse(NetworkResponse response) {
                String responseString = new String(response.data);
                Log.d("ERROR", responseString + "ERROR");
                new APIUtility(DocVerificationActivity.this).dismissDialog(true);
                try {
                    JSONObject jObj = new JSONObject(responseString);
                    JSONObject data = jObj.getJSONObject("data");
                    JSONObject result = data.getJSONObject("result");
                    String code = data.getString("code");
                    String docVerify = result.getString("doc_verify");
                    if (docVerify != null) {
                        Preferences.setPreference(getApplicationContext(), PrefEntity.DOCVERIFY, docVerify);
                    }
                    String message = data.getString("message");
                    Log.d("MutipartResponse", new Gson().toJson(jObj));
                    if (code.equals("1")) {

                        showDialogButton(message);

                    }

                } catch (JSONException e) {
                    new APIUtility(DocVerificationActivity.this).dismissDialog(true);
                    CommonUtils.alert(DocVerificationActivity.this, e.getMessage().toString());
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                new APIUtility(DocVerificationActivity.this).dismissDialog(true);

//                CommonUtils.alert(DocVerificationActivity.this,error.getStackTrace().toString());
            }
        })

        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                params.put("user_id", user_id);
                params.put("document_type", documentType);

                Log.d("MultipartRequest", new Gson().toJson(params));

                return params;


            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                if (image != null) {
                    params.put("id_image", new DataPart("User_profile.jpg", image, "image/jpeg"));
                }
                return params;
            }

        };

        multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                40000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        VolleySingleton.getInstance(DocVerificationActivity.this).addToRequestQueue(multipartRequest);


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {

            if (requestCode == 1) {

                Bitmap imageBitMap = (Bitmap) data.getExtras().get("data");
                Uri uri = getImageUri(DocVerificationActivity.this, imageBitMap);
                String path = getRealPathFromURI(uri);
                imageView.setImageURI(uri);


            } else if (requestCode == 0) {
                Bitmap imageBitMap = MediaStore.Images.Media.getBitmap(DocVerificationActivity.this.getContentResolver(), data.getData());
                Uri uri = getImageUri(DocVerificationActivity.this, imageBitMap);
                String path = getRealPathFromURI(uri);
                Log.d("dfgh", String.valueOf(path));
                imageView.setImageURI(uri);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Uri getImageUri(Context context, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage, "Title", null);
        image = bytes.toByteArray();
        return Uri.parse(path);
    }

    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = this.getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            return contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(idx);
        }
    }

    private void selectPicture() {
        final CharSequence[] options = {"Take Photo", "Choose from Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(DocVerificationActivity.this);
        builder.setTitle("Select Profile Photo From");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo")) {
                    if ((ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                        ActivityCompat.requestPermissions(DocVerificationActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                    } else {
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, 1);
                    }
                } else if (options[item].equals("Choose from Gallery")) {
                    if ((ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                        ActivityCompat.requestPermissions(DocVerificationActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
                    } else {
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);
                    }
                }
            }
        });
        builder.show();

    }


    public void showDialogButton(String message) {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your document is uploaded successfully you will receive approval via email after verification.")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(DocVerificationActivity.this, DashBoardActivity.class);
                        intent.putExtra("come", "Doc");
                        startActivity(intent);
                        finish();

                    }
                });
        builder.create();
        builder.show();

    }


}
