package com.ripenapps.rehntu.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.WalletAdapter;
import com.ripenapps.rehntu.models.walletamount.request.GetWalletRequest;
import com.ripenapps.rehntu.models.walletamount.response.GetWalletWrapper;
import com.ripenapps.rehntu.models.walletamount.response.WalletModel;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.facebook.FacebookSdk.getApplicationContext;

public class EarnFragment extends Fragment {
    View view;
    APIUtility apiUtility;
    private RecyclerView recyclerView;
    private Context context;
    private WalletAdapter adapter;
    private String user_id;
    private LinearLayoutManager layoutManager;
    private ArrayList<WalletModel> walletModels = new ArrayList<>();
    private String convertedTime;
    private TextView nodatafound;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_tab, container, false);
        context=getActivity();
        Log.e("call1","fragm");

        init();
        return view;

    }

    private  void init(){
        recyclerView=(RecyclerView)view.findViewById(R.id.wallet_recyclerview);
        apiUtility=new APIUtility(getContext());
        user_id= Preferences.getPreference(getApplicationContext(), PrefEntity.USERID);
        nodatafound=(TextView)view.findViewById(R.id.no_datafound);



        getwalletAmount();


    }

    private void setAdapter(ArrayList<WalletModel> walletModel){

        adapter=new WalletAdapter(getApplicationContext(),walletModel);
        recyclerView.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter.notifyDataSetChanged();

    }

    private String getConvertedTimeReverse(String strDate){

        try {

            SimpleDateFormat sourceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");


            Date date = sourceDateFormat.parse(strDate);


            SimpleDateFormat targetDateFormat = new SimpleDateFormat("dd-MMMM-yyyy");
            convertedTime=targetDateFormat.format(date);



        } catch ( ParseException e) {
            e.printStackTrace();
        }

        return  convertedTime;
    }


    private void getwalletAmount() {

        GetWalletRequest amount = new GetWalletRequest();
        amount.setType("earn");
        amount.setUser_id(Preferences.getPreference(getContext(), PrefEntity.USERID));
        Gson gson=new Gson();
        Log.e("gsonreq",""+gson.toJson(amount));

        apiUtility.displayAllAmount(context, amount, true, new APIUtility.APIResponseListener<GetWalletWrapper>() {


            @Override
            public void onReceiveResponse(GetWalletWrapper response) {
                Gson gson=new Gson();
                Log.e("gsonres",""+gson.toJson(response)+" "+response.getResponse().getGetWalletResult().getAll().size());
                walletModels.clear();

                if (response.getResponse().getGetWalletResult().getAll().size()>0){


                for (int i=0;i<response.getResponse().getGetWalletResult().getAll().size();i++) {
                    Log.e("status", "" + response.getResponse().getGetWalletResult().getAll().get(i).get("status").getAsBoolean());

                    Boolean status = response.getResponse().getGetWalletResult().getAll().get(i).get("status").getAsBoolean();
                    String user_name = response.getResponse().getGetWalletResult().getAll().get(i).get("user_name").getAsString();
                    String earningDate = response.getResponse().getGetWalletResult().getAll().get(i).get("earningDate").getAsString();
                    String service_name = response.getResponse().getGetWalletResult().getAll().get(i).get("service_name").getAsString();
                    Float walletAmount;
                    walletAmount = response.getResponse().getGetWalletResult().getAll().get(i).get("walletAmount").getAsFloat();
                    getConvertedTimeReverse(earningDate);


                    walletModels.add(new WalletModel(user_name, service_name, walletAmount.toString(), status, convertedTime));
                    setAdapter(walletModels);

                }

                }
                else {
                    nodatafound.setVisibility(View.VISIBLE);
                    nodatafound.setText("No wallet found");
                }

            }

            @Override
            public void onResponseFailed() {

            }

            @Override
            public void onStatusFalse(GetWalletWrapper response) {
                nodatafound.setVisibility(View.VISIBLE);
                nodatafound.setText("No wallet found");


            }
        });
    }

}
