package com.ripenapps.rehntu.models.payment.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.paymentSession.request.amount;

public class PaymentResultValue {

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    @SerializedName("resultCode")
    String resultCode;

    public String getPspReference() {
        return pspReference;
    }

    public void setPspReference(String pspReference) {
        this.pspReference = pspReference;
    }

    @SerializedName("pspReference")
    String pspReference;

    @SerializedName("refusalReason")
    String refusalReason;

    @SerializedName("refusalReasonCode")
    String refusalReasonCode;

    @SerializedName("shopperLocale")
    String shopperLocale;
//
//    @com.google.gson.annotations.SerializedName("additionalData")
//    additionalData add=new additionalData();

    @SerializedName("paymentMethod")
    String paymentMethod;


    public String getShopperLocale() {
        return shopperLocale;
    }

    public void setShopperLocale(String shopperLocale) {
        this.shopperLocale = shopperLocale;
    }



    public String getRefusalReason() {
        return refusalReason;
    }

    public void setRefusalReason(String refusalReason) {
        this.refusalReason = refusalReason;
    }

    public String getRefusalReasonCode() {
        return refusalReasonCode;
    }

    public void setRefusalReasonCode(String refusalReasonCode) {
        this.refusalReasonCode = refusalReasonCode;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }


//    public additionalData getAdd() {
//        return add;
//    }
//
//    public void setAdd(additionalData add) {
//        this.add = add;
//    }





}


