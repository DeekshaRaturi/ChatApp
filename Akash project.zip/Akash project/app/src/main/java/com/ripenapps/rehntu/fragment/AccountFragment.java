package com.ripenapps.rehntu.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.my_screen.AccountVerificationActivity;
import com.ripenapps.rehntu.my_screen.BankAccountDetailsActivity;
import com.ripenapps.rehntu.my_screen.EditProfileActivity;
import com.ripenapps.rehntu.my_screen.TransactionHistoryActivity;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import java.io.ByteArrayOutputStream;

import de.hdodenhof.circleimageview.CircleImageView;

public class AccountFragment extends Fragment implements View.OnClickListener{

    View view;
    APIUtility apiUtility;
    TextView logout,txt_name,txt_email,txt_phno;
    AccountCallback callback;
    private CardView setting_cardview,account_cardview,credit_card_cardview,transaction_cardView,accountdetail_cardview;
    private Context mcontext;
    private ImageView img_edit;
    private CircleImageView profile_img;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_account, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
        return view;
    }

    private void InitView() {


        setting_cardview=(CardView)view.findViewById(R.id.setting_cardview);

        img_edit=(ImageView)view.findViewById(R.id.img_edit);
        account_cardview=(CardView)view.findViewById(R.id.account_cardview);
       // credit_card_cardview=(CardView)view.findViewById(R.id.credit_card_cardview);
        transaction_cardView=(CardView)view.findViewById(R.id.transaction_cardView);
        accountdetail_cardview=(CardView)view.findViewById(R.id.accountdetail_cardview);
        profile_img=(CircleImageView)view.findViewById(R.id.profile_img);

        txt_name=(TextView)view.findViewById(R.id.txt_name);
        txt_email=(TextView)view.findViewById(R.id.txt_email);
        txt_phno=(TextView)view.findViewById(R.id.txt_phno);

        txt_name.setText(Preferences.getPreference(getContext(), PrefEntity.USER_NAME));
        txt_email.setText(Preferences.getPreference(getContext(), PrefEntity.USER_EMAIL));
        txt_phno.setText(Preferences.getPreference(getContext(),PrefEntity.PHONE_NUMBER));

        String profileimageView=Preferences.getPreference(getContext(),PrefEntity.PROFILE_IMAGE);
        Log.e("imgv1",""+profileimageView);


        Uri imageUri = Uri.parse(profileimageView);
        Log.e("imgv",""+imageUri);

        profile_img.setImageURI(imageUri);




        setting_cardview.setOnClickListener(this);
        accountdetail_cardview.setOnClickListener(this);
        //credit_card_cardview.setOnClickListener(this);
        transaction_cardView.setOnClickListener(this);
        account_cardview.setOnClickListener(this);
        img_edit.setOnClickListener(this);


//        logout=(TextView)view.findViewById(R.id.logout);
//        logout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//               callback.doLOgout();
//
//            }
//        });
    }

    @Override
    public void onClick(View v)
    {

        switch (v.getId()){

            case R.id.account_cardview:{

                Intent intent=new Intent(getContext(), AccountVerificationActivity.class);
                startActivity(intent);

            }
            break;

            case R.id.transaction_cardView:{

                Intent intent=new Intent(getContext(), TransactionHistoryActivity.class);
                startActivity(intent);
            }
            break;

            case R.id.img_edit:{

                Intent intent=new Intent(getContext(), EditProfileActivity.class);
                startActivityForResult(intent,1400);

            }
            break;
            case R.id.accountdetail_cardview:{

                Intent intent=new Intent(getContext(), BankAccountDetailsActivity.class);
                startActivity(intent);
            }

        }




    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == 1400) {

                Log.e("path",data.getStringExtra("path")+" "+data);
                String name=data.getStringExtra("name");
                Uri imgUri=Uri.parse(data.getStringExtra("path"));
                txt_name.setText(name);
                profile_img.setImageURI(imgUri);

            }
        }

    }

    private Uri getImageUri(Context context, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }


    public   interface AccountCallback{
        void doLOgout();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            callback=(AccountCallback)context;

        }catch (Exception
                e){

        }
    }
}
