package com.ripenapps.rehntu.my_screen

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.nfc.tech.MifareUltralight.PAGE_SIZE
import android.os.Build
import android.os.Handler
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.app.FragmentActivity
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.CardView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.adyen.checkout.core.*
import com.adyen.checkout.core.handler.StartPaymentParametersHandler
import com.adyen.checkout.ui.CheckoutController
import com.adyen.checkout.ui.CheckoutSetupParameters
import com.adyen.checkout.ui.CheckoutSetupParametersHandler
import com.google.gson.Gson

import com.kunzisoft.switchdatetime.SwitchDateTimeDialogFragment
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.ChatAdapterr
import com.ripenapps.rehntu.models.acceptDeclineChat.request.AcceptDeclineRequest
import com.ripenapps.rehntu.models.acceptDeclineChat.response.AcceptDeclineWrapper
import com.ripenapps.rehntu.models.chat.request.ChatRequest
import com.ripenapps.rehntu.models.chat.response.Chat
import com.ripenapps.rehntu.models.chat.response.GetChatResponseWrapper
import com.ripenapps.rehntu.models.payment.request.Payment
import com.ripenapps.rehntu.models.payment.response.PaymentWrapperValue
import com.ripenapps.rehntu.models.paymentSession.request.PaymentRequest
import com.ripenapps.rehntu.models.paymentSession.response.PaymentWrapper
import com.ripenapps.rehntu.my_util.*
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import org.json.JSONException
import org.json.JSONObject

import java.net.URISyntaxException
import java.text.SimpleDateFormat

import io.socket.client.IO
import io.socket.client.Socket
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper
import java.text.ParseException
import java.util.*
import kotlin.collections.ArrayList


class ChatActivity : FragmentActivity(), View.OnClickListener, OnClicklistener {


    private var butn_make0ffer: Button? = null
    private var butn_date: Button? = null
    private var txt_booknow: TextView? = null
    private val socket_url = "http://18.216.101.125:3000"
    private var mcontext: Context? = null
    private var mSocket: Socket? = null
    private var butn_send: ImageView? = null
    private var edt_send: EditText? = null
    private var `object`: Any? = null
    private var chatArrayList: ArrayList<Chat>? = null
    private var convertedTime: String? = null
    private var rate_type:String?=null

    private var msg: String? = null
    private var transaction_id: String? = ""

    private var mYear: Int = 0
    private var mMonth: Int = 0
    private var mDay: Int = 0
    private var servicetype: String? = null
    private var serviceId: String? = null
    private var service_name: String? = null
    private var serviceprovidername: String? = null
    private var buyer_id: String? = null
    private var apiUtility: APIUtility? = null
    private var title: AppCompatTextView? = null
    private var back: ImageView? = null
    private var txt_status: TextView? = null

    var recyclerView: RecyclerView? = null
    var viewAdapter: ChatAdapterr? = null;
    var viewManager: RecyclerView.LayoutManager? = null;
    var time: String? = null
    var onClicklistener: OnClicklistener? = this

    var mLayoutManager: LinearLayoutManager? = null
    var last_text_edit: Long = 0
    var handler = Handler()

    var service_date: String? = null
    var service_time: String? = null
    var product_from: String? = null
    var product_to: String? = null

    var isbuyer: String? = null
    var status: String? = null
    var status_layout: RelativeLayout? = null

    var msg_id: ArrayList<String>? = ArrayList()
    var butn_status_booknow1: LinearLayout? = null
    var side_img: ImageView? = null

    var butn_status_booknow: TextView? = null

    var txt_status_value: TextView? = null

    var price_text: TextView? = null

    var swiper:SwipeRefreshLayout?=null

    var price: Int? = null
    var datetime:String?=null


    var price_value: Int? = null
    var status_value: String? = null
    var recievername: String? = null

    var img_price: ImageView? = null

    var first_date:String?=" "

    var local_time: String? = null
    var status_cardview: CardView? = null
    var encode_data:String?="eyJjaGVja291dHNob3BwZXJCYXNlVXJsIjoiaHR0cHM6XC9cL2NoZWNrb3V0c2hvcHBlci10ZXN0LmFkeWVuLmNvbVwvY2hlY2tvdXRzaG9" +
            "wcGVyXC8iLCJkaXNhYmxlUmVjdXJyaW5nRGV0YWlsVXJsIjoiaHR0cHM6XC9cL2NoZWNrb3V0c2hvcHBlci10ZXN0LmFkeWVuLmNvbVwvY2hlY2tvdXRzaG9wcGVyXC9zZ" +
            "XJ2aWNlc1wvUGF5bWVudEluaXRpYXRpb25cL3YxXC9kaXNhYmxlUmVjdXJyaW5nRGV0YWlsIiwiZ2VuZXJhdGlvbnRpbWUiOiIyMDE5LTAzLTE0VDA5OjU3OjE2WiIsImluaXRpYXRpb25VcmwiOiJodHRwczpcL1wvY2hlY2tvdXRzaG9wcGVyLXRlc3QuYWR5ZW4uY29tXC9jaGVja291dHNob3BwZXJcL3NlcnZpY2VzXC9QYXltZW50SW5pdGlhdGlvblwvdjFcL2luaXRpYXRlIiwicGF5bWVudCI6eyJhbW91bnQiOnsiY3VycmVuY3kiOiJVU0QiLCJ2YWx1ZSI6MTB9LCJjb3VudHJ5Q29kZSI6Ik5MIiwicmVmZXJlbmNlIjoiMmgwN2YzZ2kiLCJyZXR1cm5VcmwiOiJjaGVja291dDpcL1wvY29tLnJpcGVuYXBwcy5yZWhudHUiLCJzZXNzaW9uVmFsaWRpdHkiOiIyMDE5LTAzLTE0VDEwOjU4WiIsInNob3BwZXJMb2NhbGUiOiJubF9OTCIsInNob3BwZXJSZWZlcmVuY2UiOiJ5b3VyU2hvcHBlcklkX0lPZlczazlHMlB2WEZ1MmoifSwicGF5bWVudERhdGEiOiJBYjAyYjRjMCFCUUFCQWdCQTVncW81a2NUOXVxS2ZISWFiRHcxcE5yT05qWFhEMmpKY3dnY1A0MkxNT1wvRGNQdXBcL0NCeG5UR1BzOWo5bnNsTGhGazJDQyt4dkxlRDlHREI2dFFNMm5iQzNScWExY0w3T0dmSkhWTlNRdGk3czFOYVwvXC80d3VEXC8xaVl0bWlvSmlQczdBUkJaMzd0NTFFK0tKSkVSYlk1UzdOc2JscUhhMVhjUW84YUdvTVwvTGJqREJYbTF6anFtOXpTZ2hOeGZ0SFI4bE5SbGNWcEZTUDNcL0RHeU5FSXFRaUI5REhUZXlZcFd0ZkNINFwvZXFWdjdheDVPVTZqMDdSMjE5emxhbUdWQzRBVVdMcXU0ZXFoVDZWRzdTajZBbFppNkl1XC9UcGhocXFTdlRleDBxM2ZxTjZaZlhUNHJhc1JyMERMRTRtcU5hOUlkc0VEXC8zQTdHUjlkN293bUNrRmJQdDJUUGtpSEFZaVM5WkFrMlAweVFYejR5eDZ5WTkwYk82XC9YZEtXRk8zWjhUWVRMNm1MT0swd1prZXRBVmYyUGN6SEt5S2ZoQzlaNVV0cjR4M1wvb3ZEZTJpSjhrdU1pMnowVzI3WGg3NllmSFZEZWVcL3c2OWNxTThZUFJZMFpXSDdCS2F5XC9RVmw5MVZFNElnUzlCTm5cL2xsNTZieXhMaTFUN2V4dVNDVDlsbjZpUEYxcjV4NVc2VDNZMFZPQXhjY0xsVWRHYml2TWhqdmxHNm5oRlo0clFCWGZhMGVUTDRKNXVkSUFyUkJrYVowdWdCS0ZqVHE0blJHOHptT3dmSjEwMTcxVXpoTEE4ZjlOaGd5R0pjYjlvN1dkMHM5OFJxWFwvUHJSUnhkXC85YVJBZGh3ZXpZTGNlcktPN2lcLzc1eUVDOGVpckJaQUFiMUJsUWhlQitKS3hEZGYrTG5ZbFBnNGR6R1pjXC9nOWFqUEFFcDdJbXRsZVNJNklrRkdNRUZCUVRFd00wTkJOVE0zUlVGRlJEZzNRekkwUkVRMU16a3dPVUk0TUVFM09FRTVNak5GTXpneU0wUTJPRVJCUTBNNU5FSTVSa1k0TXpBMVJFTWlmWTBxdTVWTGlDWWFvRmx6Qm9jaEo1bUV4cXlkRG56MU1JNThIMnlhUHZcLzhqbXBSS1NERURKXC84eTJIWmVGemtvSmpvQXpvR3RucHNuc2d3Q0VndDRKcXdkeHFNektseFwvU2hKWTNWUjZSN1k0Wnhya1ZlOU1rK1M5M0pYckJDS25qZTg1Zm5hbTluaXJCcVwvUElYQmNQY0U2ZWthVml5SnJUUDVweXdNZERGUzcwVkwzYnQ3ZzJzd3hjRlp2T0QyRjdjZ25pRHBoOGE4Njc4U3ZDV3pwamVKd2tIM2JCWERjUTlZajh3VFZsc09KMHdmSGRyWnpPeSsrN0VsZ21hb1hkcU9vT3FDMFRWa3puKzJUYmlNdmVyQWwzelptRktrQ1VTNXpVcGhyXC9ieGFjVFIwaHdVNlVOcittcXI0eWtVbit4VTNzY2ZkeGFWMkk5Y015aVRYUVdUQ1VGNDhQVjlqOVFjYVVVdzN6UU5NdjluS0phSGw3U1V6OFwvMjBvUkxPZDBZaU1LZ3hFXC9TR2FnSGRnRUdUNzNHNlVWcmxuXC9jd0ZvSkliWEVCWmZWYVRGZG9FbHJRN0VPWTZ6ZHpIalp5NEsxUzZMclNiRkhsMngzOGFaNUM2Y1RzcU9EYVhDckV1R05rdGYrQzBPMlZybXpUZUd1WENZb1B6bnZ5RmZFTVYrdGxhb3JhVFZGbE0xN2JTbU9vaktPRXNvR0hMb0ZSQVQydnNYRjNlbW9IQUtYSERFTVVmdUNrMTJFQlRTTUdFNHhpbEVJRHF6UFROMHlCR25QNWh3WTVlYkVqOWJWUzdQNWVZd1wvYVlZaWNFYmJoenRabzlETjVFa1wvOTdCSWFHSHVET0V4VENEZm5cLzdBNmF4XC9kXC9UVnJKM3Z2NDFcL3BWbU9Ld28rRzV4Qlo2OUdTVG5zMGZoNjlCMXIwVGN1UEZIWHFwYWJzMWRBOUJJSHp3Y0drbFpPU1JQMDZJaTg2MkRaTHFsUXRCNVYrWmJPbWRGVUVKSjZlbFBVQkRSeGtPanQ1WlRLNnZWNmtQaXJ1MGRJR0JHNENQZzVQRFZGU243OCsybzBkRXE5MWVud1BNUDVCRjlGWkx2b3FEZHZ3SFU1MXBxYnJCaTI5bE1GWjROY0xJcHAzTkk4ajloNXBMcWV3clZ5YzFNV2NZSDJVRnNlcUNYOTl6blwvckJ5YWdnWVZPRkIySTNSVlAxMWVBRzIzelh3K0M0aWFMZ29ZbVZ2Y0pEYUhCeGc5cU9BNExFcWcySmV3VjFSWnVOd1NmU0N2aFhJN1FPREhRVnZvWHRsb3FWaTFQenJuZUJkMzJBY2JXV1dsR1BhaFFua1BwVG5FN0lYTHRGNjFTQTl1d2tDVERxK2Y3V3VmTURuYzl1a3g2RXVsYW81WEdZcHdVMitXQStUWTU0VDVVWGx4VXFSUGRvQUVJU0ZYK0pQTFlSWFwvTk5EbXJLN0Q4cFwvY2dHeDZZTXc2dTBsQzY5bEdDWjdhVm1zU0V2R0g0OXFnMUlhN0JmdWhpMDErTlwvZjRzZnpOeElhSThJb2VMNlZKTjdHY1ErYlA2UkRJT0NuVTZmKzFwbVhjN2pIZzlGVitwb051YXFwVDBhMmRoK0l2ZEpEc3U1TFJJam9NbzlKbyIsInBheW1lbnRNZXRob2RzIjpbeyJkZXRhaWxzIjpbeyJrZXkiOiJlbmNyeXB0ZWRDYXJkTnVtYmVyIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkU2VjdXJpdHlDb2RlIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkRXhwaXJ5TW9udGgiLCJ0eXBlIjoiY2FyZFRva2VuIn0seyJrZXkiOiJlbmNyeXB0ZWRFeHBpcnlZZWFyIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5Ijoic3RvcmVEZXRhaWxzIiwib3B0aW9uYWwiOnRydWUsInR5cGUiOiJib29sZWFuIn1dLCJncm91cCI6eyJuYW1lIjoiQ3JlZGl0IENhcmQiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0JcL1FrOVhBOEUzakdpSktFZHNsYjNOcFdFekkwQVhiOWhvM3RFaHBuYXpWaDlzRUd5R1wvdnhZOGhHSHlIN2NGUzJlYmRob2dFeGY5WmRnYXlBb1UwaWF4V0V3RjducmJuMG01SEJWUmlmM1VkcEp5Y1ZvMFZUbWZwR3FSZTJsdFg4WkxIU0NHXC9lb1FycDlDVUVGUFB6TEZhUUFnc0lxa2lrRFIzajlyeUV6NzBHUDlNV1B3TTZ6YU9PK0xoR01HSXBhSEFsOG1qWkg5eng3bE1wQ2l6MHFBVkpaa3ErdGpEMjJSTzd6ZGRHUnhrUDljXC8zb1ltNUpNK1VjaDc3eUxUeTBnSElGcDY1b1hlNERtVWFKbTllb1c5TER0VFNWbW5NN1pxWlNGZWRjSXd3eU95UFpkdXVcL1dZNWZld2Z4VVRqNVFTVDZuN0JZK0JEK0FWWjNmZEk5d0h0eWVwcnJcL0pNSHhpbnR0ckxcLzJDY0ZRbWZ6OUtGZVJpNDUrN0NRV0RlYkcyYUlEV0dVdVpYa1RTdzBHdGsxeEFvMEIrTWhsNERMWmpITmhUY2JId3RhNHlaUTFUV1FRb28rc1wvNkdpNmZQTkNra0NvYlhVYktuVDRMM2ZIckoyRnZXUnVZcDBaWDdtOHdvRjlUZTd4MjlPbWdWUk9YZHl1N2RoR1hFa0VFaU5yY1NSR3hVQjhcL0NIWHphSCt6eFZnckRWSXMxUmh1Wm1QcFVHNEFBRmhuZHJZdkhCckMrTWJ3TUdLcjhITTMrMFFySDBIQ2lKTlQ2dXNJK3BHSEZtaXI0UWl4TjZvemd5d0daN0ZwVEczM1lrbytQUEVLK2czUnpuaFFoTlRtTXd0bjl1NzF6b0dnMnR3dDdiQmRjcXRKMTdERTVlUkJlQVZcLzV1cEhiK1JCV3pqSHhjYW9WV09wQms3RVZrb25mQUVwN0ltdGxlU0k2SWtGR01FRkJRVEV3TTBOQk5UTTNSVUZGUkRnM1F6STBSRVExTXprd09VSTRNRUUzT0VFNU1qTkZNemd5TTBRMk9FUkJRME01TkVJNVJrWTRNekExUkVNaWZlQzFvUDFTVEVyMDJqTTlcL3dEWkN0OURrYmUxUk9Ta0t1a1pzeVNjK1NsSzFJY0xxRzdnYlR1ZGFNckY5V3JHeEl0N1p6az0iLCJ0eXBlIjoiY2FyZCJ9LCJuYW1lIjoiTWFzdGVyQ2FyZCIsInBheW1lbnRNZXRob2REYXRhIjoiQWIwMmI0YzAhQlFBQkFnQ3A2SnRKb1k0c1Z3RDNVK0lzeTRjbndmRTd1eU1FZk9ONkUyQVo5ckpiZmZLY2pRNzNUZU15d1hsZG9qM2k4aWxpRDhmWFpJNHpmSE5XZTV1d0c0aHhsdFFtRDk1WjNcL3FMdnNYQ3ZkQlhHODJudm9uaVdtRjluazUwazJaQkFxbDErdnVLN2ZTU0lnSjgxOGt4M3k2blFGcHhUbEpXRTFxUkxrV3NwN3JySVpjdG9acFplTG8rN3hwQ1BlQ0M3UnZiRHhublVub3NITFUzNW9XTkFybDAzY1daXC9QZnZqN1puZ2Y2ZWJqaEFxWGlleFJvREw2S1wvbitaV0gxRzJXR3QzbjhvMlJOYlVyWSsrb1VHOTVoM01uV2F6cG54UmRYMGcwdVwvUzFpWUZJWUJOY0EzZm9RbXR0bGFzXC83MGF5MytSbm43U0ZoVWRoMExXeGpEdnVxQnhYMWs3RWJWemozODIzWUcwejdyUllLQnJQakdTblNCMnFOSXVqT0Y5bFJaQlljNDMwVGU0clBwb0pLYjduZGwreVA2bWdIU0tSbFJHd3VvVTFRMDFsS21sMmpMMnpGS25hSnFoQ2VXRUVoWmtxNnFMWlNZdXZnWGh4QXNMeW5Wam1wNU5EK1RTU3A4OGY3TnpjRzZneHpWV0dEOExDeW5LMDNVSVpMQ1NSUHJRRlRvTnhKd3FwVVU5QXk1ekdjU3kwOFhkSlNrclEyQ3BCa2hlNDdXSjh4ZWVBTUdmUXE3RjBqVHdzVUlqNkFwTXJUaHdKSldnSEFxaUZMV0pGbG8rZ2tQbmU1VGgyQ1NcL2ozU3loZFlFOW01aThVdTdDRWZoZ05iVWlUbDRna2NjY28waVNNWFQ4c3hHeEZVNTBcL2FuNW84ZlRSM2c2cElXN3dXc1dSbDlHaERtY0hReWQ5cEVHWXVmR2ZGRnVjaThBRXA3SW10bGVTSTZJa0ZHTUVGQlFURXdNME5CTlRNM1JVRkZSRGczUXpJMFJFUTFNemt3T1VJNE1FRTNPRUU1TWpORk16Z3lNMFEyT0VSQlEwTTVORUk1UmtZNE16QTFSRU1pZmQ1b05iZktJa2U0M3FIcjMzS0lXMzAyS25cL3BWamNZcE4zVXBHekVvKzgrY2J2YzEwTGVweXNYekt2XC93M2hjZ2c9PSIsInR5cGUiOiJtYyJ9LHsiZGV0YWlscyI6W3sia2V5IjoiZW5jcnlwdGVkQ2FyZE51bWJlciIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6ImVuY3J5cHRlZFNlY3VyaXR5Q29kZSIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6ImVuY3J5cHRlZEV4cGlyeU1vbnRoIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkRXhwaXJ5WWVhciIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6InN0b3JlRGV0YWlscyIsIm9wdGlvbmFsIjp0cnVlLCJ0eXBlIjoiYm9vbGVhbiJ9XSwiZ3JvdXAiOnsibmFtZSI6IkNyZWRpdCBDYXJkIiwicGF5bWVudE1ldGhvZERhdGEiOiJBYjAyYjRjMCFCUUFCQWdCXC9RazlYQThFM2pHaUpLRWRzbGIzTnBXRXpJMEFYYjlobzN0RWhwbmF6Vmg5c0VHeUdcL3Z4WThoR0h5SDdjRlMyZWJkaG9nRXhmOVpkZ2F5QW9VMGlheFdFd0Y3bnJibjBtNUhCVlJpZjNVZHBKeWNWbzBWVG1mcEdxUmUybHRYOFpMSFNDR1wvZW9RcnA5Q1VFRlBQekxGYVFBZ3NJcWtpa0RSM2o5cnlFejcwR1A5TVdQd002emFPTytMaEdNR0lwYUhBbDhtalpIOXp4N2xNcENpejBxQVZKWmtxK3RqRDIyUk83emRkR1J4a1A5Y1wvM29ZbTVKTStVY2g3N3lMVHkwZ0hJRnA2NW9YZTREbVVhSm05ZW9XOUxEdFRTVm1uTTdacVpTRmVkY0l3d3lPeVBaZHV1XC9XWTVmZXdmeFVUajVRU1Q2bjdCWStCRCtBVlozZmRJOXdIdHllcHJyXC9KTUh4aW50dHJMXC8yQ2NGUW1mejlLRmVSaTQ1KzdDUVdEZWJHMmFJRFdHVXVaWGtUU3cwR3RrMXhBbzBCK01obDRETFpqSE5oVGNiSHd0YTR5WlExVFdRUW9vK3NcLzZHaTZmUE5Da2tDb2JYVWJLblQ0TDNmSHJKMkZ2V1J1WXAwWlg3bTh3b0Y5VGU3eDI5T21nVlJPWGR5dTdkaEdYRWtFRWlOcmNTUkd4VUI4XC9DSFh6YUgrenhWZ3JEVklzMVJodVptUHBVRzRBQUZobmRyWXZIQnJDK01id01HS3I4SE0zKzBRckgwSENpSk5UNnVzSStwR0hGbWlyNFFpeE42b3pneXdHWjdGcFRHMzNZa28rUFBFSytnM1J6bmhRaE5UbU13dG45dTcxem9HZzJ0d3Q3YkJkY3F0SjE3REU1ZVJCZUFWXC81dXBIYitSQld6akh4Y2FvVldPcEJrN0VWa29uZkFFcDdJbXRsZVNJNklrRkdNRUZCUVRFd00wTkJOVE0zUlVGRlJEZzNRekkwUkVRMU16a3dPVUk0TUVFM09FRTVNak5GTXpneU0wUTJPRVJCUTBNNU5FSTVSa1k0TXpBMVJFTWlmZUMxb1AxU1RFcjAyak05XC93RFpDdDlEa2JlMVJPU2tLdWtac3lTYytTbEsxSWNMcUc3Z2JUdWRhTXJGOVdyR3hJdDdaems9IiwidHlwZSI6ImNhcmQifSwibmFtZSI6IlZJU0EiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0E3OHg2Zno1YTlBWkt2a3JxbERmM0VUZmI3XC9ES1NrVmdwOER1OHdWMHI0d0JGMWRyWGFTeW4zcjZ2em4wMU9NZHozNWx6c1daRllaQldFWVZBMWJUSUd1XC9XdEE2QnVMamtUY2U0Vlg3Vk8weG9uU2hoRkMzV29EZlY3dDlWaUFFK1R0UEE0MVRYcTlyK1UxMnlcL2ZnVHFyVVhRNkN0ak0ySU5XanBvRWFETW9KbzF6S24xbHNhMWVNVUN6S0NvQXZWbXUyS0xXTmRsVTBhYWtBVzhIcllRRExuY2cwT1FtY1hwRllmaDFpNW03YktrZ2VnZXFheE4yOWVrWG1EZnlnZ0ErRklXb1dsSTRjTXB4YzVVRjlTMXlUUFNzVjRyUXBrcGVNejdHMldEeURzZUxvNmZtWnBtR2Q2cVg4U0Nsek1vclBkdk9LYlJCXC9vS2prUGgzZlhkaGVWcEpaaXI0YjlEUGM2b2s5anpBSUZqQ01oN1RFNGxvVEZLY0hcL3JJamN5VGhkQytLTWdZOTd4TG5hc1VJOHA4VXlpK2dMV2V5TmR2ZW9QbnBIbEJiMkttUlFEcHZwSHdxOUxTMnNIMFdmTjZXVUpKYm5rbzFPdjRVSDBROEhuQXlmM2JvRjJVTVBETDRrTmdVY2g5N3FaQjE4bzcwMElGK1JVTnV3NnR2RzZrbk9COHBSbVRNZE4yQVhcL1NnaXVVZktcL1NVTjVPSk1HR1FhS0QranlFXC92MWpxOUhkTE91aTRYVDZkT2QxTHZYM3J5RlBVYmxRUEViYjdiTTliVzdZSXdjcXpIMytTdHFGMkxGRlJtTjFaVzE1MGlrRzlpNldHa1wvcStPTnNjcU9CM3V4RXUxM3JmSEgxdEJDNlBvV3plSXFHbjdMeU5RaitpZzhVTWlcL0JEcFhuc3lFTEh0WFE1Z3FZSFFpbnc4QUVwN0ltdGxlU0k2SWtGR01FRkJRVEV3TTBOQk5UTTNSVUZGUkRnM1F6STBSRVExTXprd09VSTRNRUUzT0VFNU1qTkZNemd5TTBRMk9FUkJRME01TkVJNVJrWTRNekExUkVNaWZkYmVyVkJkXC9qSG1rZkxzTFZpYUJBUWNPaE1SWkh1K1Y3azBSZGNReEV0aktwTkNnNzZDXC9mR2ZQWVo0TnhWV0p5RzkiLCJ0eXBlIjoidmlzYSJ9LHsiZGV0YWlscyI6W3sia2V5IjoiZW5jcnlwdGVkQ2FyZE51bWJlciIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6ImVuY3J5cHRlZFNlY3VyaXR5Q29kZSIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6ImVuY3J5cHRlZEV4cGlyeU1vbnRoIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkRXhwaXJ5WWVhciIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6InN0b3JlRGV0YWlscyIsIm9wdGlvbmFsIjp0cnVlLCJ0eXBlIjoiYm9vbGVhbiJ9XSwiZ3JvdXAiOnsibmFtZSI6IkNyZWRpdCBDYXJkIiwicGF5bWVudE1ldGhvZERhdGEiOiJBYjAyYjRjMCFCUUFCQWdCXC9RazlYQThFM2pHaUpLRWRzbGIzTnBXRXpJMEFYYjlobzN0RWhwbmF6Vmg5c0VHeUdcL3Z4WThoR0h5SDdjRlMyZWJkaG9nRXhmOVpkZ2F5QW9VMGlheFdFd0Y3bnJibjBtNUhCVlJpZjNVZHBKeWNWbzBWVG1mcEdxUmUybHRYOFpMSFNDR1wvZW9RcnA5Q1VFRlBQekxGYVFBZ3NJcWtpa0RSM2o5cnlFejcwR1A5TVdQd002emFPTytMaEdNR0lwYUhBbDhtalpIOXp4N2xNcENpejBxQVZKWmtxK3RqRDIyUk83emRkR1J4a1A5Y1wvM29ZbTVKTStVY2g3N3lMVHkwZ0hJRnA2NW9YZTREbVVhSm05ZW9XOUxEdFRTVm1uTTdacVpTRmVkY0l3d3lPeVBaZHV1XC9XWTVmZXdmeFVUajVRU1Q2bjdCWStCRCtBVlozZmRJOXdIdHllcHJyXC9KTUh4aW50dHJMXC8yQ2NGUW1mejlLRmVSaTQ1KzdDUVdEZWJHMmFJRFdHVXVaWGtUU3cwR3RrMXhBbzBCK01obDRETFpqSE5oVGNiSHd0YTR5WlExVFdRUW9vK3NcLzZHaTZmUE5Da2tDb2JYVWJLblQ0TDNmSHJKMkZ2V1J1WXAwWlg3bTh3b0Y5VGU3eDI5T21nVlJPWGR5dTdkaEdYRWtFRWlOcmNTUkd4VUI4XC9DSFh6YUgrenhWZ3JEVklzMVJodVptUHBVRzRBQUZobmRyWXZIQnJDK01id01HS3I4SE0zKzBRckgwSENpSk5UNnVzSStwR0hGbWlyNFFpeE42b3pneXdHWjdGcFRHMzNZa28rUFBFSytnM1J6bmhRaE5UbU13dG45dTcxem9HZzJ0d3Q3YkJkY3F0SjE3REU1ZVJCZUFWXC81dXBIYitSQld6akh4Y2FvVldPcEJrN0VWa29uZkFFcDdJbXRsZVNJNklrRkdNRUZCUVRFd00wTkJOVE0zUlVGRlJEZzNRekkwUkVRMU16a3dPVUk0TUVFM09FRTVNak5GTXpneU0wUTJPRVJCUTBNNU5FSTVSa1k0TXpBMVJFTWlmZUMxb1AxU1RFcjAyak05XC93RFpDdDlEa2JlMVJPU2tLdWtac3lTYytTbEsxSWNMcUc3Z2JUdWRhTXJGOVdyR3hJdDdaems9IiwidHlwZSI6ImNhcmQifSwibmFtZSI6IkFtZXJpY2FuIEV4cHJlc3MiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0JUU2MxSWFQcFY4RVVEd25PK3JmNkNYSWdEdTljeUpTXC81b0trcDdjMFNwVDlycnExUEszY1FXa1wvQ1wvcU5DMncxR1lYb3FubnFSd2NKWk5JWHlKRXM5ODJwbWo0bEhWa2dwV1JoYUZcL3lWenlKTFBXT1ZySjdSWkhVblZveHZVS0k2aVlrb3pzb2ptYldhTERZelJBb0VHQ1drbzRScHlZWmNBSytJalZMM2k0ZFh0b2JOdlZEcURpbjhtM2tVU2ZDWXNxVEZNUWhSNjM0ZTh0dFdlZDBJeDhzMm8xbjhlS3NRZEd0SDFHSUx0TkRwVFwvT1V6OFN2QWlmRkZ0OUZtMGluQ09mb1R3eEFtVU5SYncyK2IyVGhDXC91dGlCZWxWNU45U3d4WjRxdEUyNFlEMFM3VEg5QlB2Zzk0VlwvOGY1MVVLTGVFbXR6dzNjYURGV3dHMklBRGJCMW85MThWbUkyeFZmOTJSUHo3eklXZkdsQytoNWlJZE9qNDBPS2VUTkJpOFYrOU4wUzQ1OVBrdHIyK0dDWEx1Nk9XYkp5WWdPWWk3ZlVabDdZRzhuZUtwZ1VNMlhCNnAyU3MrNEhxTnFBQkxPank3NEltSGdcL2dHdnpONTJyWkorWklFSTRBQUhDeWEwMGxidXdJT0o0Q1pESllIYlRjdSttSFNjN1Y1SVVuaDV1dHQ4a0tjU1kyQnNFVjlsS3RzMTZwc3VNanBnb2hJNGNmclNsUUNBY0kxSTBmRDZFWTNNMVNkVk1FY3RDSVhKdFhMRjRTZDNMWjJUTkpBeDJlR2pcLzBJWUlCRjY5WFdDd0ltMDFwVWt6NjNraVEzTVlSNUhcL3craThjRmdidFNzZWpHKzVUbytlN1JlOEJ1RWtWUTV0YUViaFNETzNpMGFpV1NrRTh1SGhCZWxYVjhyd2RrY1hSa21XZ0lGMExSQUVwN0ltdGxlU0k2SWtGR01FRkJRVEV3TTBOQk5UTTNSVUZGUkRnM1F6STBSRVExTXprd09VSTRNRUUzT0VFNU1qTkZNemd5TTBRMk9FUkJRME01TkVJNVJrWTRNekExUkVNaWZSYUcyTjluSjRhZDBTdDlOeEg2S09xalwvT2d5a2NGcWxOa1NjejV1ODNteUtQbDRuMEVmQmNwNE5cL1hpV3NiUkJ3SzIiLCJ0eXBlIjoiYW1leCJ9LHsiZGV0YWlscyI6W3sia2V5IjoiZW5jcnlwdGVkQ2FyZE51bWJlciIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6ImVuY3J5cHRlZFNlY3VyaXR5Q29kZSIsIm9wdGlvbmFsIjp0cnVlLCJ0eXBlIjoiY2FyZFRva2VuIn0seyJrZXkiOiJlbmNyeXB0ZWRFeHBpcnlNb250aCIsInR5cGUiOiJjYXJkVG9rZW4ifSx7ImtleSI6ImVuY3J5cHRlZEV4cGlyeVllYXIiLCJ0eXBlIjoiY2FyZFRva2VuIn0seyJrZXkiOiJzdG9yZURldGFpbHMiLCJvcHRpb25hbCI6dHJ1ZSwidHlwZSI6ImJvb2xlYW4ifV0sImdyb3VwIjp7Im5hbWUiOiJDcmVkaXQgQ2FyZCIsInBheW1lbnRNZXRob2REYXRhIjoiQWIwMmI0YzAhQlFBQkFnQlwvUWs5WEE4RTNqR2lKS0Vkc2xiM05wV0V6STBBWGI5aG8zdEVocG5helZoOXNFR3lHXC92eFk4aEdIeUg3Y0ZTMmViZGhvZ0V4ZjlaZGdheUFvVTBpYXhXRXdGN25yYm4wbTVIQlZSaWYzVWRwSnljVm8wVlRtZnBHcVJlMmx0WDhaTEhTQ0dcL2VvUXJwOUNVRUZQUHpMRmFRQWdzSXFraWtEUjNqOXJ5RXo3MEdQOU1XUHdNNnphT08rTGhHTUdJcGFIQWw4bWpaSDl6eDdsTXBDaXowcUFWSlprcSt0akQyMlJPN3pkZEdSeGtQOWNcLzNvWW01Sk0rVWNoNzd5TFR5MGdISUZwNjVvWGU0RG1VYUptOWVvVzlMRHRUU1Ztbk03WnFaU0ZlZGNJd3d5T3lQWmR1dVwvV1k1ZmV3ZnhVVGo1UVNUNm43QlkrQkQrQVZaM2ZkSTl3SHR5ZXByclwvSk1IeGludHRyTFwvMkNjRlFtZno5S0ZlUmk0NSs3Q1FXRGViRzJhSURXR1V1WlhrVFN3MEd0azF4QW8wQitNaGw0RExaakhOaFRjYkh3dGE0eVpRMVRXUVFvbytzXC82R2k2ZlBOQ2trQ29iWFViS25UNEwzZkhySjJGdldSdVlwMFpYN204d29GOVRlN3gyOU9tZ1ZST1hkeXU3ZGhHWEVrRUVpTnJjU1JHeFVCOFwvQ0hYemFIK3p4VmdyRFZJczFSaHVabVBwVUc0QUFGaG5kcll2SEJyQytNYndNR0tyOEhNMyswUXJIMEhDaUpOVDZ1c0krcEdIRm1pcjRRaXhONm96Z3l3R1o3RnBURzMzWWtvK1BQRUsrZzNSem5oUWhOVG1Nd3RuOXU3MXpvR2cydHd0N2JCZGNxdEoxN0RFNWVSQmVBVlwvNXVwSGIrUkJXempIeGNhb1ZXT3BCazdFVmtvbmZBRXA3SW10bGVTSTZJa0ZHTUVGQlFURXdNME5CTlRNM1JVRkZSRGczUXpJMFJFUTFNemt3T1VJNE1FRTNPRUU1TWpORk16Z3lNMFEyT0VSQlEwTTVORUk1UmtZNE16QTFSRU1pZmVDMW9QMVNURXIwMmpNOVwvd0RaQ3Q5RGtiZTFST1NrS3VrWnN5U2MrU2xLMUljTHFHN2diVHVkYU1yRjlXckd4SXQ3WnprPSIsInR5cGUiOiJjYXJkIn0sIm5hbWUiOiJNYWVzdHJvIiwicGF5bWVudE1ldGhvZERhdGEiOiJBYjAyYjRjMCFCUUFCQWdBZWE2bWRVTXNaQkJFcmpTaTJ4eE9KSkYrWTZKNXlGbnNoaXBEYXhQVFBRVVwvNWM1V3lcL3FCbEx0YzNTXC9DQmNGZDB1U25cL0E4YW96dFMwV0tSQTFGRlQyU2xhaWp2bkJWakgzbTNDWHp2Q1lsNThHN1p5NGlGSGFNMERWZE8rVjM3XC9zMkppK29uV0N0alJGekhnWXlpU29raUJJXC9Ma2p2T3dKT3gwT0h4QTZHbFwvRGMraHdyM1k0cStTV2Mrc1p5cVFPZ0U2NWRpSHhKUTVXYTgzc0thV1NROUNoUFZnWXFuN0JYRlR2XC9PbFZlY1wvWmoraG9ieU14aGN6d1diWnhJRGIzbHFWREhFMU1Ya0ppY1hVS0c5KzNlVDNcL0Z0TDBqU2pFcG9NODFTZWNST2FROTA1ZWRPOWNhZ0dTdllLVjFGM2VqZm5KNW9LXC9xd1VxVHAyVklvSGMxOWxMSnY5QjFOZDNoVWU5b2I3bXBTMXlZOXQ1TDNYOGppR3hQcE5OSk1MQXdSdGZZWERVWVkzWEpSdWI2RWNpWFNlM2V5VVJkK21BOUZ1QjdGQ2NKanhrU0IrakxkclpuYnlPQWFUVUc2MnROVUYzXC8xVHZCVk9RTjJ4Rzk4SFE2QTVaajdLT0FTYU5OY0VCYWxZT1plbitJVFlpS25SWmlNajdmb2NaM0hDNkxqUXU5RnVzYjBlV2o0UEE0dENyWUxnOWhCZmpSbW9qN255dzlBbnplcGdZeERqMUhkUFJwczlRMnpxeFRXXC9sYzdmcEVGbmp1WmlvdjNOaVYydUZQSnVDVVBIdEExekJ0T3FadGhwdGp2RlRLNVhBZUQ4M1FmSDMzamdBb0FETDYxR0N1UlpHQ2UyXC9UZkpZMndDMWVFOVY1RlhVSkxlcXhNMDdGb0Q1QkI3UTFwTHU2NWxjMHhpNXpjREcxRUZBRXA3SW10bGVTSTZJa0ZHTUVGQlFURXdNME5CTlRNM1JVRkZSRGczUXpJMFJFUTFNemt3T1VJNE1FRTNPRUU1TWpORk16Z3lNMFEyT0VSQlEwTTVORUk1UmtZNE16QTFSRU1pZlkxQ1NldEdiVmFsSjdSUE1aMXJ2UDkyS3JoRWhMQzhGUmJ0RzNuOVoyUU5ObEpwWTl5ZjI1SWpCcFwveUdxZVFIZkpBaHNhMyIsInR5cGUiOiJtYWVzdHJvIn0seyJkZXRhaWxzIjpbeyJrZXkiOiJlbmNyeXB0ZWRDYXJkTnVtYmVyIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkU2VjdXJpdHlDb2RlIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkRXhwaXJ5TW9udGgiLCJ0eXBlIjoiY2FyZFRva2VuIn0seyJrZXkiOiJlbmNyeXB0ZWRFeHBpcnlZZWFyIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5Ijoic3RvcmVEZXRhaWxzIiwib3B0aW9uYWwiOnRydWUsInR5cGUiOiJib29sZWFuIn1dLCJncm91cCI6eyJuYW1lIjoiQ3JlZGl0IENhcmQiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0JcL1FrOVhBOEUzakdpSktFZHNsYjNOcFdFekkwQVhiOWhvM3RFaHBuYXpWaDlzRUd5R1wvdnhZOGhHSHlIN2NGUzJlYmRob2dFeGY5WmRnYXlBb1UwaWF4V0V3RjducmJuMG01SEJWUmlmM1VkcEp5Y1ZvMFZUbWZwR3FSZTJsdFg4WkxIU0NHXC9lb1FycDlDVUVGUFB6TEZhUUFnc0lxa2lrRFIzajlyeUV6NzBHUDlNV1B3TTZ6YU9PK0xoR01HSXBhSEFsOG1qWkg5eng3bE1wQ2l6MHFBVkpaa3ErdGpEMjJSTzd6ZGRHUnhrUDljXC8zb1ltNUpNK1VjaDc3eUxUeTBnSElGcDY1b1hlNERtVWFKbTllb1c5TER0VFNWbW5NN1pxWlNGZWRjSXd3eU95UFpkdXVcL1dZNWZld2Z4VVRqNVFTVDZuN0JZK0JEK0FWWjNmZEk5d0h0eWVwcnJcL0pNSHhpbnR0ckxcLzJDY0ZRbWZ6OUtGZVJpNDUrN0NRV0RlYkcyYUlEV0dVdVpYa1RTdzBHdGsxeEFvMEIrTWhsNERMWmpITmhUY2JId3RhNHlaUTFUV1FRb28rc1wvNkdpNmZQTkNra0NvYlhVYktuVDRMM2ZIckoyRnZXUnVZcDBaWDdtOHdvRjlUZTd4MjlPbWdWUk9YZHl1N2RoR1hFa0VFaU5yY1NSR3hVQjhcL0NIWHphSCt6eFZnckRWSXMxUmh1Wm1QcFVHNEFBRmhuZHJZdkhCckMrTWJ3TUdLcjhITTMrMFFySDBIQ2lKTlQ2dXNJK3BHSEZtaXI0UWl4TjZvemd5d0daN0ZwVEczM1lrbytQUEVLK2czUnpuaFFoTlRtTXd0bjl1NzF6b0dnMnR3dDdiQmRjcXRKMTdERTVlUkJlQVZcLzV1cEhiK1JCV3pqSHhjYW9WV09wQms3RVZrb25mQUVwN0ltdGxlU0k2SWtGR01FRkJRVEV3TTBOQk5UTTNSVUZGUkRnM1F6STBSRVExTXprd09VSTRNRUUzT0VFNU1qTkZNemd5TTBRMk9FUkJRME01TkVJNVJrWTRNekExUkVNaWZlQzFvUDFTVEVyMDJqTTlcL3dEWkN0OURrYmUxUk9Ta0t1a1pzeVNjK1NsSzFJY0xxRzdnYlR1ZGFNckY5V3JHeEl0N1p6az0iLCJ0eXBlIjoiY2FyZCJ9LCJuYW1lIjoiRGluZXJzIENsdWIiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0NWckFvQXpIeGQxcFJZRlo5b2hZYkZlQXlKbmdjbG9KdjZsaFl2VjlpNFwvNmRcL3h6QmNpd0VYak5FWnpzdncyWHp5blwvTjFRZ0xzUVJxNWFXOEtwWEZXV05MbjZcL1AySjVFSmMzbFJjOWRycXo1VW9jMGVoWU8wbFZmVFhtQTFaMDFlUFNSOGZnSXg4a0o4M0tOd3N2Z0JTeXhDTUtldVduZTFCZlNvakkyU09GS1N0OU9uSGRYUVNobUxBcHA3S3RIU3BlSm91QUd3XC9pSzBPN29vc2J0TzNQNVwvOEdnK3BBeHNsOVFGdm00XC9XOWlnYVNjZklFaFwvQnYrbDluVU1vQWVRbDNpXC9PQzAyalA5eXdHZGt5NStMR1JXMURDdFNTMitqTURTVHJ2VkdaREJcL0F3cHlYdDhkYnNDWWk5T1wvcHUzXC9nVWNudGVGYkVaVW9Ra0phQXloYVdQWGk5Q3hyVVhhZlo1RWNNbkNvcGtcL0V2S1d3MWxRUnNSN0YyakdlK2dzSEFyUTF6UkQ0akUwQ1J0Q0JUeGswdDlhWVFEa1oxS0ozOUVxMVlOYmFzcGtOR3dzNURxaGdJc1RhbVZIYVY3QUQ5ZGlRemNlRlwvY3VFNHR2TTZXQkY4ZjlsS1R1Nkp6c1krTWFRa1FmYWdMN1d2WGJLSGZjTmEwNUNxNktFMmJQcnFOMjFKRnpvXC96M2xDTUF2VXNZMXRXUFZuUWFCMkJ2V3pCZTg0WEtQU2VhK2ptTTZ5ZXBLa1ZGQmNrbGNKVTJIcmpFSlFGR05GZXhTcXBOWm05aEdWSml0anVMV3d3M0E0d3FmclB2VWx1eTlpYWVOQjY0anhpSmpSV2d5UHNqXC9hUjhWV092VUpUY2srVlIyOVwvWGpYbmM0cGpYeFNwdEJrKzZCc1ZlTmFSRE11bHhjTDVVek1HbVdra2FvOHNVRUFFcDdJbXRsZVNJNklrRkdNRUZCUVRFd00wTkJOVE0zUlVGRlJEZzNRekkwUkVRMU16a3dPVUk0TUVFM09FRTVNak5GTXpneU0wUTJPRVJCUTBNNU5FSTVSa1k0TXpBMVJFTWlmWllVTElXRVZuQWNuOTNxaCsyTElnZW1vQ0V0Z1F4ajZcL1wvcUROSUwwdXkrNWl2bzhtd1wvQ2dOMk5Oclp5WitLcndrY3M5dz0iLCJ0eXBlIjoiZGluZXJzIn0seyJkZXRhaWxzIjpbeyJrZXkiOiJlbmNyeXB0ZWRDYXJkTnVtYmVyIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkU2VjdXJpdHlDb2RlIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5IjoiZW5jcnlwdGVkRXhwaXJ5TW9udGgiLCJ0eXBlIjoiY2FyZFRva2VuIn0seyJrZXkiOiJlbmNyeXB0ZWRFeHBpcnlZZWFyIiwidHlwZSI6ImNhcmRUb2tlbiJ9LHsia2V5Ijoic3RvcmVEZXRhaWxzIiwib3B0aW9uYWwiOnRydWUsInR5cGUiOiJib29sZWFuIn1dLCJncm91cCI6eyJuYW1lIjoiQ3JlZGl0IENhcmQiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0JcL1FrOVhBOEUzakdpSktFZHNsYjNOcFdFekkwQVhiOWhvM3RFaHBuYXpWaDlzRUd5R1wvdnhZOGhHSHlIN2NGUzJlYmRob2dFeGY5WmRnYXlBb1UwaWF4V0V3RjducmJuMG01SEJWUmlmM1VkcEp5Y1ZvMFZUbWZwR3FSZTJsdFg4WkxIU0NHXC9lb1FycDlDVUVGUFB6TEZhUUFnc0lxa2lrRFIzajlyeUV6NzBHUDlNV1B3TTZ6YU9PK0xoR01HSXBhSEFsOG1qWkg5eng3bE1wQ2l6MHFBVkpaa3ErdGpEMjJSTzd6ZGRHUnhrUDljXC8zb1ltNUpNK1VjaDc3eUxUeTBnSElGcDY1b1hlNERtVWFKbTllb1c5TER0VFNWbW5NN1pxWlNGZWRjSXd3eU95UFpkdXVcL1dZNWZld2Z4VVRqNVFTVDZuN0JZK0JEK0FWWjNmZEk5d0h0eWVwcnJcL0pNSHhpbnR0ckxcLzJDY0ZRbWZ6OUtGZVJpNDUrN0NRV0RlYkcyYUlEV0dVdVpYa1RTdzBHdGsxeEFvMEIrTWhsNERMWmpITmhUY2JId3RhNHlaUTFUV1FRb28rc1wvNkdpNmZQTkNra0NvYlhVYktuVDRMM2ZIckoyRnZXUnVZcDBaWDdtOHdvRjlUZTd4MjlPbWdWUk9YZHl1N2RoR1hFa0VFaU5yY1NSR3hVQjhcL0NIWHphSCt6eFZnckRWSXMxUmh1Wm1QcFVHNEFBRmhuZHJZdkhCckMrTWJ3TUdLcjhITTMrMFFySDBIQ2lKTlQ2dXNJK3BHSEZtaXI0UWl4TjZvemd5d0daN0ZwVEczM1lrbytQUEVLK2czUnpuaFFoTlRtTXd0bjl1NzF6b0dnMnR3dDdiQmRjcXRKMTdERTVlUkJlQVZcLzV1cEhiK1JCV3pqSHhjYW9WV09wQms3RVZrb25mQUVwN0ltdGxlU0k2SWtGR01FRkJRVEV3TTBOQk5UTTNSVUZGUkRnM1F6STBSRVExTXprd09VSTRNRUUzT0VFNU1qTkZNemd5TTBRMk9FUkJRME01TkVJNVJrWTRNekExUkVNaWZlQzFvUDFTVEVyMDJqTTlcL3dEWkN0OURrYmUxUk9Ta0t1a1pzeVNjK1NsSzFJY0xxRzdnYlR1ZGFNckY5V3JHeEl0N1p6az0iLCJ0eXBlIjoiY2FyZCJ9LCJuYW1lIjoiRGlzY292ZXIiLCJwYXltZW50TWV0aG9kRGF0YSI6IkFiMDJiNGMwIUJRQUJBZ0EzaGFTZEZWMlwvc0pnQ08yMDZSb0s2eGllZllhU2toSSsyeTNqN2dndHNlalZraFlITGNPTnJvUFA1S0t3dlhQS2VvZFwvaW4zcGJIZVF1bGpVbDNWVWxqYnJLWEUzZUhyUFZrMUd1YlFJM0g3dEJjbXlOWUpJU2ZxazJlTVViOFlNTklic0l4SVBRRXBVUXV1aWE2R2s5ajV6YWVaRGJZSTVKRFFKNEQxcUNiT0NqOHlMNVloTUJ2WnZiMEJ2akxvVzBLeEVsY2tTWEtsMFI5SjMwckh3SWo1Wk5PdUx3R0NFNllMK2RkQmltajBrQnljbkdmME9yZ1ZuV2hkSFlGdnY2cnJ3RlNBT2pjQ09WVjZCam50TExBS29pWFNxTFA5V1wvNDNsS1lOaFpwcVVwWG9YaDA5ditWNVRVU3N2ZnpEcnRBUU5MdHVMUzFKejZoSXdrWEhXVGU5Qmp1YzdpYlhvK1d1d0wzSkdDR3RzeVFGRDJ1RnZzc0JEamJhZGFncm1UU2wrOEJIR0ErS01WSEtlT3B4MXBORVhqVEROVmU0XC9hMHVXSDhJNmhNOTVGczRSbTRCajJcL1dlSGR4N1ZIc3M0ZW1INWJ1eCtlb3dYKzJibTAwcnlNekVMMWJybDRXM1EyVkl3VVVtcXUxYXNqUWNjVjI4RXU2S1wvYk5kZVJBb1wvT1gyVFViMGNDMUo5QUVKTWtIOG95YzhKczdIMVwvNmpXNGhqSkVzc1IyRlNFZzEwa3MyM3gxUjMySEVSOWlWclhJWTRQNWJoTW15NGlTektHSXBZKzluYUtBcVNNeWl1UVc0WFU1c2F3WXJPeG5yY2ZjYjNNNThnQkhNdlNCUG5wRk9sbXVLVVNMalZhK3UwTjRSWkZuNm1zOWptUGF4RW96aFJVbmk4UGl4Q2FRcFR5ZURGcUVQbmh1bFk0dGdEa0FFcDdJbXRsZVNJNklrRkdNRUZCUVRFd00wTkJOVE0zUlVGRlJEZzNRekkwUkVRMU16a3dPVUk0TUVFM09FRTVNak5GTXpneU0wUTJPRVJCUTBNNU5FSTVSa1k0TXpBMVJFTWlmWGZQMUFhVnkrYmN6NFl0MzN0RkhKY1BUb0Z0NVlxSEQrc0Rza2hSTWFxTEJvNFZUNWZ3WGZvVlVzSHozYlpVckNrUVRiR004Zz09IiwidHlwZSI6ImRpc2NvdmVyIn1dLCJwdWJsaWNLZXkiOiIxMDAwMXxCMjZDNTlGODVCNjlGMzhCQzcyQzE3NkYxNkUwRkEzQ0E4OEQ1QUNDQzQ4OThGNTI1RDE2QzIxNkQ3N0RFRkU1MzcxNUEyQTlFNzA1RkE3RDJERDZBODEwNEIwM0VFRjYyMTcyMTU5Mzk4MkQ1MEQ0NjA2MkM2M0IzMkM1NTJCQTJBMTM1QTAzNDY2N0JERjc5QjVERjlDNTZERDdCMUY5QUY3Njg4MEMzNDhEQzFEQTM2M0MwNDk1MEZCQkU1MjA0N0E5NTJBQTlFMzY0QTVFOTYyNjI2MjNERTZEODY1NEIzQjM2QjNBN0Q1NThFQjFERjE1N0I3RUFGOEZCMjhDMDNDMzcxOTg3NEU5MUMyNTM4NEM5RUVGNTFGMThFMUQ0REM3MkFDMjU4NDZBRDIzREQxRDYxRDdFMUQyQzlFRTg4RkE5Q0YzODlEOUZCM0EyRkI5MUJFOEZGMTg3Nzc0QzEyMkJDOThDQ0Q2RjFCNUI0QzZDREIzOTAzN0RBQkE2MjNCQUY1MEY0QTNGQjhGRkQyQjdERkQ0ODJCRDNGRDUxRDVFMTUwNTdGODUzNDlBRDQ3QUMwNDk5RTRFRjVBRTdEND" +
            "MyQkI2OTEzNjFFRjRCOTc1RTdBQjAwM0QzRDJBNENGNEVGODJFNTEzNDI2REFGNkU5Nzk2RkM5RERBMSIsInNka1ZlcnNpb24iOiIyLjMuMyJ9"


    var progressbar: ProgressBar? = null
    var securityDeposite: String? = null
    var fromdate:Long?=null
    var product_from_date:String?=null
    var product_to_date:String?=null

    var gmtTime:String?=null

    var direction:String?=""


    var TotalItemCount:Int?=20
    var mCurrentPage:Int?=1
    var pageCounter:Int?=0

    var isloading=false
    var islastpage=false


    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)


        butn_status_booknow1 = findViewById(R.id.ll_shape)
        side_img = findViewById(R.id.iv_shape)
        transaction_id = intent.getStringExtra("transaction_id")

        servicetype = intent.getStringExtra("service_type")

        serviceId = intent.getStringExtra("serviceId")

        recievername = intent.getStringExtra("recievername")

        service_name = intent.getStringExtra("service_name")

        buyer_id = intent.getStringExtra("buyer_id")

        serviceprovidername = intent.getStringExtra("serviceprovidername")

        isbuyer = intent.getStringExtra("isbuyer")

        status = intent.getStringExtra("status")

        price = intent.getIntExtra("price", 0)

        rate_type=intent.getStringExtra("rate_type")


        securityDeposite = intent.getStringExtra("securityDeposite")


        initViews()


    }


    private fun createCahtRecyclerView(chatlist: ArrayList<Chat>) {




        recyclerView?.setHasFixedSize(true)

        mLayoutManager = LinearLayoutManager(this)

        recyclerView?.setLayoutManager(mLayoutManager)


        viewAdapter = ChatAdapterr(chatlist, this@ChatActivity, recyclerView, onClicklistener)
        recyclerView?.setAdapter(viewAdapter)


        viewAdapter?.refresh(chatArrayList, chatArrayList?.size)
        recyclerView?.addOnScrollListener(recyclerview())

        viewAdapter?.setLoaded()
        viewAdapter?.setOnLoadMoreListener(onLoad());

    }


    @TargetApi(Build.VERSION_CODES.M)
    @RequiresApi(Build.VERSION_CODES.M)
    private fun initViews() {

        butn_make0ffer = findViewById<View>(R.id.butn_make0ffer) as Button
        butn_date = findViewById<View>(R.id.butn_setDate) as Button
        txt_booknow = findViewById<View>(R.id.txt_booknow) as TextView

        txt_status_value = findViewById(R.id.status_text)
        price_text = findViewById(R.id.price_text)


        status_layout = findViewById(R.id.status_layout)

        butn_status_booknow = findViewById(R.id.butn_status_booknow)

        img_price = findViewById(R.id.img_price)
        status_cardview = findViewById(R.id.status_cardview)
        status_cardview?.setOnClickListener(this)

        recyclerView = findViewById(R.id.chat_recyclerview);
        progressbar = findViewById(R.id.progress_bar)

        swiper=findViewById(R.id.swiper)


        setResult(Activity.RESULT_OK)

        if (!isbuyer.equals("true")) {
            butn_make0ffer?.visibility = View.GONE
            butn_date?.visibility = View.GONE

        } else {
            if (!status.equals("0")) {
                butn_make0ffer?.visibility = View.GONE
                butn_date?.visibility = View.GONE


            }

        }


        price_text?.setText("" + price)
        price_text?.visibility = View.VISIBLE
        img_price?.visibility = View.VISIBLE


        apiUtility = APIUtility(this@ChatActivity)
        title = findViewById<AppCompatTextView>(R.id.title)
        back = findViewById(R.id.back)


        edt_send = findViewById(R.id.edt_send)
        butn_send = findViewById(R.id.butn_send)
        txt_status = findViewById(R.id.txt_status)
        txt_status!!.visibility = View.VISIBLE

        butn_send!!.setOnClickListener(this)
        back?.setOnClickListener(this)
        butn_status_booknow?.setOnClickListener(this)


        butn_make0ffer!!.setOnClickListener(this)
        butn_date!!.setOnClickListener(this)


        mcontext = this
        chatArrayList = ArrayList()
        txt_booknow!!.setOnClickListener(this)

        title?.text = service_name


        getAllChats(first_date!!,direction!!)



       // getConvertedTime()

        socketConnection()

        socketTestConnection()

        socketNewMessage()

        socketTypeMessage()

        socketStopTypeMessage()

        edtChangeListener()

        checkStatus()





        swiper?.setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener {
            override fun onRefresh() {
                Log.e("refres","refresh")
                swiper?.isRefreshing=false


                getAllChats(first_date!!,"down")
//                recyclerView?.smoothScrollToPosition(pageCounter!!*19)


            }

        })

        /* create connection */

        mSocket!!.on("connected") {

        }


        mSocket!!.on("socket") { args ->

            `object` = args[0] as Any


        }

    }



   fun recyclerview():RecyclerView.OnScrollListener {
       return object : RecyclerView.OnScrollListener() {

           override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
               super.onScrolled(recyclerView, dx, dy)
               if (dy > 0) {
                   Log.e("up", "down")
               } else {
                   Log.e("up", "up")
                   direction="down"



               }

                  var visibleItemCount = mLayoutManager?.getChildCount();
              var firstVisibleItemPosition = mLayoutManager?.findFirstVisibleItemPosition()
              var lastVisibleItemPosition=mLayoutManager?.findLastCompletelyVisibleItemPosition()

              var totalItemCount = mLayoutManager?.getItemCount()

              Log.e("totalitems"," "+totalItemCount+"  "+firstVisibleItemPosition+"  "+lastVisibleItemPosition)


              /*if (!isloading && !islastpage){
                  if ((visibleItemCount!!+firstVisibleItemPosition!!)>=totalItemCount!!&&firstVisibleItemPosition>=0) {
                      getAllChats(first_date!!, direction!!)
                      Log.e("more", "small")
                  }

              }
              else{

                  Log.e("more","more")
              }*/

           }

           override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
               super.onScrollStateChanged(recyclerView, newState)







           }
       }



   }


    fun getConvertedTime(strDate: String) {

        try {
            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            datetime=targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }


    fun convertGmtToLocal(strDate: String){

        var inputFormat =  SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        inputFormat.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));

        var outputFormat =  SimpleDateFormat("MMM dd, yyyy h:mm a");

        var date = inputFormat.parse(strDate)
        gmtTime = outputFormat.format(date)


    }

  /*  fun getLocalTime() {


        var formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("Etc/UTC"))
        var value = formatter.parse(time)
        var dateFormatter = SimpleDateFormat("MMM dd, yyyy h:mm a") //this format changeable
        dateFormatter.setTimeZone(TimeZone.getDefault())
        local_time = dateFormatter.format(value)


    }*/


    private fun edtChangeListener() {


        edt_send!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                try {


                    var jsonObject1 = JSONObject()

                    jsonObject1?.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))

                    msg = s.toString()

                    mSocket!!.emit("typing", jsonObject1)

                    handler.removeCallbacks(getRunnable());


                } catch (e: JSONException) {
                    e.printStackTrace()
                }

            }

            override fun afterTextChanged(s: Editable) {

                if (s?.length > 0) {
                    last_text_edit = System.currentTimeMillis()
                    handler.postDelayed(getRunnable(), 1000);
                }

            }
        })

    }

    private fun socketStopTypeMessage() {

        mSocket!!.on("stopTyping") { args ->

            var `object` = args[0] as Object


            var jsonObject = JSONObject()

            jsonObject?.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))

            mSocket!!.emit("stopTyping", jsonObject)
            runOnUiThread(object : Runnable {
                override fun run() {

                    txt_status!!.setText("Online")


                }

            })


        }

    }

    private fun socketTypeMessage() {


        mSocket!!.on("typing") { args ->

            var `object` = args[0] as Object

            runOnUiThread(object : Runnable {
                override fun run() {

                    txt_status!!.setText("Typing")


                }

            })
        }


    }


    fun onLoad(): OnLoadMoreListener {

        return object : OnLoadMoreListener {
            override fun onLoadMore() {

                getAllChats(first_date!!,direction!!)
                progressbar?.visibility = View.VISIBLE
              //  viewAdapter?.setLoaded()




            }
        }

    }

    fun getRunnable(): Runnable {
        var runnable = Runnable {

            var jsonstoptyping = JSONObject()

            jsonstoptyping?.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))

            if (System.currentTimeMillis() > (0 + 1000 - 500)) {

                mSocket?.emit("stopTyping", jsonstoptyping)


            }


        }
        return runnable

    }


    private fun socketNewMessage() {
        mSocket!!.on("newMessage") { args ->

            val test = args[0] as JSONObject

            if (test.getString("user_id").equals("")) {

                runOnUiThread(object : Runnable {
                    override fun run() {
                        txt_status!!.setText("Offline")

                    }

                })

            }


            try {
                val data = args[0] as JSONObject
                var offer_price: String? = null


                var userId = data.getString("user_id")
                var time = data.getString("time")
                var specialmsg = data.getString("special_msg")

                if (data.has("message")) {
                    msg = data.getString("message")
                }


                dateTime(time)
                //getLocalTime()

                if (userId.equals(Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))) {


                    runOnUiThread(object : Runnable {
                        @RequiresApi(Build.VERSION_CODES.M)
                        override fun run() {

                            if (specialmsg.equals("2")) {


                                if (data.has("price")) {
                                    var price = data.getString("price")
                                    price_text?.setText(price)

                                    Log.e("specccial1", "" + price + "  " + price_text?.text)


                                }

                                if (data.has("status")) {
                                    var statuskey = data.getString("status")
                                    Log.e("specccia2", "" + statuskey)

                                    status = statuskey
                                    checkStatus()



                                }


                            }

                        }

                    })
                } else {

                    runOnUiThread(object : Runnable {
                        @SuppressLint("NewApi")
                        @RequiresApi(Build.VERSION_CODES.M)
                        override fun run() {
                            txt_status!!.setText("Online")

                            if (specialmsg.equals("2")) {

                                status = data.getString("status")


                                txt_status_value?.setText("Your service booked successfully,Please wait for the Service Provider Response")
                                checkStatus()

                                if (data.has("price")) {
                                    var price = data.getString("price")

                                    price_text?.setText(price)
                                }

                            }

                        }

                    })
                    if (!specialmsg.equals("2")) {
                        if (data.has("offer_price")) {

                            offer_price = data.getString("offer_price")

                            chatArrayList?.add(Chat(local_time, msg, 1, specialmsg, offer_price))
                            viewAdapter?.refresh(chatArrayList, chatArrayList?.size)

                        } else {

                            chatArrayList?.add(Chat(local_time, msg, 1, specialmsg, null))
                            viewAdapter?.refresh(chatArrayList, chatArrayList?.size)
                        }
                    }

                }


            } catch (e: Exception) {
                e.printStackTrace()
            }


        }
    }


    fun socketConnection() {

        try {
            mSocket = IO.socket(socket_url)


        } catch (e: URISyntaxException) {

        }

        mSocket!!.connect()

    }

    private fun socketTestConnection() {


        val jsonObject: JSONObject = JSONObject()

        jsonObject?.put("room", transaction_id)
        jsonObject?.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))

        mSocket?.emit("test", jsonObject)


        mSocket?.on("test") { args ->

            val data = args[0] as JSONObject


            if (data.has("user_id")) {

                runOnUiThread(object : Runnable {
                    override fun run() {
                        txt_status!!.setText("Online")

                    }

                })

            }

        }

    }


    override fun onBackPressed() {
        super.onBackPressed()
        mSocket?.disconnect()
        mSocket?.close()

    }


    fun getConvertedTime() {

        var currentTime = Calendar.getInstance().getTime()

        var dateFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")

        dateFormatter.setTimeZone(TimeZone.getDefault())
        time = dateFormatter.format(currentTime)


        var formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",Locale.US);
        formatter.setTimeZone(TimeZone.getTimeZone("Etc/UTC"))
        var value = formatter.parse(time)
        var dateFormatter1 = SimpleDateFormat("MMM dd, yyyy h:mm a") //this format changeable
        dateFormatter1.setTimeZone(TimeZone.getDefault())
        local_time = dateFormatter1.format(value)


    }


    fun getAllChats(firstdate:String,direction:String) {


        val request = ChatRequest()

        request.receiver_id = buyer_id
        request.user_id = Preferences.getPreference(this@ChatActivity, PrefEntity.USERID)
        request.transaction_id = transaction_id
        request.scroll = direction
        request.time = firstdate
//        request.page_size=TotalItemCount!!
//        request.page_number=mCurrentPage


        apiUtility?.getAllChats(this@ChatActivity, request, true, object : APIUtility.APIResponseListener<GetChatResponseWrapper> {
            override fun onReceiveResponse(response: GetChatResponseWrapper?) {


                if (response != null) {

                    if (response.response.getChatResult.user_msgs != null) {

                        swiper?.isRefreshing=false

                        var usermsgsCount=response.response.getChatResult.user_msgs.size



                        if (response.response.getChatResult.user_msgs.size != 0) {
                            progressbar!!.visibility=View.GONE


                            Collections.reverse(response.response.getChatResult.user_msgs)

                            var count=usermsgsCount-1*pageCounter!!

                            Log.e("userms","  "+count)
                            pageCounter!!+1


                            first_date=response.response.getChatResult.user_msgs.get(pageCounter!!).get("time").asString


                            for (i in 0 until response.response.getChatResult.user_msgs.size) {


                                var id = response.response.getChatResult.user_msgs.get(i).get("_id").asString
                                var msg_body = response.response.getChatResult.user_msgs.get(i).get("msg_body").asString
                                var is_sender = response.response.getChatResult.user_msgs.get(i).get("is_sender").asString
                                var time = response.response.getChatResult.user_msgs.get(i).get("time").asString
                                var special_msg = response.response.getChatResult.user_msgs.get(i).get("special_msg").asString


                                dateTime(time)
                               // getLocalTime()
                                convertGmtToLocal(time)



                                msg_id?.add(id)

                                if (!is_sender.equals(Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))) {


                                    if (response.response.getChatResult.user_msgs.get(i).has("offer_price")) {
                                        var offer_price = response.response.getChatResult.user_msgs.get(i).get("offer_price").asString

                                        chatArrayList?.add(Chat(gmtTime, msg_body, 1, special_msg, offer_price))


                                    } else {
                                        chatArrayList?.add(Chat(gmtTime, msg_body, 1, special_msg, null))
                                    }


                                } else {


                                    chatArrayList?.add(Chat(gmtTime, msg_body, 0, special_msg, null))


                                }
                                createCahtRecyclerView(chatArrayList!!)
                                //viewAdapter?.setOnLoadMoreListener(onLoad())




                            }
                        }
                    }


                }


            }

            override fun onResponseFailed() {


            }

            override fun onStatusFalse(response: GetChatResponseWrapper?) {


            }

        })
    }


    fun dateTime(timevalue: String): String {


        try {

            var sourceDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")

            var date = sourceDateFormat.parse(timevalue)


            var targetDateFormat = SimpleDateFormat("dd-MM-yyyy HH:mm")
            convertedTime = targetDateFormat.format(date)


        } catch (e: ParseException) {
            e.printStackTrace()
            Log.e("excep", "" + e.message)
        }
        return timevalue!!


    }

    fun getAcceptStatus(pos: Int?, price: String) {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ChatActivity, PrefEntity.USERID)
        request.transaction_id = transaction_id;
        request.status = "2"
        if (price != null) {
            request.price = price
        } else {
            request.price = ""

        }
        var gson = Gson()

        apiUtility?.getAcceptDecline(this@ChatActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "accepted succesfully")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", servicetype)
                    jsonObject1.put("special_msg", "0")
                    jsonObject1.put("time", time)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("price", price)
                    jsonObject1.put("status", "2")

                    object1.put("receiver_id", buyer_id)

                    object1.put("receiver_name", recievername)

                    dateTime(time!!)
                    //getLocalTime()


                    chatArrayList?.add(Chat(convertedTime, "accepted succesfully", 0, "0", null))
//
                    createCahtRecyclerView(chatArrayList!!)

                    mSocket?.emit("createMessage", jsonObject1, object1)


                    edt_send!!.setText("")
                    chatArrayList?.clear()


                } catch (e: JSONException) {
                    e.printStackTrace()
                }

               // getAllChats()


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })
    }


    fun getDeclineStatus(pos: Int?, price: String) {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ChatActivity, PrefEntity.USERID)
        request.transaction_id = transaction_id;
        request.status = "3"
        request._id = " "

        apiUtility?.getAcceptDecline(this@ChatActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "Offer Decline")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", servicetype)
                    jsonObject1.put("special_msg", "0")
                    jsonObject1.put("time", time)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("price", price)
                    jsonObject1.put("status", "3")



                    object1.put("receiver_id", buyer_id)


                    object1.put("receiver_name", recievername)

                    dateTime(time!!)
                    //getLocalTime()


                    chatArrayList?.add(Chat(convertedTime, "Offer Decline", 0, "0", null))

                    createCahtRecyclerView(chatArrayList!!)
                    mSocket?.emit("createMessage", jsonObject1, object1)


                    edt_send!!.setText("")
                    chatArrayList?.clear()


                } catch (e: JSONException) {
                    e.printStackTrace()
                }
                //getAllChats()


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }
        })
    }

    @SuppressLint("ResourceAsColor")
    @RequiresApi(Build.VERSION_CODES.M)
    fun checkStatus() {

        butn_status_booknow1?.setBackgroundColor(R.color.red)
        side_img?.setImageResource(R.mipmap.red_side_curve)


        if (isbuyer.equals("true")) {

            when (status) {

                "0" -> {

                    txt_status_value?.setText("You can book Service by a single tap")
                    butn_status_booknow?.setText("Book now")
                    status_cardview?.isClickable = true
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)
                }

                "1" -> {
                    txt_status_value?.setText("Waiting for Service Provider acceptance")
                    price_text?.setText("" + price)
                    butn_status_booknow?.setText("Booked")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.green, theme))
                    side_img?.setImageResource(R.mipmap.green_side_curve)

                }
                "2" -> {
                    txt_status_value?.setText("Please Confirmed your booking by paying")
                    butn_status_booknow?.setText("Pay now")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    side_img?.setImageResource(R.mipmap.side_curve_large)
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.blue, theme))
                }
                "3" -> {
                    txt_status_value?.setText("Booking Price decline by Service Provider,Please Coordinate with Service Provider")
                    butn_status_booknow?.setText("Declined by Service Provider")
                    status_cardview?.isClickable = false
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE


                }

                "4" -> {
                    txt_status_value?.setText("Your payment Successful")
                    butn_status_booknow?.setText("Payment done")
                    status_cardview?.isClickable = false
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.black, theme))
                    side_img?.setImageResource(R.mipmap.black_side_curve)

                }
                "5" -> {

                    txt_status_value?.setText("Cancle by you")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Cancle by you")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.red, theme))
                    side_img?.setImageResource(R.mipmap.red_side_curve)
                }
                "6" -> {

                    txt_status_value?.setText("Cancle by Service provider")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Cancle by Service provider")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.red, theme))
                    side_img?.setImageResource(R.mipmap.red_side_curve)
                }

                "7"->{
                    txt_status_value?.setText("Handover")
                    status_cardview?.isClickable = true
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.red, theme))
                    side_img?.setImageResource(R.mipmap.red_side_curve)


                }
                "9"->{
                    txt_status_value?.setText("Return")
                    status_cardview?.isClickable = false
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.red, theme))
                    side_img?.setImageResource(R.mipmap.red_side_curve)



                }

                "8" -> {

                    txt_status_value?.setText(" Confirm")
                    status_cardview?.isClickable = true
                    butn_status_booknow?.setText("Confirm")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)

                }

                "11"->{
                    txt_status_value?.setText(" Confirm and pay")
                    status_cardview?.isClickable = true
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)

                }


                "13" ->{

                    txt_status_value?.setText("Service done")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Service done")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)

                }

                "7" ->{
                    txt_status_value?.setText("Please Confirm")
                    status_cardview?.isClickable = true
                    butn_status_booknow?.setText("Please Confirm")

                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)



                }
                "10"->{

                    txt_status_value?.setText("Confirm and pay")
                    butn_status_booknow?.setText("Confirm and pay")

                    status_cardview?.isClickable = true
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)




                }


                "14"->{

                    txt_status_value?.setText("Product done")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Product done")

                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)



                }

                "12"->{
                    txt_status_value?.setText("Completed")
                    butn_status_booknow?.setText("Completed")

                    status_cardview?.isClickable = false
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)




                }

            }


        } else {
            when (status) {


                "0" -> {
                    txt_status_value?.setText(recievername + " has not Booked service yet")
                    butn_status_booknow?.setText("Waiting for booking")
                    status_cardview?.isClickable = false
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)
                }
                "1" -> {
                    txt_status_value?.setText("Recieved booking request from" + " " + recievername)
                    butn_status_booknow?.setText("Recieved booking")
                    status_cardview?.isClickable = true
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.green, theme))
                    side_img?.setImageResource(R.mipmap.green_side_curve)
                }
                "2" -> {
                    txt_status_value?.setText("Payment yet to be recieve")
                    butn_status_booknow?.setText("Payment due")

                    status_cardview?.isClickable = true
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.colorAccent, theme))
                    side_img?.setImageResource(R.mipmap.side_curve_large)
                }
                "3" -> {
                    txt_status_value?.setText("Booking price decline by" + " " + service_name + " ,Please Coordinate with Service Provider")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Decline by Service Provider")

                }
                "4" -> {
                    txt_status_value?.setText("Your payment Successful")
                    status_cardview?.isClickable = true
                    butn_status_booknow?.setText("Payment done")
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.black, theme))
                    side_img?.setImageResource(R.mipmap.black_side_curve)
                }
                "5" -> {
                    txt_status_value?.setText("Cancle by buyer")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.text = "Cancle by buyer"
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.red, theme))
                    side_img?.setImageResource(R.mipmap.red_side_curve)
                }
                "6" -> {
                    txt_status_value?.setText("Cancle by you")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.text = "Cancle by you"
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.red, theme))
                    side_img?.setImageResource(R.mipmap.red_side_curve)
                }
                "8" ->{
                    txt_status_value?.setText("Waiting for Confirmation")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.text = "Waiting for Confirmation"
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)


                }


                "9"->{
                    txt_status_value?.setText("Waiting for return")
                    status_cardview?.isClickable = true
                    butn_status_booknow?.setText("Waiting for return")

                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)


                }
                "10"->{

                    txt_status_value?.setText("Waiting for confirmation")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Waiting for confirmation")


                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)
                }

                "11"->{

                    txt_status_value?.setText("Waiting for confirmation")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Waiting for confirmation")


                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)

                }

                "7" ->{

                    txt_status_value?.setText("Waiting for confirmation")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Waiting for confirmation")

                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)
                }

                "13" ->{


                    txt_status_value?.setText("Service done")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Service done")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)

                    side_img?.setImageResource(R.mipmap.yellow_side_curve)



                }

                "12"->{

                    txt_status_value?.setText("Please complete")
                    status_cardview?.isClickable = true
                    butn_status_booknow?.setText("Please complete")
                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)



                }
                "14"->{

                    txt_status_value?.setText("Completed")
                    status_cardview?.isClickable = false
                    butn_status_booknow?.setText("Completed")

                    butn_make0ffer?.visibility = View.GONE
                    butn_date?.visibility = View.GONE
                    butn_status_booknow1?.setBackgroundColor(getResources().getColor(R.color.yellow, theme))
                    side_img?.setImageResource(R.mipmap.yellow_side_curve)



                }


            }


        }

    }


    override fun click(pos: Int?, price: String) {

        getAcceptStatus(pos, price)
    }


    override fun declineclick(pos: Int?, price: String) {
        getDeclineStatus(pos, price)

    }

    override fun onDestroy() {
        super.onDestroy()
        mSocket?.disconnect()
        mSocket?.close()


    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }


    override fun onClick(v: View) {
        when (v.id) {

            R.id.back -> {

                finish()
                mSocket?.disconnect()
                mSocket?.close()

            }


            R.id.status_cardview -> {


                if (status.equals("1")) {

                    if (servicetype == "product") {
                        Log.e("payments", "pay11")

                        var intent = Intent(this@ChatActivity, ProductBookingDetailsActivity::class.java)
                        intent.putExtra("transaction", transaction_id)
                        intent.putExtra("status", status)
                        intent.putExtra("isbuyer", isbuyer)
                        intent.putExtra("service_name", service_name)
                        intent.putExtra("transaction", transaction_id)
                        intent.putExtra("service_type", servicetype)
                        intent.putExtra("serviceId", serviceId)
                        intent.putExtra("user_id", buyer_id)
                        intent.putExtra("rate_type",rate_type)

                        intent.putExtra("serviceprovidername", serviceprovidername)
                        intent.putExtra("securityDeposite", securityDeposite)

                        intent.putExtra("isbuyer", isbuyer)
                        startActivityForResult(intent, 10)

                    } else {


                        var intent = Intent(this@ChatActivity, ServiceBookingDetailActivity::class.java)
                        intent.putExtra("transaction", transaction_id)
                        intent.putExtra("status", status)
                        intent.putExtra("isbuyer", isbuyer)
                        intent.putExtra("service_name", service_name)
                        intent.putExtra("transaction", transaction_id)
                        intent.putExtra("service_type", servicetype)
                        intent.putExtra("serviceId", serviceId)
                        intent.putExtra("user_id", buyer_id)
                        intent.putExtra("serviceprovidername", serviceprovidername)
                        intent.putExtra("isbuyer", isbuyer)

                        startActivityForResult(intent, 10)


                    }

                } else if (status.equals("0")) {

                    if (servicetype == "product") {

                        val intent2 = Intent(this, ProductBookingActivity::class.java)
                        intent2.putExtra("service_name", service_name)
                        intent2.putExtra("transaction", transaction_id)
                        intent2.putExtra("service_type", servicetype)
                        intent2.putExtra("serviceId", serviceId)
                        intent2.putExtra("user_id", buyer_id)
                        intent2.putExtra("rate_type",rate_type)

                        intent2.putExtra("securityDeposite", securityDeposite)

                        intent2.putExtra("serviceprovidername", serviceprovidername)

                        startActivityForResult(intent2, 11)
                    } else {


                        val intent2 = Intent(this, ServiceBookingActivity::class.java)
                        intent2.putExtra("service_name", service_name)
                        intent2.putExtra("transaction", transaction_id)
                        intent2.putExtra("service_type", servicetype)
                        intent2.putExtra("serviceId", serviceId)
                        intent2.putExtra("user_id", buyer_id)
                        intent2.putExtra("serviceprovidername", serviceprovidername)


                        startActivityForResult(intent2, 11)
                    }

                } else {


                    if (isbuyer.equals("true")) {
                        if (servicetype == "service") {

                            var intent = Intent(this@ChatActivity, ServiceBookingDetailActivity::class.java)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("status", status)
                            intent.putExtra("isbuyer", isbuyer)
                            intent.putExtra("service_name", service_name)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("service_type", servicetype)
                            intent.putExtra("serviceId", serviceId)
                            intent.putExtra("user_id", buyer_id)
                            intent.putExtra("serviceprovidername", serviceprovidername)
                            intent.putExtra("isbuyer", isbuyer)

                            startActivityForResult(intent, 12)
                        }

                        if (servicetype == "product") {
                            var intent = Intent(this@ChatActivity, ProductBookingDetailsActivity::class.java)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("status", status)
                            intent.putExtra("isbuyer", isbuyer)
                            intent.putExtra("service_name", service_name)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("service_type", servicetype)
                            intent.putExtra("serviceId", serviceId)
                            intent.putExtra("securityDeposite", securityDeposite)
                            intent.putExtra("rate_type",rate_type)


                            intent.putExtra("user_id", buyer_id)
                            intent.putExtra("serviceprovidername", serviceprovidername)
                            intent.putExtra("isbuyer", isbuyer)

                            startActivityForResult(intent, 12)


                        }


                    } else {

                        if (servicetype == "service") {

                            var intent = Intent(this@ChatActivity, ServiceBookingDetailActivity::class.java)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("status", status)
                            intent.putExtra("isbuyer", isbuyer)
                            intent.putExtra("service_name", service_name)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("service_type", servicetype)
                            intent.putExtra("serviceId", serviceId)
                            intent.putExtra("user_id", buyer_id)
                            intent.putExtra("serviceprovidername", serviceprovidername)
                            intent.putExtra("isbuyer", isbuyer)

                            startActivityForResult(intent, 12)
                        }

                        if (servicetype == "product") {
                            var intent = Intent(this@ChatActivity, ProductBookingDetailsActivity::class.java)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("status", status)
                            intent.putExtra("isbuyer", isbuyer)
                            intent.putExtra("service_name", service_name)
                            intent.putExtra("transaction", transaction_id)
                            intent.putExtra("service_type", servicetype)
                            intent.putExtra("serviceId", serviceId)
                            intent.putExtra("securityDeposite", securityDeposite)
                            intent.putExtra("rate_type",rate_type)


                            intent.putExtra("user_id", buyer_id)
                            intent.putExtra("serviceprovidername", serviceprovidername)
                            intent.putExtra("isbuyer", isbuyer)

                            startActivityForResult(intent, 12)
                        }


                    }
                }
            }

            R.id.butn_make0ffer -> {




                val dialog = Dialog(this)
                dialog.setContentView(R.layout.custom_makeoffer_dialog)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

                dialog.show()
                val imageView = dialog.findViewById<ImageView>(R.id.cancle_image)
                val textview = dialog.findViewById<TextView>(R.id.like_text)
                imageView.setOnClickListener {

                    dialog.dismiss()


                }

                var editText = dialog.findViewById<EditText>(R.id.edt_price)
                var submit = dialog.findViewById<Button>(R.id.submit)





                submit!!.setOnClickListener(object : View.OnClickListener {
                    override fun onClick(v: View?) {

                        if (TextUtils.isEmpty(editText.text)) {


                            Toast.makeText(this@ChatActivity, "Enter some text", Toast.LENGTH_SHORT).show()
                        }
                        else {
                            val jsonObject1 = JSONObject()

                            val object1 = JSONObject()

                            try {
                                jsonObject1.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))
                                jsonObject1.put("message", "I would like to buy your service for" + " " + editText?.text.toString())
                                jsonObject1.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))
                                jsonObject1.put("service_id", serviceId)
                                jsonObject1.put("service_type", servicetype)
                                jsonObject1.put("special_msg", "1")
                                jsonObject1.put("time", time)
                                jsonObject1.put("service_name", service_name)
                                jsonObject1.put("offer_price", editText?.text.toString())
                                jsonObject1.put("securityDeposite", securityDeposite)
                                jsonObject1.put("rate_type",rate_type)


                                object1.put("receiver_id", buyer_id)


                                object1.put("receiver_name", recievername)


                                dateTime(time!!)
                                //getLocalTime()
                                getConvertedTime()



                                chatArrayList?.add(Chat(local_time, "I would like to buy your service for" + " " + editText!!.text.toString(), 0, "1", null))
                                viewAdapter?.refresh(chatArrayList, chatArrayList?.size)
                                editText?.setText("")

                                mSocket?.emit("createMessage", jsonObject1, object1)

                                dialog.dismiss()


                            } catch (e: Exception) {

                            }

                        }
                    }

                })
            }


            R.id.butn_send -> {

                send_msg()

            }


            R.id.butn_setDate -> {

                if (servicetype == "service") {


                    val dialog = Dialog(this)
                    dialog.setContentView(R.layout.custom_datetime_dialog)
                    dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

                    dialog.show()
                    val imageView = dialog.findViewById<ImageView>(R.id.cancle_image)
                    val edt_price = dialog.findViewById<EditText>(R.id.edt_price)
                    var submit = dialog.findViewById<Button>(R.id.submit)
                    var time: String? = null


                    submit.setOnClickListener(object : View.OnClickListener {

                        override fun onClick(v: View?) {


                            if (TextUtils.isEmpty(edt_price.text)) {


                                Toast.makeText(this@ChatActivity, "Select date and time", Toast.LENGTH_SHORT).show()
                            } else {

                                val jsonObject1 = JSONObject()

                                val object1 = JSONObject()

                                try {
                                    jsonObject1.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))
                                    jsonObject1.put("message", "I want to check your availability for" + " " + service_date + " at " + service_time + ",Are you available?")
                                    jsonObject1.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))
                                    jsonObject1.put("service_id", serviceId)
                                    jsonObject1.put("service_type", servicetype)
                                    jsonObject1.put("special_msg", "1")
                                    jsonObject1.put("time", time)
                                    jsonObject1.put("service_name", service_name)
                                    jsonObject1.put("offer_price", price.toString())
                                    jsonObject1.put("securityDeposite", securityDeposite)
                                    jsonObject1.put("rate_type",rate_type)


                                    object1.put("receiver_id", buyer_id)


                                    object1.put("receiver_name", recievername)

                                    getConvertedTime()



                                    chatArrayList?.add(Chat(local_time, "I want to check your availability for" + " " + service_date + " at " + service_time + ", Are you available?", 0, "1", null))

                                    createCahtRecyclerView(chatArrayList!!)

                                    mSocket?.emit("createMessage", jsonObject1, object1)
                                    dialog.dismiss()


                                } catch (e: java.lang.Exception) {


                                }

                            }
                        }

                    })

                    imageView.setOnClickListener {

                        dialog.dismiss()
                    }

                    edt_price.setOnClickListener {


                        var dateTimeDialogFragment = SwitchDateTimeDialogFragment.newInstance(
                                "Select Data and Time",
                                "OK",
                                "Cancel"
                        );

                        dateTimeDialogFragment.startAtCalendarView()
                        dateTimeDialogFragment.set24HoursMode(false);


                        try {
                            dateTimeDialogFragment.setSimpleDateMonthAndDayFormat(SimpleDateFormat("dd MM"))

                        } catch (e: SwitchDateTimeDialogFragment.SimpleDateMonthAndDayFormatException) {

                        }

                        dateTimeDialogFragment.setOnButtonClickListener(object : SwitchDateTimeDialogFragment.OnButtonClickListener {
                            override fun onPositiveButtonClick(p0: Date?) {


                                var date = SimpleDateFormat("yyyy-MM-dd")
                                date.setTimeZone(TimeZone.getDefault())
                                service_date = date.format(p0)


                                var formatter = SimpleDateFormat("hh:mm a")
                                var dateString = formatter.format(Date(p0.toString()))
                                service_time = "" + dateString



                                edt_price.setText(service_date + " " + service_time)

                            }

                            override fun onNegativeButtonClick(p0: Date?) {


                            }

                        })
                        var date = Date()
                        var currentTime = Calendar.getInstance().time


                        dateTimeDialogFragment.show(getSupportFragmentManager(), "dialog_time")



                    }

                }


                else {


                    val dialog = Dialog(this)
                    dialog.setContentView(R.layout.custom_product_date)
                    dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

                    dialog.show()
                    val imageView = dialog.findViewById<ImageView>(R.id.cancle_image)
                    val edt_from = dialog.findViewById<EditText>(R.id.edt_from)
                    var edt_to = dialog.findViewById<EditText>(R.id.edt_to)
                    var submit = dialog.findViewById<Button>(R.id.submit)

                    imageView.setOnClickListener(object : View.OnClickListener {
                        override fun onClick(v: View?) {
                            dialog.dismiss()
                        }

                    })

                    edt_from.setOnClickListener(object : View.OnClickListener {
                        override fun onClick(v: View?) {
                            val c = Calendar.getInstance()
                            mYear = c.get(Calendar.YEAR)
                            mMonth = c.get(Calendar.MONTH)
                            mDay = c.get(Calendar.DAY_OF_MONTH)


                            val datePickerDialog = DatePickerDialog(this@ChatActivity,
                                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                                        product_from = ""+year+"-"+String.format("%02d", (monthOfYear+1))+"-"+String.format("%02d", dayOfMonth)
                                        product_from_date=dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year


                                        getConvertedTime(product_from!!)
                                        var day=datetime

                                        var formatter =  SimpleDateFormat("yyyy-MM-dd")
                                        var date = formatter!!.parse(day)
                                        fromdate=date.time

                                        edt_from!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                                    }, mYear, mMonth, mDay)
                            datePickerDialog.show()
                            datePickerDialog.getDatePicker().minDate = System.currentTimeMillis() - 1000


                        }

                    })

                        edt_to.setOnClickListener(object : View.OnClickListener {
                            override fun onClick(v: View?) {
                                if (!edt_from.text.toString().equals("")!!) {

                                    val c = Calendar.getInstance()
                                    mYear = c.get(Calendar.YEAR)
                                    mMonth = c.get(Calendar.MONTH)
                                    mDay = c.get(Calendar.DAY_OF_MONTH)


                                    val datePickerDialog = DatePickerDialog(this@ChatActivity,
                                            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                                                product_to = year.toString() + "-" + monthOfYear + 1 + "-" + dayOfMonth.toString()

                                                product_to_date=dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year




                                                edt_to!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                                            }, mYear, mMonth, mDay)
                                    datePickerDialog.show()
                                    datePickerDialog.getDatePicker().minDate = fromdate!!


                                }
                                else{
                                    Toast.makeText(applicationContext,"Please Select From Date",Toast.LENGTH_SHORT).show()
                                }
                            }

                     })




                    submit.setOnClickListener(object : View.OnClickListener {
                        override fun onClick(v: View?) {

                            if (TextUtils.isEmpty(edt_from.text) || TextUtils.isEmpty(edt_to.text)) {
                                Toast.makeText(this@ChatActivity, "Enter all values", Toast.LENGTH_SHORT).show()

                            } else {


                                val jsonObject1 = JSONObject()

                                val object1 = JSONObject()

                                try {
                                    jsonObject1.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))
                                    jsonObject1.put("message", "I want to check your product availability from" + " " + product_from_date + " to " + product_to_date + ",is product available?")
                                    jsonObject1.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))
                                    jsonObject1.put("service_id", serviceId)
                                    jsonObject1.put("service_type", servicetype)
                                    jsonObject1.put("special_msg", "1")
                                    jsonObject1.put("time", time)
                                    jsonObject1.put("service_name", service_name)
                                    jsonObject1.put("offer_price", price.toString())
                                    jsonObject1.put("securityDeposite", securityDeposite)
                                    jsonObject1.put("rate_type",rate_type)

                                    object1.put("receiver_id", buyer_id)


                                    object1.put("receiver_name", recievername)

                                     getConvertedTime()
                                     dateTime(time!!)
                                     //getLocalTime()

                                    chatArrayList?.add(Chat(local_time, "I want to check your product  availability from" + " " + product_from_date + " to " + product_to_date + ", is product available?", 0, "1", null))
                                    createCahtRecyclerView(chatArrayList!!)


                                    mSocket?.emit("createMessage", jsonObject1, object1)
                                    dialog.dismiss()


                                } catch (e: java.lang.Exception) {


                                }


                            }
                        }

                    })


                }
            }


            R.id.txt_booknow -> {


                if (servicetype == "product") {
                    val intent2 = Intent(this, ProductBookingActivity::class.java)
                    intent2.putExtra("service_name", service_name)

                    intent2.putExtra("transaction", transaction_id)
                    intent2.putExtra("service_type", servicetype)
                    intent2.putExtra("serviceId", serviceId)
                    intent2.putExtra("user_id", buyer_id)
                    intent2.putExtra("securityDeposite", securityDeposite)

                    intent2.putExtra("serviceprovidername", serviceprovidername)

                    startActivity(intent2)
                } else {
                    val intent2 = Intent(this, ServiceBookingActivity::class.java)
                    intent2.putExtra("service_name", service_name)
                    intent2.putExtra("transaction", transaction_id)
                    intent2.putExtra("service_type", servicetype)
                    intent2.putExtra("serviceId", serviceId)
                    intent2.putExtra("user_id", buyer_id)
                    intent2.putExtra("serviceprovidername", serviceprovidername)

                    startActivity(intent2)
                }


            }

        }
    }

    fun send_msg() {


        if (edt_send?.text.toString().equals("")) {
            Toast.makeText(this@ChatActivity, "Enter some message", Toast.LENGTH_LONG).show()


        } else {

            val jsonObject1 = JSONObject()

            val object1 = JSONObject()


            try {
                jsonObject1.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))

                jsonObject1.put("message", edt_send!!.text.toString())
                jsonObject1.put("user_id", Preferences.getPreference(this@ChatActivity, PrefEntity.USERID))
                jsonObject1.put("service_id", serviceId)
                jsonObject1.put("service_type", servicetype)
                jsonObject1.put("special_msg", "0")
                jsonObject1.put("time", time)
                jsonObject1.put("service_name", service_name)
                jsonObject1.put("securityDeposite", securityDeposite)
                jsonObject1.put("rate_type",rate_type)

                object1.put("receiver_id", buyer_id)



                object1.put("receiver_name", recievername)

                var time1: String? = null


                //getLocalTime()
                getConvertedTime()
                dateTime(time!!)


                chatArrayList?.add(Chat(local_time, edt_send!!.text.toString(), 0, "0", null))


                createCahtRecyclerView(chatArrayList!!)

                edt_send!!.setText("")


            } catch (e: JSONException) {
                e.printStackTrace()
            }


            mSocket?.emit("createMessage", jsonObject1, object1)

            var jsonObject_typing = JSONObject()

            jsonObject_typing?.put("name", Preferences.getPreference(this@ChatActivity, PrefEntity.USER_NAME))


            mSocket!!.emit("stopTyping", jsonObject_typing)


        }

    }










    @RequiresApi(Build.VERSION_CODES.M)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode==12){

            if (resultCode == Activity.RESULT_OK) {







            }




        }



    }



}












