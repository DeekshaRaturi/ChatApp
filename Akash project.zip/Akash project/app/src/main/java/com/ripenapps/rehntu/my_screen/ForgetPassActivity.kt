package com.ripenapps.rehntu.my_screen


import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.text.TextUtils

import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toolbar

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.forgot.request.ForgotRequest
import com.ripenapps.rehntu.models.forgot.response.FgPasswordResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.volley.APIUtility

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class ForgetPassActivity : BaseActivity(), View.OnClickListener {

    private var forgot_btn: Button? = null
    private var forgot_email: EditText? = null
    private val toolbar: Toolbar? = null
    private var apiUtility: APIUtility? = null
    private var back: ImageView? = null
    private var title: AppCompatTextView?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_pass)
        apiUtility = APIUtility(this@ForgetPassActivity)
        initViews()
    }


    private fun initViews() {
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title?.text = "Forgot Password"
        forgot_btn = findViewById<View>(R.id.forget_email_btn) as Button
        forgot_email = findViewById<View>(R.id.forget_email) as EditText
        forgot_btn!!.setOnClickListener(this)
        back!!.setOnClickListener(this)
    }


    override fun onClick(v: View) {
        val id = v.id
        when (id) {

            R.id.forget_email_btn -> ForgotPasswordMethod()

            R.id.back -> finish()
        }
    }


    private fun ForgotPasswordMethod() {
        if (!TextUtils.isEmpty(forgot_email!!.text.toString().trim { it <= ' ' })) {
            if (CommonUtils.isEmailValid(forgot_email!!.text.toString().trim { it <= ' ' })) {
                forgetPassword(forgot_email!!.text.toString().trim { it <= ' ' })
            } else {
                CommonUtils.alert(this@ForgetPassActivity, getString(R.string.alert_email_valid))

                //                forgot_email.setError(getString(R.string.alert_email_valid));
            }
        } else {
            CommonUtils.alert(this@ForgetPassActivity, getString(R.string.alert_email))

            //            forgot_email.setError(getString(R.string.alert_email));
        }
    }


    private fun forgetPassword(email: String) {

        val request = ForgotRequest(email)
        apiUtility!!.forgetPassword(this@ForgetPassActivity, request, true, object : APIUtility.APIResponseListener<FgPasswordResponseWrapper> {
            override fun onReceiveResponse(response: FgPasswordResponseWrapper?) {
                if (response != null) {
                    gotoLogin("User will receive an email over the registered email address")
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@ForgetPassActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: FgPasswordResponseWrapper) {
                CommonUtils.alert(this@ForgetPassActivity, "Email ID not Registered")

            }
        })

    }

    private fun gotoLogin(msg: String) {
        AlertDialog.Builder(this@ForgetPassActivity)
                .setMessage(msg)
                .setTitle(R.string.app_name)
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok
                ) { dialog, whichButton ->
                    dialog.dismiss()
                    val intent = Intent(this@ForgetPassActivity, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }.show()
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }
}
