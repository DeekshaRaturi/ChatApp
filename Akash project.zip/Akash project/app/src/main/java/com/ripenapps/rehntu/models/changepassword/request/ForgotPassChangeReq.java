package com.ripenapps.rehntu.models.changepassword.request;

import com.google.gson.annotations.SerializedName;

public class ForgotPassChangeReq {


        @SerializedName("email")
        String email;

        @SerializedName("password")
        String password;

        public ForgotPassChangeReq(String email, String password) {
            this.email = email;
            this.password = password;
        }
}
