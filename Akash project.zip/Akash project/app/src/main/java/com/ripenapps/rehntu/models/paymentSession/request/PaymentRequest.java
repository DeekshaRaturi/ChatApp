package com.ripenapps.rehntu.models.paymentSession.request;

import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

import retrofit2.http.Header;

public class PaymentRequest {

      public String getMerchantAccount() {
            return merchantAccount;
      }

      public void setMerchantAccount(String merchantAccount) {
            this.merchantAccount = merchantAccount;
      }

      public String getChannel() {
            return channel;
      }

      public void setChannel(String channel) {
            this.channel = channel;
      }
/*
      public JSONObject getAmount() {
            return amount;
      }

      public void setAmount(JSONObject amount) {
            this.amount = amount;
      }*/

      public String getReference() {
            return reference;
      }

      public void setReference(String reference) {
            this.reference = reference;
      }

      public String getCountryCode() {
            return countryCode;
      }

      public void setCountryCode(String countryCode) {
            this.countryCode = countryCode;
      }

      public String getShopperLocale() {
            return shopperLocale;
      }

      public void setShopperLocale(String shopperLocale) {
            this.shopperLocale = shopperLocale;
      }

      public String getToken() {
            return token;
      }

      public void setToken(String token) {
            this.token = token;
      }

      public String getReturnUrl() {
            return returnUrl;
      }

      public void setReturnUrl(String returnUrl) {
            this.returnUrl = returnUrl;
      }

      @SerializedName("merchantAccount")
      String merchantAccount;

      @SerializedName("channel")
      String channel;

      public String getShopperReference() {
            return shopperReference;
      }

      public void setShopperReference(String shopperReference) {
            this.shopperReference = shopperReference;
      }
      @SerializedName("enableOneClick")
      Boolean enableOneClick;

      @SerializedName("enableRecurring")
      Boolean enableRecurring;

      @SerializedName("html")
      Boolean html;

      @SerializedName("origin")
      String origin;

      public Boolean getEnableOneClick() {
            return enableOneClick;
      }

      public void setEnableOneClick(Boolean enableOneClick) {
            this.enableOneClick = enableOneClick;
      }

      public Boolean getEnableRecurring() {
            return enableRecurring;
      }

      public void setEnableRecurring(Boolean enableRecurring) {
            this.enableRecurring = enableRecurring;
      }

      public Boolean getHtml() {
            return html;
      }

      public void setHtml(Boolean html) {
            this.html = html;
      }

      public String getOrigin() {
            return origin;
      }

      public void setOrigin(String origin) {
            this.origin = origin;
      }

      public String getSdkVersion() {
            return sdkVersion;
      }

      public void setSdkVersion(String sdkVersion) {
            this.sdkVersion = sdkVersion;
      }

      @SerializedName("sdkVersion")
      String sdkVersion;

      @SerializedName("shopperReference")
      String shopperReference;

      public String getUser_id() {
            return user_id;
      }

      public void setUser_id(String user_id) {
            this.user_id = user_id;
      }

      @SerializedName("user_id")
      String user_id;
//
//      @SerializedName("amount")
//      JSONObject amount;

      public amount getAm() {
            return am;
      }

      public void setAm(amount am) {
            this.am = am;
      }

      @com.google.gson.annotations.SerializedName("amount")
      amount am=new amount();

      @SerializedName("reference")
      String reference;

      @SerializedName("countryCode")
      String countryCode;

      @SerializedName("shopperLocale")
      String shopperLocale;

      @SerializedName("token")
      String token;

      @SerializedName("returnUrl")
      String returnUrl;

      public String getSessionValidity() {
            return sessionValidity;
      }

      public void setSessionValidity(String sessionValidity) {
            this.sessionValidity = sessionValidity;
      }

      @SerializedName("sessionValidity")
      String sessionValidity;
}
