package com.ripenapps.rehntu.models.homeListingDetail.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Locations {

    @SerializedName("coordinates")
    ArrayList<String> locations = new ArrayList<>();

    @SerializedName("type")
    String type;

    public ArrayList<String> getLocations() {
        return locations;
    }

    public void setLocations(ArrayList<String> locations) {
        this.locations = locations;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
