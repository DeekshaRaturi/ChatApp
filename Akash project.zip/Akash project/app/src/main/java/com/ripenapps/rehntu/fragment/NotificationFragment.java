package com.ripenapps.rehntu.fragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.NotificationAdapter;
import com.ripenapps.rehntu.models.getAllNotification.request.AllNotificationRequest;
import com.ripenapps.rehntu.models.getAllNotification.request.Notification;
import com.ripenapps.rehntu.models.getAllNotification.response.AllNotificationWrapper;
import com.ripenapps.rehntu.models.login.response.LoginResponseWrapper;
import com.ripenapps.rehntu.my_screen.LoginActivity;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import org.json.JSONException;

import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class NotificationFragment extends Fragment {

    View view;
    APIUtility apiUtility;
    private NotificationAdapter notificationAdapter;
    private ArrayList<Notification>notificationArrayList;
    private RecyclerView notification_recycler;
    private Context context;
    private    String convertedTime;
    private TextView notification_txt;
    private String gmtTime;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_notification, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
        return view;
    }

    private void InitView() {

        notificationArrayList=new ArrayList<>();
        notification_recycler=(RecyclerView)view.findViewById(R.id.notification_recycler);

        if (isNetworkAvailable()) {
            getAllNotification();
        }
        else {

            CommonUtils.alert(getActivity(),"Please check Internet Connection");
        }
        notification_txt=(TextView)view.findViewById(R.id.notification_txt);



    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void convertGmtToLocal( String strDate){

        SimpleDateFormat inputFormat = new  SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        inputFormat.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));

        SimpleDateFormat outputFormat =  new SimpleDateFormat("MMM dd, yyyy h:mm a");

        try {
           Date date = inputFormat.parse(strDate);
            gmtTime = outputFormat.format(date);
            Log.e("output",gmtTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }



    }

    public void getAllNotification(){

        AllNotificationRequest request=new AllNotificationRequest();
        request.setOffset("1");
        request.setUser_id(Preferences.getPreference(getActivity(), PrefEntity.USERID));


        apiUtility.displayAllNotification(getActivity(), request, true, new APIUtility.APIResponseListener<AllNotificationWrapper>() {


            @Override
            public void onReceiveResponse(AllNotificationWrapper response) {

                 try{


                if (response.getResponse().getGetallnotificationResult().getNotifications().size()>0) {

                    for (int i = 0; i <= response.getResponse().getGetallnotificationResult().getNotifications().size() - 1; i++) {
                        try {

                            String notification_body = response.getResponse().getGetallnotificationResult().getNotifications().get(i).get("notification_body").getAsString();
                            String time = response.getResponse().getGetallnotificationResult().getNotifications().get(i).get("time").getAsString();

                            convertGmtToLocal(time);


//                            try {
//                                SimpleDateFormat sourceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//
//
//                                Date date = sourceDateFormat.parse(time);
//
//
//                                SimpleDateFormat targetDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
//
//                                convertedTime = targetDateFormat.format(date);
//
//                                Log.e("datetime", " " + targetDateFormat.format(date));
//
//                            } catch (ParseException e) {
//                                e.printStackTrace();
//                            }


                            notificationArrayList.add(new Notification(notification_body, gmtTime));
                            setAdapter(notificationArrayList);
                            notification_txt.setVisibility(View.GONE);



                        } catch (Exception e) {
                            notification_txt.setVisibility(View.VISIBLE);


                        }
                    }
                }
                else {
                    notification_txt.setVisibility(View.VISIBLE);

                }
                 }
                catch (Exception e){
                    notification_txt.setVisibility(View.VISIBLE);

                 }

            }

            @Override
            public void onResponseFailed() {

            }

            @Override
            public void onStatusFalse(AllNotificationWrapper response) {

            }
        }
        );}




        private void setAdapter(ArrayList<Notification>notificationArrayList){
        notificationAdapter=new NotificationAdapter(this,notificationArrayList);
        notification_recycler.setAdapter(notificationAdapter);
        notification_recycler.setLayoutManager(new LinearLayoutManager(context));



    }





}
