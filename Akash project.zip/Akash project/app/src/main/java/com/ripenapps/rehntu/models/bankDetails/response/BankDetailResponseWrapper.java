package com.ripenapps.rehntu.models.bankDetails.response;

import com.google.gson.annotations.SerializedName;

public class BankDetailResponseWrapper {

    public BankDetailResponse getResponse() {
        return response;
    }

    public void setResponse(BankDetailResponse response) {
        this.response = response;
    }

    @SerializedName("data")
    private BankDetailResponse response;

}
