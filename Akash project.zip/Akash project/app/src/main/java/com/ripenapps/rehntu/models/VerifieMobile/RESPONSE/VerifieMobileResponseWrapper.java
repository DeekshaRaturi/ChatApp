package com.ripenapps.rehntu.models.VerifieMobile.RESPONSE;

import com.google.gson.annotations.SerializedName;

public class VerifieMobileResponseWrapper {
    @SerializedName("data")
    private VerifieMobileResponse response;

    public VerifieMobileResponse getResponse() {
        return response;
    }

    public void setResponse(VerifieMobileResponse response) {
        this.response = response;
    }
}
