package com.ripenapps.rehntu.models.getAllNotification.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.notification.response.NotificationResponse;

public class AllNotificationWrapper {

    public AllNotificationResponse getResponse() {
        return response;
    }

    public void setResponse(AllNotificationResponse response) {
        this.response = response;
    }

    @SerializedName("data")
    private AllNotificationResponse response;
}
