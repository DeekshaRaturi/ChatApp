package com.ripenapps.rehntu.models.transaction.response;

import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.bookNow.response.Address;

import java.util.ArrayList;

public class GetTransactionResult {

    public ArrayList<JsonObject> getBooking_list() {
        return booking_list;
    }

    public void setBooking_list(ArrayList<JsonObject> booking_list) {
        this.booking_list = booking_list;
    }

    @SerializedName("bookings")
    ArrayList<JsonObject> booking_list =new ArrayList<>();

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @SerializedName("message")
    private String message;

    public ArrayList<JsonObject> getList1() {
        return list1;
    }

    public void setList1(ArrayList<JsonObject> list1) {
        this.list1 = list1;
    }

    @SerializedName("address")
    ArrayList<JsonObject>list1=new ArrayList<>();


    @SerializedName("fullAddress")
    private String fullAddress;

    @SerializedName("_id")
    private String id;

    public ServiceAddress getAddress() {
        return address;
    }

    public void setAddress(ServiceAddress address) {
        this.address = address;
    }

    @com.google.gson.annotations.SerializedName("serviceAddress")
    @Expose
    ServiceAddress address = new ServiceAddress();



    @SerializedName("service_id")
    private String service_id;


    @SerializedName("service_provider_id")
    private String service_provider_id;

    @SerializedName("buyer_id")
    private String buyer_id;

    @SerializedName("service_name")
    private String service_name;

    @SerializedName("price")
    private Integer price;

    @SerializedName("service_provider_name")
    private String service_provider_name;

    public String getBuyer_name() {
        return buyer_name;
    }

    public void setBuyer_name(String buyer_name) {
        this.buyer_name = buyer_name;
    }

    @SerializedName("buyer_name")
    private String buyer_name;

    public String getIs_buyer() {
        return is_buyer;
    }

    public void setIs_buyer(String is_buyer) {
        this.is_buyer = is_buyer;
    }

    @SerializedName("is_buyer")
    private String is_buyer;



    public ArrayList<JsonObject> getStatus() {
        return status;
    }

    public void setStatus(ArrayList<JsonObject> status) {
        this.status = status;
    }

    @SerializedName("status")
    private ArrayList<JsonObject> status;



    public String getService_provider_name() {
        return service_provider_name;
    }

    public void setService_provider_name(String service_provider_name) {
        this.service_provider_name = service_provider_name;
    }



    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getService_provider_id() {
        return service_provider_id;
    }

    public void setService_provider_id(String service_provider_id) {
        this.service_provider_id = service_provider_id;
    }

    public String getBuyer_id() {
        return buyer_id;
    }

    public void setBuyer_id(String buyer_id) {
        this.buyer_id = buyer_id;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getTransection_id() {
        return transection_id;
    }

    public void setTransection_id(String transection_id) {
        this.transection_id = transection_id;
    }

    @SerializedName("transection_id")
    private String transection_id;

    public String getSecurityDeposite() {
        return securityDeposite;
    }

    public void setSecurityDeposite(String securityDeposite) {
        this.securityDeposite = securityDeposite;
    }

    @SerializedName("securityDeposite")
    private String securityDeposite;



}
