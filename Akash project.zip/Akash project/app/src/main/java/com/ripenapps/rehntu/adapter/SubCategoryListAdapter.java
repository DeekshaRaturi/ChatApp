package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.subcategory.response.SubCategory;


import java.util.ArrayList;
import java.util.List;

public class SubCategoryListAdapter extends RecyclerView.Adapter<SubCategoryListAdapter.ViewHolder> {

    private Context mContext;
    private List<SubCategory> categoryList;
    private ArrayList<String> selectedList= new ArrayList<>();
    private ArrayList<String> subCategoryListId= new ArrayList<>();
    public SubCategoryListAdapterCallback callback;


    public SubCategoryListAdapter(List<SubCategory> streetList, Context mContext) {
        this.mContext = mContext;
        this.categoryList = streetList;
        this.callback = (SubCategoryListAdapterCallback) mContext;

    }

    @Override
    public SubCategoryListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new SubCategoryListAdapter.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.sub_category_list, parent, false));
    }


    @Override
    public void onBindViewHolder(final SubCategoryListAdapter.ViewHolder holder, final int position) {
           holder.SubcategoryName.setText(categoryList.get(position).getName());
           holder.list.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {

                   if(categoryList.get(position).isSelected()){
                       if(!selectedList.isEmpty())
                       selectedList.remove(categoryList.get(position).getName());
                       subCategoryListId.remove(categoryList.get(position).getId());
                       callback.addItem(selectedList,subCategoryListId);
                       holder.SubcategoryName.setTextColor(mContext.getResources().getColor(R.color.black) );
                       categoryList.get(position).setSelected(false);
                   }else{
                       selectedList.add(categoryList.get(position).getName());
                       subCategoryListId.add(categoryList.get(position).getId());
                       callback.addItem(selectedList,subCategoryListId);
                       categoryList.get(position).setSelected(true);
                       holder.SubcategoryName.setTextColor(mContext.getResources().getColor(R.color.colorPrimary) );

                   }


               }
           });
    }


    @Override
    public int getItemCount() {
        return categoryList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout list;
        private TextView SubcategoryName;


        ViewHolder(View itemView) {
            super(itemView);

            SubcategoryName = (TextView) itemView.findViewById(R.id.text);
            list=(LinearLayout)itemView.findViewById(R.id.list);
        }


    }

    public interface SubCategoryListAdapterCallback {
        public void addItem(ArrayList<String> list, ArrayList<String> subCategoryId);
    }
}


