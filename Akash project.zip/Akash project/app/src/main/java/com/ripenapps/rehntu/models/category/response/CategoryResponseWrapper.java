package com.ripenapps.rehntu.models.category.response;

import com.google.gson.annotations.SerializedName;

public class CategoryResponseWrapper {

    @SerializedName("data")
    private CategoryResponse response;

    public CategoryResponse getResponse() {
        return response;
    }

    public void setResponse(CategoryResponse response) {
        this.response = response;
    }
}
