package com.ripenapps.rehntu.models.payment.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;
import com.ripenapps.rehntu.models.paymentSession.response.PaymentResult;

public class PaymentResponseValue extends BaseResponse {

    public PaymentResultValue getGetPaymentResult() {
        return getPaymentResult;
    }

    public void setGetPaymentResult(PaymentResultValue getPaymentResult) {
        this.getPaymentResult = getPaymentResult;
    }

    @SerializedName("result")
    private PaymentResultValue getPaymentResult;



}
