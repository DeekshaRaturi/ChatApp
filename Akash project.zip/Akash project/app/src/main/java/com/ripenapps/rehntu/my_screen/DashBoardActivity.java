package com.ripenapps.rehntu.my_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.AccountFragment;
import com.ripenapps.rehntu.fragment.ListingFragment;
import com.ripenapps.rehntu.fragment.NotificationFragment;
import com.ripenapps.rehntu.fragment.HomeFragment;
import com.ripenapps.rehntu.fragment.Transactionfragment;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class DashBoardActivity extends BaseActivity implements View.OnClickListener, AccountFragment.AccountCallback {
    public AppCompatTextView toolbar_title_main;
    private TabLayout tabLayout;
    private FrameLayout container;
    private ImageView homebutton, filter,transaction_filter;
    private TextView txt_logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        initViewS();
    }

    private void initViewS() {
        filter = (ImageView) findViewById(R.id.filter);
        tabLayout = (TabLayout) findViewById(R.id.tabs);
        toolbar_title_main = (AppCompatTextView) findViewById(R.id.title);
        container = (FrameLayout) findViewById(R.id.container);
        homebutton = (ImageView) findViewById(R.id.homebutton);
        txt_logout=(TextView)findViewById(R.id.txt_logout);
        transaction_filter=(ImageView)findViewById(R.id.transaction_filter);
        homebutton.setOnClickListener(this);
        txt_logout.setOnClickListener(this);
        transaction_filter.setOnClickListener(this);
        filter.setOnClickListener(this);
        setupTabIcons();

        if (getIntent().hasExtra("come") || getIntent().hasExtra("AddService")) {
            tabLayout.getTabAt(0).select();
            replaceFragment(new ListingFragment());
            toolbar_title_main.setText("Listing");
            filter.setVisibility(View.GONE);
        } else {
            tabLayout.getTabAt(2).select();
            replaceFragment(new HomeFragment());
            toolbar_title_main.setText("Search");
            filter.setVisibility(View.VISIBLE);
        }
        tabselection();


    }


    private void tabselection() {
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        replaceFragment(new ListingFragment());
                        tabLayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.colorPrimary));
                        toolbar_title_main.setText("Listing");
                        filter.setVisibility(View.GONE);
                        txt_logout.setVisibility(View.GONE);
                        transaction_filter.setVisibility(View.GONE);
                        break;

                    case 1:
                        replaceFragment(new Transactionfragment());
                        tabLayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.colorPrimary));
                        toolbar_title_main.setText("Transaction");
                        filter.setVisibility(View.GONE);
                        txt_logout.setVisibility(View.GONE);
                        transaction_filter.setVisibility(View.VISIBLE);


                        break;

                    case 2:
                        replaceFragment(new HomeFragment());
                        toolbar_title_main.setText("Search");
                        filter.setVisibility(View.VISIBLE);
                        txt_logout.setVisibility(View.GONE);
                        transaction_filter.setVisibility(View.GONE);


                        break;

                    case 3:
                        replaceFragment(new NotificationFragment());
                        toolbar_title_main.setText("Notification");
                        filter.setVisibility(View.GONE);
                        txt_logout.setVisibility(View.GONE);
                        transaction_filter.setVisibility(View.GONE);


                        break;

                    case 4:
                        replaceFragment(new AccountFragment());
                        toolbar_title_main.setText("Account");
                        filter.setVisibility(View.GONE);
                        txt_logout.setVisibility(View.VISIBLE);
                        transaction_filter.setVisibility(View.GONE);


                        break;
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void setupTabIcons() {
        tabLayout.addTab(tabLayout.newTab().setText("Listing").setIcon(R.drawable.tab_selector_listing));
        tabLayout.addTab(tabLayout.newTab().setText("Transaction").setIcon(R.drawable.tab_selector_transection));
        tabLayout.addTab(tabLayout.newTab().setText(""));
        tabLayout.addTab(tabLayout.newTab().setText("Notification").setIcon(R.drawable.tab_selector_notification));
        tabLayout.addTab(tabLayout.newTab().setText("Account").setIcon(R.drawable.tab_selector_account));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.homebutton:
                tabLayout.getTabAt(2).select();
                tabLayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.colorWhite));
                replaceFragment(new HomeFragment());
                break;


            case R.id.filter:
                Intent intent= new Intent(DashBoardActivity.this,MapFilterActivity.class);
                startActivity(intent);
                break;


            case R.id.txt_logout:

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setMessage("Are You sure,you want to Logout?");
                        alertDialogBuilder.setPositiveButton("yes",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface arg0, int arg1) {
                                        doLOgout();

                                    }
                                });

                alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                   @Override
                    public void onClick(DialogInterface dialog, int which) {
                       dialog.dismiss();

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();



                break;

            case R.id.transaction_filter:

                Intent intent1=new Intent(DashBoardActivity.this,TransactionFilterActivity.class);
                startActivity(intent1);

        }
    }


    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }


    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_name))
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton("No", null)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        finishAffinity();
                    }
                }).create().show();


    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void doLOgout() {
        if (AccessToken.getCurrentAccessToken() != null)
            LoginManager.getInstance().logOut();
        clearUserDetails();
        Intent intent = new Intent(DashBoardActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
