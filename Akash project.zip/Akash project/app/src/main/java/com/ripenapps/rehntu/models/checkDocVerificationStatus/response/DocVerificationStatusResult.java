package com.ripenapps.rehntu.models.checkDocVerificationStatus.response;

import com.google.gson.annotations.SerializedName;

public class DocVerificationStatusResult {

    @SerializedName("status")
    private String Status;
    @SerializedName("is_verified")
    private boolean isVerified;
    @SerializedName("_id")
    private String Id;
    @SerializedName("name")
    private String Name;
    @SerializedName("email")
    private String Email;
    @SerializedName("mobile_no")
    private String Mobile;
    @SerializedName("social_id")
    private String SocialId;
    @SerializedName("created_at")
    private String Creaated;
    @SerializedName("_v")
    private String Version;

    @SerializedName("doc_verify")
    private String doc_Verify;

    @SerializedName("document_type")
    private String document_type;

    @SerializedName("country_code")
    private String country_code;

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getSocialId() {
        return SocialId;
    }

    public void setSocialId(String socialId) {
        SocialId = socialId;
    }

    public String getCreaated() {
        return Creaated;
    }

    public void setCreaated(String creaated) {
        Creaated = creaated;
    }

    public String getVersion() {
        return Version;
    }

    public void setVersion(String version) {
        Version = version;
    }

    public String getDoc_Verify() {
        return doc_Verify;
    }

    public void setDoc_Verify(String doc_Verify) {
        this.doc_Verify = doc_Verify;
    }

    public String getDocument_type() {
        return document_type;
    }

    public void setDocument_type(String document_type) {
        this.document_type = document_type;
    }
}
