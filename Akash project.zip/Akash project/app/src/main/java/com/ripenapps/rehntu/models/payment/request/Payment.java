package com.ripenapps.rehntu.models.payment.request;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.paymentSession.request.amount;

public class Payment {


      public String getPayload() {
            return payload;
      }

      public void setPayload(String payload) {
            this.payload = payload;
      }

      public String getUser_id() {
            return user_id;
      }

      public void setUser_id(String user_id) {
            this.user_id = user_id;
      }

      @SerializedName("payload")
      String payload;

      @SerializedName("user_id")
      String user_id;


}
