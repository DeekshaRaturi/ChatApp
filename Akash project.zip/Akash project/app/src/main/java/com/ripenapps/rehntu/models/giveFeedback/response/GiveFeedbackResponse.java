package com.ripenapps.rehntu.models.giveFeedback.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class GiveFeedbackResponse extends BaseResponse{


    @SerializedName("result")
    private GiveFeedbackResult result;


    public GiveFeedbackResult getResult() {
        return result;
    }

    public void setResult(GiveFeedbackResult result) {
        this.result = result;
    }
}
