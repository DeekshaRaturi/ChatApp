package com.ripenapps.rehntu.models.changepassword.response;

import com.google.gson.annotations.SerializedName;

public class ForgotPassChangeResponseWrapper {

    @SerializedName("data")
    private ForgotPassChangeResponse response;

    public ForgotPassChangeResponse getResponse() {
        return response;
    }

    public void setResponse(ForgotPassChangeResponse response) {
        this.response = response;
    }
}
