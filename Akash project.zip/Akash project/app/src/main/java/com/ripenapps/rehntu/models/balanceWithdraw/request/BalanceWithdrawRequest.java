package com.ripenapps.rehntu.models.balanceWithdraw.request;

import android.content.Intent;

import com.google.gson.annotations.SerializedName;

public class BalanceWithdrawRequest {

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("status")
    private Integer status;
}
