package com.ripenapps.rehntu.models.walletamount.response;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class GetWalletResult {

    public double getAmount() {
        return amount;

    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    @SerializedName("amount")
    private double amount;

    public ArrayList<JsonObject> getAll() {
        return all;
    }

    public void setAll(ArrayList<JsonObject> all) {
        this.all = all;
    }

    @SerializedName("all")
    private ArrayList<JsonObject>all;

}
