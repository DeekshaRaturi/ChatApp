package com.ripenapps.rehntu.models.forgot.request;

import com.google.gson.annotations.SerializedName;

public class ForgotRequest {

    @SerializedName("email")
    private String Email;

    public ForgotRequest(String email) {
        Email = email;
    }

}
