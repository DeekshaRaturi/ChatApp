package com.ripenapps.rehntu.my_util;

public interface OnClicklistener {
    void click(Integer pos,String price);

    void declineclick(Integer pos,String price);

}
