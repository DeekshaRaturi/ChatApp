package com.ripenapps.rehntu.my_screen

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.content.ContextCompat
import android.support.v4.view.ViewPager
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.TabAdapter
import com.ripenapps.rehntu.adapter.ViewPagerAdapter
import com.ripenapps.rehntu.fragment.*
import com.ripenapps.rehntu.models.balanceWithdraw.request.BalanceWithdrawRequest
import com.ripenapps.rehntu.models.balanceWithdraw.response.BalanceWithdrawResponseWrapper
import com.ripenapps.rehntu.models.bankDetails.response.BankDetailResponseWrapper
import com.ripenapps.rehntu.models.payment.request.Payment
import com.ripenapps.rehntu.models.payment.response.PaymentWrapperValue
import com.ripenapps.rehntu.models.walletamount.request.GetWalletRequest
import com.ripenapps.rehntu.models.walletamount.response.GetWalletWrapper
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class TransactionHistoryActivity : AppCompatActivity(),View.OnClickListener {

    var title:TextView?=null
    var cancle_img:ImageView?=null
    private var adapter: ViewPagerAdapter? = null
    private var tabLayout: TabLayout? = null
    private var viewPager: ViewPager? = null
    private var apiUtility:APIUtility?=null
    private var txt_total_amount:TextView?=null
    private var convertedTime:String?=null
    private var butn_transfer:Button?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaction_history)

        init()
    }

    fun init() {

        apiUtility= APIUtility(applicationContext)

        title = findViewById<View>(R.id.title) as TextView
        title!!.text="Transaction History"
        txt_total_amount=findViewById(R.id.txt_total_amount)


        butn_transfer=findViewById<Button>(R.id.butn_transfer)
        butn_transfer?.setOnClickListener(this)



        cancle_img = findViewById<View>(R.id.img_close) as ImageView
        cancle_img!!.setOnClickListener(this)

        viewPager = findViewById(R.id.viewPager) as ViewPager
        tabLayout = findViewById(R.id.tabLayout) as TabLayout

        adapter=ViewPagerAdapter(supportFragmentManager)


        viewPager?.setAdapter(adapter)
        tabLayout?.setupWithViewPager(viewPager)

        getwalletAmount()







    }



    fun getwalletAmount() {

        var amount = GetWalletRequest()
        amount.type = "all"
        amount.user_id = Preferences.getPreference(this@TransactionHistoryActivity, PrefEntity.USERID)



        apiUtility?.displayAllAmount(this@TransactionHistoryActivity, amount, true, object : APIUtility.APIResponseListener<GetWalletWrapper> {
            override fun onReceiveResponse(response: GetWalletWrapper?) {
                var gson = Gson()
                Log.e("displaywallet", "" + gson.toJson(response))
                var price=response?.response?.getWalletResult?.amount
                Log.e("amountt",""+price)
                txt_total_amount!!.text=price.toString()

                if (price!!.equals(0.0)){

                    butn_transfer!!.setBackgroundColor(ContextCompat.getColor(applicationContext,R.color.garycolor))
                    butn_transfer?.isClickable=false
                }






            }

            override fun onResponseFailed() {
                Log.e("error", "error")

            }

            override fun onStatusFalse(response: GetWalletWrapper?) {
                Log.e("status","status0")

            }


        })

    }

    override fun onClick(v: View?) {
        when(v?.id){

            R.id.img_close->{
                finish()
                Log.e("click","click")

            }
            R.id.butn_transfer->{

                withDrawBalance()

            }
        }

    }

    fun withDrawBalance(){

        var balanceWithdrawRequest=BalanceWithdrawRequest()
        balanceWithdrawRequest.user_id=Preferences.getPreference(applicationContext,PrefEntity.USERID)
        balanceWithdrawRequest.status=1
        val gson = Gson()
        Log.e("withdrawre", "" + gson.toJson(balanceWithdrawRequest))

        apiUtility?.balancewithDraw(this@TransactionHistoryActivity, balanceWithdrawRequest, true, object : APIUtility.APIResponseListener<BalanceWithdrawResponseWrapper> {
            override fun onReceiveResponse(response: BalanceWithdrawResponseWrapper?) {

               /* var price=response?.response?.result?.amount
                Log.e("amountt",""+price)
                txt_total_amount!!.text=price.toString()*/
                getwalletAmount()
                butn_transfer!!.setBackgroundColor(ContextCompat.getColor(applicationContext,R.color.garycolor))


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: BalanceWithdrawResponseWrapper?) {

            }


        })



    }

}
