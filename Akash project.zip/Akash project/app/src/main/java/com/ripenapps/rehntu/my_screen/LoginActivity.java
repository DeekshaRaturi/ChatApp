package com.ripenapps.rehntu.my_screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.os.Bundle;
import android.text.LoginFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.crashlytics.android.Crashlytics;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.gson.Gson;
import com.hbb20.CountryCodePicker;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.checkRegistration.request.CheckRegistrationReq;
import com.ripenapps.rehntu.models.checkRegistration.response.CheckRegistrationResponseWrapper;
import com.ripenapps.rehntu.models.login.request.LoginRequest;
import com.ripenapps.rehntu.models.login.response.LoginResponseWrapper;
import com.ripenapps.rehntu.models.notification.request.NotificationRequest;
import com.ripenapps.rehntu.models.notification.response.NotificationWrapper;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

import io.fabric.sdk.android.Fabric;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class LoginActivity extends BaseActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {
    private static final int G_SIGN_IN = 007;
    APIUtility apiUtility;
    ImageView facebook_login;
    ImageView google_login;
    boolean isSocialLogin = false;
    GoogleApiClient googleApiClient;
    String id = "";
    String stringEmail = "";
    String firstname = "";
    String lastname = "";
    String SocailID = "";
    String stringNumber = "";
    private LoginButton facebook_login_btn;
    private CallbackManager callbackManager;
    private SignInButton btn_sign_in_google;
    private EditText emailText, passwordText;
    private TextView forgot_password;
    private Button loginButton;
    private TextView sign_up;
    private LoginRequest loginRequest;
    private EditText editTextMobile;
    private String social_id;
    private String personName;
    private String password;
    Dialog dialog;
    Dialog numberDialog;
    String countryCodeAndroid;
    boolean isNewUser = false;
    LinearLayout signuplayout;
    private static final String BASE_URL = "http://18.216.101.125:3000/mobile_api/";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RhentoSingleton.getInstance();
        Fabric.with(this,new Crashlytics());
        setContentView(R.layout.activity_login);
        GoogleSignInOptions signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        googleApiClient = new GoogleApiClient.Builder(this).enableAutoManage(this, this).addApi(Auth.GOOGLE_SIGN_IN_API, signInOptions).build();

        init();
        apiUtility = new APIUtility(LoginActivity.this);



    }


    private void loginFacebookMethod() {
        facebook_login_btn.performClick();
        callbackManager = CallbackManager.Factory.create();

        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d("onSuccessFB: ", "" + loginResult.getAccessToken());
                loginResult.getAccessToken();
                //getNotification();
                getGraphData(loginResult.getAccessToken().getUserId());


            }

            @Override
            public void onCancel() {
//                CommonUtils.alert(LoginActivity.this, "Cancelled");

            }

            @Override
            public void onError(FacebookException error) {
                CommonUtils.alert(LoginActivity.this, error.getMessage().toString());

            }
        });

    }


    private void getGraphData(String userID) {

        social_id = userID;
        final GraphRequest request = new GraphRequest(
                AccessToken.getCurrentAccessToken(),
                "/" + userID, null, HttpMethod.GET, new GraphRequest.Callback() {
            public void onCompleted(GraphResponse response) {
                try {
                    JSONObject object = response.getJSONObject();
                    Log.d("OBJECT", object.toString());
                    if (object.has("id")) {
                        id = object.getString("id");
                    }
                    if (object.has("first_name")) {
                        firstname = object.getString("first_name");
                    }
                    if (object.has("last_name")) {
                        lastname = object.getString("last_name");
                    }
                    if (object.has("email")) {
                        stringEmail = object.getString("email");
                    }

                    Log.e("UserName", firstname + " " + lastname);
                    Log.e("UserEmail", stringEmail);
                    Log.e("UserID", id);


                } catch (Exception e) {
                    e.printStackTrace();
                    CommonUtils.alert(LoginActivity.this, e.getMessage().toString());
                }
            }
        });

        Bundle parameters = new Bundle();
        parameters.putString("fields", "email,first_name,last_name");
        request.setParameters(parameters);
        request.executeAsync();


        RhentoSingleton.getInstance().setName(firstname + " " + lastname);
        RhentoSingleton.getInstance().setEmail(stringEmail);
        RhentoSingleton.getInstance().setLogin_type("FB");
        RhentoSingleton.getInstance().setMobile_num("");
        RhentoSingleton.getInstance().setSocial_id(social_id);
        RhentoSingleton.getInstance().setPassword("");

        LoginAttempt("FB", firstname + " " + lastname, stringEmail, "", "", "", social_id);


    }

    public final boolean containsDigit(String s) {
        boolean containsDigit = false;

        if (s != null && !s.isEmpty()) {
            for (char c : s.toCharArray()) {
                if (containsDigit = Character.isDigit(c)) {
                    break;
                }
            }
        }

        return containsDigit;
    }

    private boolean onlyContainsNumbers(String text) {
        try {
            Long.parseLong(text);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private void validate() {
        boolean valid = true;
        View focusView = null;
//        emailText.setError(null);
//        passwordText.setError(null);
        stringEmail = emailText.getText().toString();
        password = passwordText.getText().toString();


        if (TextUtils.isEmpty(stringEmail)) {

            CommonUtils.alert(LoginActivity.this,getString(R.string.alert_email_mobile_valid));

//            emailText.setError("Enter a valid email or Mobile number");
            valid = false;
            focusView = emailText;
        } else if (!(CommonUtils.isValidMobNumber(stringEmail) || CommonUtils.isEmailValid(stringEmail))) {
            if (onlyContainsNumbers(stringEmail)) {
                CommonUtils.alert(LoginActivity.this,getString(R.string.alert_mobile_valid));

//                emailText.setError(getString(R.string.alert_mobile_valid));
                valid = false;
                focusView = emailText;
            } else {

                CommonUtils.alert(LoginActivity.this,getString(R.string.alert_email_valid));

//                emailText.setError(getString(R.string.alert_email_valid));
                valid = false;
                focusView = emailText;
            }

        } else if (TextUtils.isEmpty(password) ) {
            CommonUtils.alert(LoginActivity.this,getString(R.string.alert_password));

//            passwordText.setError(getString(R.string.password_length));
            valid = false;
            focusView = passwordText;
        }
        else if (password.length()<8 ) {
            CommonUtils.alert(LoginActivity.this,getString(R.string.password_length));

//            passwordText.setError(getString(R.string.password_length));
            valid = false;
            focusView = passwordText;
        }


        if (valid) {
            RhentoSingleton.getInstance().setLogin_type("EM");
            RhentoSingleton.getInstance().setPassword(passwordText.getText().toString());
            RhentoSingleton.getInstance().setEmail(emailText.getText().toString());
            RhentoSingleton.getInstance().setSocial_id("");
            RhentoSingleton.getInstance().setName("");
            RhentoSingleton.getInstance().setMobile_num("");


            LoginAttempt("EM", "", emailText.getText().toString(), passwordText.getText().toString(), "", "", "");


        } else {
            focusView.requestFocus();
        }

    }

    private void init() {
        facebook_login = findViewById(R.id.facebook_login);
        facebook_login_btn = findViewById(R.id.facebook_login_button);
        google_login = findViewById(R.id.google_login);
        btn_sign_in_google = findViewById(R.id.btn_sign_in_google);
        emailText = findViewById(R.id.login_email_mobile);
        passwordText = findViewById(R.id.login_password);
        forgot_password = findViewById(R.id.forgot_password);
        loginButton = findViewById(R.id.login_button);
        sign_up = findViewById(R.id.sign_up);
        signuplayout=findViewById(R.id.signuplayout);

        facebook_login.setOnClickListener(this);
        google_login.setOnClickListener(this);
        forgot_password.setOnClickListener(this);
        loginButton.setOnClickListener(this);
       /* sign_up.setOnClickListener(this);*/
        signuplayout.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.facebook_login:

                isSocialLogin = true;
                /*if (AccessToken.getCurrentAccessToken() != null) {
                    LoginManager.getInstance().logOut();
                } else {*/
                    loginFacebookMethod();
//                }

                break;
            case R.id.google_login:
                btn_sign_in_google.performClick();
                Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
                startActivityForResult(signInIntent, G_SIGN_IN);
                break;


            case R.id.signuplayout:
                Intent intent4 = new Intent(this, SignupActivity.class);
                startActivity(intent4);
                break;

            case R.id.forgot_password:
                Intent intent1 = new Intent(this, ForgetPassActivity.class);
                startActivity(intent1);
                break;

            case R.id.login_button: {

                validate();
                break;
            }

        }

    }


    void LoginAttempt(final String loginType, final String name, final String email, final String password, final String mobile, final String county_code, final String socialid) {

        LoginRequest request = new LoginRequest();
        request.setEmail(email);
        request.setMobile(mobile);
        request.setLoginType(loginType);
        request.setName(name);
        request.setPassword(password);
        request.setCountry_code(county_code);
        request.setSocialID(socialid);



        apiUtility.userLogin(LoginActivity.this, request, true, new APIUtility.APIResponseListener<LoginResponseWrapper>() {
            @Override
            public void onReceiveResponse(LoginResponseWrapper response) {
                if (response != null) {
                    setUserDetails(response.getResponse().getResult().getEmail(), response.getResponse().getResult().getMobile(), response.getResponse().getResult().getName(), response.getResponse().getResult().getId(), response.getResponse().getResult().isVerified(), response.getResponse().getResult().getDoc_Verify(), response.getResponse().getResult().getCountry_code());
                   String url=response.getResponse().getResult().getProfileImage();

                   Log.e("url1",""+url);
                  // Uri uri=Uri.parse();
                   //Uri uri1=Uri.fromFile(uri.toString())
//                    try {
//                        URL url1 = new URL(BASE_URL+url);
//                        Bitmap image = BitmapFactory.decodeStream(url1.openConnection().getInputStream());
//                        Log.e("urii",""+image);
//
//                    } catch(IOException e) {
//                        System.out.println(e);
//                    }




//
//                    Preferences.setPreference(getApplicationContext(),PrefEntity.PROFILE_IMAGE,response.getResponse().getResult().getProfileImage());
                    if (!response.getResponse().getResult().isVerified()) {
                        Intent intent = new Intent(LoginActivity.this, VerificationActivity.class);
                        intent.putExtra("activity", "Login");
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        //getNotification();
                    } else {
                        Intent intent = new Intent(LoginActivity.this, GetCurrentLocationActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onResponseFailed() {
                LoginManager.getInstance().logOut();
                CommonUtils.alert(LoginActivity.this, getString(R.string.VolleyError));

            }

            @Override
            public void onStatusFalse(LoginResponseWrapper response) {

                switch (response.getResponse().getStatus()) {
                    case 0:
                        CommonUtils.alert(LoginActivity.this, response.getResponse().getMessage());
                        break;
                    case 2:

                        LoginValidation(loginType);
                        break;

                    case 4:
                        Intent intent = new Intent(LoginActivity.this, UpdatePasswordActivity.class);
                        intent.putExtra("email", email);
                        startActivity(intent);
                        finish();

                        break;

                    default:
                        CommonUtils.alert(LoginActivity.this, "Error Code 1133! Try again");
                        break;

                }

            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == G_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleSignInResult(result);

        } else {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }


    }

    private void handleSignInResult(GoogleSignInResult result) {

        Log.e("StatusResult: ", "" + result.getStatus().getStatusMessage()+" "+result.getStatus().getStatusMessage()+" "+result.getStatus().getStatusCode()+" "+result.isSuccess());

        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            Log.e("display_name: ", "" + acct.getDisplayName());
            personName = acct.getDisplayName();
            stringEmail = acct.getEmail();
            social_id = acct.getId();
           // getNotification();


            RhentoSingleton.getInstance().setName(acct.getDisplayName());
            RhentoSingleton.getInstance().setEmail(acct.getEmail());
            RhentoSingleton.getInstance().setSocial_id(acct.getId());
            RhentoSingleton.getInstance().setMobile_num("");
            RhentoSingleton.getInstance().setLogin_type("G+");

            LoginAttempt("G+", personName, stringEmail, "", "", "", social_id);

            //  LoginValidation("G+");
        } else {
//            CommonUtils.alert(LoginActivity.this, "Error :" + result.getStatus().getStatusMessage() + result.getStatus());
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        CommonUtils.alert(LoginActivity.this, connectionResult.getErrorMessage());

    }

    public void showDialogMobileNumber(Activity activity, final String loginType) {
        numberDialog = new Dialog(activity);
        final LayoutInflater inflater = LayoutInflater.from(activity);
        final View view = inflater.inflate(R.layout.add_mobile_no_dialog, null, false);
        numberDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        numberDialog.setCancelable(false);
        numberDialog.setContentView(view);
        numberDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        editTextMobile = view.findViewById(R.id.edit_text_mobile);
        editTextMobile.setHint("Enter Mobile Number");

        Button sendData = (Button) view.findViewById(R.id.dialogButtonOK);
        ImageView close = (ImageView) view.findViewById(R.id.closeDialogue);
        final CountryCodePicker countryCodePicker = (CountryCodePicker) view.findViewById(R.id.ccp_dialog);

        countryCodePicker.setCountryForPhoneCode(+91);
        RhentoSingleton.getInstance().setCountryCodeAndroid(countryCodePicker.getDefaultCountryCodeWithPlus());
        countryCodeAndroid = countryCodePicker.getDefaultCountryCodeWithPlus();

        countryCodePicker.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected() {
                countryCodeAndroid = countryCodePicker.getSelectedCountryCodeWithPlus();
                RhentoSingleton.getInstance().setCountryCodeAndroid(countryCodePicker.getSelectedCountryCodeWithPlus());
            }
        });

        sendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stringNumber = editTextMobile.getText().toString();
//                editTextMobile.setError(null);
                if (stringNumber.equals("") || stringNumber.isEmpty()) {
                    CommonUtils.alert(LoginActivity.this,getString(R.string.alert_mobile));


//                    editTextMobile.setError("Enter Mobile Number");
                }

                else {

                    if(CommonUtils.isValidMobNumber(stringNumber)) {

//                        editTextMobile.setError(null);
                        numberDialog.dismiss();
                        RhentoSingleton.getInstance().setMobile_num(editTextMobile.getText().toString());
                        isNewUser = true;
                        LoginValidation(loginType);
                    }else{
                        CommonUtils.alert(LoginActivity.this,getString(R.string.alert_mobile_valid));
                    }
                }
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginManager.getInstance().logOut();
                numberDialog.dismiss();
            }
        });

        numberDialog.show();
    }

    public void showDialogEmail(Activity activity, final String loginType) {
        dialog = new Dialog(activity);
        final LayoutInflater inflater = LayoutInflater.from(activity);
        final View view = inflater.inflate(R.layout.entre_email_dialoge, null, false);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(view);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        final EditText editTextemail = view.findViewById(R.id.dialog_mobile);
//        editTextemail.setError(null);
        editTextemail.setHint("Enter Email id");

        Button sendData = (Button) dialog.findViewById(R.id.dialog_send);
        sendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stringEmail = editTextemail.getText().toString();
//                editTextemail.setError(null);
                if (stringEmail.equals("") || stringEmail.isEmpty()) {
                    CommonUtils.alert(LoginActivity.this,getString(R.string.alert_email));
//                    editTextemail.setError("Enter Email id");
                } else if (!CommonUtils.isEmailValid(stringEmail)) {
                    CommonUtils.alert(LoginActivity.this,getString(R.string.alert_email_valid));

//                    editTextemail.setError("Enter Valid Email address");
                } else {
//                    editTextemail.setError(null);
                    RhentoSingleton.getInstance().setEmail(editTextemail.getText().toString());
                    isNewUser = true;
                    LoginValidation(loginType);

                }

            }
        });

        ImageView close = (ImageView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginManager.getInstance().logOut();
                dialog.dismiss();
            }
        });
        dialog.show();

    }

    @Override
    public void onBackPressed() {
        //  super.onBackPressed();
        new AlertDialog.Builder(LoginActivity.this)
                .setMessage("Are you sure want to Exit? ")
                .setTitle(R.string.app_name)
                .setCancelable(false)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton(android.R.string.ok,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                                finish();
                            }
                        }).show();
    }




    void LoginValidation(String login_type) {
        if (login_type.equals("EM")) {
            LoginAttempt(login_type, "", RhentoSingleton.getInstance().getEmail(), RhentoSingleton.getInstance().getPassword(), "", "", "");

        } else if (login_type.equals("FB")) {
            if (RhentoSingleton.getInstance().getEmail().equals("")) {
                showDialogEmail(LoginActivity.this, "FB");
            } else if (RhentoSingleton.getInstance().getMobile_num().equals("")) {
                showDialogMobileNumber(LoginActivity.this, "FB");
            } else if (isNewUser) {
                CheckRegistration(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), "");
            } else {
                LoginAttempt(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), "", RhentoSingleton.getInstance().getMobile_num(), countryCodeAndroid, RhentoSingleton.getInstance().getSocial_id());

            }

        } else if (login_type.equals("G+")) {
            if (RhentoSingleton.getInstance().getEmail().equals("") || RhentoSingleton.getInstance().getEmail().equals(null)) {
                showDialogEmail(LoginActivity.this, "G+");
            } else if (RhentoSingleton.getInstance().getMobile_num().equals("") || RhentoSingleton.getInstance().getMobile_num().equals(null)) {
                showDialogMobileNumber(LoginActivity.this, "G+");
            } else if (isNewUser) {
                CheckRegistration(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), RhentoSingleton.getInstance().getMobile_num(), RhentoSingleton.getInstance().getCountryCodeAndroid(), "");
            } else {
                LoginAttempt(login_type, RhentoSingleton.getInstance().getName(), RhentoSingleton.getInstance().getEmail(), "", RhentoSingleton.getInstance().getMobile_num(), countryCodeAndroid, RhentoSingleton.getInstance().getSocial_id());
            }


        } else {
            CommonUtils.alert(LoginActivity.this, "Something Went Wrong ! Try again.");
        }
    }


    private void CheckRegistration(final String loginType, final String name, final String email, final String phone, final String county_code, final String pass) {

        final CheckRegistrationReq checkRegistrationReq = new CheckRegistrationReq(name, email, phone, county_code, pass);
        apiUtility.checkRegistration(this, checkRegistrationReq, true, new APIUtility.APIResponseListener<CheckRegistrationResponseWrapper>() {
            @Override
            public void onReceiveResponse(CheckRegistrationResponseWrapper response) {
                if (response != null) {
                    isNewUser = false;
                    Intent intent = new Intent(LoginActivity.this, VerificationActivity.class);
                    intent.putExtra("comefrom", "LOGIN");
                    intent.putExtra("loginType",loginType);
                    intent.putExtra("mobile", phone);
                    intent.putExtra("name", name);
                    intent.putExtra("email", email);
                    intent.putExtra("county_code", county_code);
                    startActivity(intent);
                }
            }

            @Override
            public void onResponseFailed() {
                CommonUtils.alert(LoginActivity.this, getString(R.string.VolleyError));
            }

            @Override
            public void onStatusFalse(CheckRegistrationResponseWrapper response) {
                CommonUtils.alert(LoginActivity.this, response.getResponse().getMessage());
            }
        });
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
