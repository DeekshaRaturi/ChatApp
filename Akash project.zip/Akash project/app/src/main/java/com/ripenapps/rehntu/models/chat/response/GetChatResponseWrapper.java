package com.ripenapps.rehntu.models.chat.response;

import com.google.gson.annotations.SerializedName;

public class GetChatResponseWrapper {


    @SerializedName("data")
    private GetChatResponse response;

    public GetChatResponse getResponse() {
        return response;
    }

    public void setResponse(GetChatResponse response) {
        this.response = response;
    }
}
