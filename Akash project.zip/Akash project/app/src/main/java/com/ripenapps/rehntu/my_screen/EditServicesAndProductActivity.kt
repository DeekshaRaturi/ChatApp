package com.ripenapps.rehntu.my_screen

import android.content.Context
import android.content.Intent
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RelativeLayout
import android.widget.TextView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.ImageViewPagerEDitAdapter
import com.ripenapps.rehntu.models.ServiceDetailOnClick.request.ServiceDetailOnClickRequest
import com.ripenapps.rehntu.models.ServiceDetailOnClick.respponse.ServiceDetailOnClickWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.RhentoSingleton
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import java.util.ArrayList

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class EditServicesAndProductActivity : BaseActivity(), View.OnClickListener {
    private var viewPager: ViewPager? = null
    private var tvCategory: TextView? = null
    private var tvSubCategory: TextView? = null
    private var tvDescription: TextView? = null
    private var tvAddress: TextView? = null
    private var edit: TextView? = null
    private var etProductName: TextView? = null
    private var etBasePrice: TextView? = null
    private var etrateperYear: TextView? = null
    private var etYearofPur: TextView? = null
    private var etSecurityDeposite: TextView? = null
    private var productName: TextView? = null
    private val ivBack: ImageView? = null
    private val categoryName: String? = null
    private val strSubCategory = ""
    private var btnSubmit: Button? = null
    private val descriptionResult: String? = null
    private var ivFoerword: ImageView? = null
    private var rlAddress: RelativeLayout? = null
    private var rlCategory: RelativeLayout? = null
    private var rlSubCategory: RelativeLayout? = null
    private var baseprice: RelativeLayout? = null
    private var rateperHour: RelativeLayout? = null
    private var yaerofPurchase: RelativeLayout? = null
    private var securityDeposite: RelativeLayout? = null
    private var homeServiceAvailable: RelativeLayout? = null
    private var llDescription: LinearLayout? = null
    private var apiUtility: APIUtility? = null
    private var back: ImageView? = null
    internal var title: AppCompatTextView?=null
    internal var subCategoryNameList: List<String> = ArrayList()
    internal var imagesList = ArrayList<String>()
    internal var subCategoryName: String?=null
    private var home: RadioGroup? = null
    private var rate: RadioGroup? = null
    private var perDay: RadioButton? = null
    private var perHour: RadioButton? = null
    private var yes: RadioButton? = null
    private var no: RadioButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_services_and_product)
        apiUtility = APIUtility(this)
        initViews()
    }

    private fun initViews() {
        yes = findViewById<View>(R.id.yes) as RadioButton
        no = findViewById<View>(R.id.no) as RadioButton
        perDay = findViewById<View>(R.id.ratePerdaybutton) as RadioButton
        perHour = findViewById<View>(R.id.ratePerhourbutton) as RadioButton
        home = findViewById<View>(R.id.radioGroup1) as RadioGroup
        rate = findViewById<View>(R.id.radioGroup) as RadioGroup

        home!!.isClickable = false
        rate!!.isClickable = false
        yes!!.isClickable = false
        no!!.isClickable = false
        perDay!!.isClickable = false
        perHour!!.isClickable = false
        productName = findViewById<View>(R.id.productName) as TextView
        edit = findViewById(R.id.done)
        edit!!.text = "Edit"
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView


        homeServiceAvailable = findViewById(R.id.homeAvailable_rl)

        viewPager = findViewById(R.id.photos_viewpager)
        etrateperYear = findViewById(R.id.ratePerhour)
        etSecurityDeposite = findViewById(R.id.securityDeposit)
        etYearofPur = findViewById(R.id.yaerofPurchase)

        baseprice = findViewById(R.id.baseprice_rl)
        rateperHour = findViewById(R.id.ratePerhour_rl)
        securityDeposite = findViewById(R.id.securityDeposit_rl)
        yaerofPurchase = findViewById(R.id.yearofPurchase_rl)

        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Service") {
            baseprice!!.visibility = View.VISIBLE
            rateperHour!!.visibility = View.GONE
            securityDeposite!!.visibility = View.GONE
            yaerofPurchase!!.visibility = View.GONE
            title?.text = "Service Details"
            productName!!.text = "Service Name"
            homeServiceAvailable!!.visibility = View.VISIBLE


        } else {
            baseprice!!.visibility = View.GONE
            rateperHour!!.visibility = View.VISIBLE
            securityDeposite!!.visibility = View.VISIBLE
            yaerofPurchase!!.visibility = View.VISIBLE
            title?.text = "Product Details"
            productName!!.text = "Product Name"
            homeServiceAvailable!!.visibility = View.GONE
        }




        tvAddress = findViewById(R.id.tv_address)
        etBasePrice = findViewById(R.id.et_base_price)
        rlAddress = findViewById(R.id.rl_address)
        tvDescription = findViewById(R.id.tv_description)
        etProductName = findViewById(R.id.et_product_name)
        rlCategory = findViewById(R.id.rl_category)
        rlSubCategory = findViewById(R.id.rl_subcategory)
        tvCategory = findViewById(R.id.tv_category)
        tvSubCategory = findViewById(R.id.tv_subcategory)
        btnSubmit = findViewById(R.id.btn_submit)
        ivFoerword = findViewById(R.id.iv_forword)
        llDescription = findViewById(R.id.ll_descr)
        back!!.setOnClickListener(this)
        edit!!.setOnClickListener(this)
        getDetail()


    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.done -> {
                val intent = Intent(this, AfterEditActivity::class.java)
                startActivity(intent)
            }

            R.id.back -> finish()
        }
    }


    internal fun getDetail() {
        val request = ServiceDetailOnClickRequest()
        if (intent.hasExtra("serviceID")) {
            request.serviceId = intent.getStringExtra("serviceID")
        }
        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            request.servicesType = "product"
        } else {
            request.servicesType = "service"
        }

        request.userId = Preferences.getPreference(applicationContext, PrefEntity.USERID)


        apiUtility!!.getServicesProductDetail(this, request, true, object : APIUtility.APIResponseListener<ServiceDetailOnClickWrapper> {
            override fun onReceiveResponse(response: ServiceDetailOnClickWrapper?) {
                if (response != null) {
                    setResponse(response)
                    RhentoSingleton.getInstance().setWrapper(response)
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@EditServicesAndProductActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: ServiceDetailOnClickWrapper) {
                CommonUtils.alert(this@EditServicesAndProductActivity, response.response.message)

            }
        })

    }

    private fun setResponse(response: ServiceDetailOnClickWrapper?) {
        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            etSecurityDeposite!!.text = "" + response!!.response.result.securityDeposit
            if (response.response.result.rate_type == "0") {
                perHour!!.isChecked = true
            } else {
                perDay!!.isChecked = true
            }
            etrateperYear!!.text = "" + response.response.result.rateHour
            etYearofPur!!.text = "" + response.response.result.yearPurchase
        } else {
            if (response!!.response.result.isHome_service_available) {
                yes!!.isChecked = true
            } else {
                no!!.isChecked = true
            }
            etBasePrice!!.text = "" + response.response.result.basePrice
        }

        Preferences.setPreference(applicationContext, PrefEntity.CATEGORYID, response.response.result.categoryId)

        tvDescription!!.text = "" + response.response.result.description
        etProductName!!.text = "" + response.response.result.name
        tvCategory!!.text = "" + response.response.result.categoryName
        tvAddress!!.text = "" + response.response.result.address.fullAddress
        subCategoryNameList = response.response.result.subcategoryName

        imagesList.clear()
        imagesList = response.response.result.images
        setViewPagerAdapter()
        if (subCategoryNameList.size > 0) {

            for (i in subCategoryNameList.indices) {
                if (i == 0) {
                    subCategoryName = subCategoryNameList[i]
                } else {
                    subCategoryName = subCategoryName + "," + subCategoryNameList[i]
                }
            }
            tvSubCategory!!.text = "" + subCategoryName

        } else {
            tvSubCategory!!.text = ""
        }
    }

    private fun setViewPagerAdapter() {
        viewPager!!.adapter = ImageViewPagerEDitAdapter(imagesList, this@EditServicesAndProductActivity)
        val tabLayout = findViewById<View>(R.id.tab_layout) as TabLayout
        tabLayout.setupWithViewPager(viewPager, true)
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }
}
