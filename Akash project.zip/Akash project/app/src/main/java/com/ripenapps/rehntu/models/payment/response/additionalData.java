package com.ripenapps.rehntu.models.payment.response;

import com.google.gson.annotations.SerializedName;

public class additionalData {


    public double getRecurringDetailReference() {
        return recurringDetailReference;
    }

    public void setRecurringDetailReference(double recurringDetailReference) {
        this.recurringDetailReference = recurringDetailReference;
    }

    @SerializedName("recurring.recurringDetailReference")
    private double recurringDetailReference;



    public String getShopperReference() {
        return shopperReference;
    }

    public void setShopperReference(String shopperReference) {
        this.shopperReference = shopperReference;
    }

    @SerializedName("recurring.shopperReference")
    private String shopperReference;
}
