package com.ripenapps.rehntu.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.my_screen.DocVerificationActivity;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

public class DocVerifyFragment extends Fragment implements View.OnClickListener{


    private View view;
    APIUtility apiUtility;
    private TextView verify_account, doc_verification_label;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_docverify, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
        return view;
    }

    private void InitView() {
        verify_account = (TextView) view.findViewById(R.id.verify_account);
        doc_verification_label = (TextView) view.findViewById(R.id.doc_verification_label);
        verify_account.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent= new Intent(getActivity(), DocVerificationActivity.class);
        startActivity(intent);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (Preferences.getPreference(getActivity(), PrefEntity.DOCVERIFY).equals("1")){
            verify_account.setVisibility(View.INVISIBLE);
            verify_account.setClickable(false);
            doc_verification_label.setText("Your document is uploaded successfully you will \n receive approval via email after varification.");
        }    }
}
