package com.ripenapps.rehntu.models.services.request;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ServiceRequest {

    @SerializedName("services_type")@Expose
    private String services_type;

    @SerializedName("user_id")@Expose
    private String user_id;

    public String getServices_type() {
        return services_type;
    }

    public void setServices_type(String services_type) {
        this.services_type = services_type;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
