package com.ripenapps.rehntu.models.checkDocVerificationStatus.response;

import com.google.gson.annotations.SerializedName;

public class DocVerificationStatusResponseWrapper {
    @SerializedName("data")
    private DocVerificationStatusResponse response;

    public DocVerificationStatusResponse getResponse() {
        return response;
    }

    public void setResponse(DocVerificationStatusResponse response) {
        this.response = response;
    }
}
