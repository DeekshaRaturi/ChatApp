package com.ripenapps.rehntu.my_screen

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.CardView
import android.util.Log
import android.view.View
import android.widget.*
import com.android.volley.*
import com.google.gson.Gson

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.VollySupport.VolleyMultipartRequest
import com.ripenapps.rehntu.VollySupport.VolleySingleton
import com.ripenapps.rehntu.models.checkDocVerificationStatus.request.DocVerificationStatusRequest
import com.ripenapps.rehntu.models.checkDocVerificationStatus.response.DocVerificationStatusResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream

import java.io.IOException
import java.util.HashMap

class AccountVerificationActivity : AppCompatActivity(), View.OnClickListener {

    private var title: TextView? = null
    private var cancle_img: ImageView? = null
    private var img_photoId: ImageView? = null
    private var img_removePic: ImageView? = null
    private var uploadimg_cardview: CardView? = null
    private val GALLERY_IMAGE = 2
    private val CAMERA = 1
    private var apiUtility:APIUtility?=null
    private var uncheck_img_upload:ImageView?=null
    private var uncheck_img_payment:ImageView?=null
    private var uncheck_img_document:ImageView?=null
    private var photoId_cardview:CardView?=null
    var document_type_spinner: Spinner?=null
    var image: ByteArray? = null
    var btn_submit:Button?= null
    var txt_header:TextView?=null
    var img_relative:RelativeLayout?= null
    var picker_cardview:CardView?= null
    var submit_layout:RelativeLayout?=null


    internal var uploadDoc: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            UploadDocument(Preferences.getPreference(this@AccountVerificationActivity, PrefEntity.USERID), document_type_spinner?.getSelectedItem().toString())

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_verification)

        initViews()
        LocalBroadcastManager.getInstance(this@AccountVerificationActivity).registerReceiver(uploadDoc, IntentFilter("startUpload"))


    }

    private fun initViews() {
        title = findViewById<View>(R.id.title) as TextView
        apiUtility= APIUtility(this@AccountVerificationActivity)

        txt_header=findViewById(R.id.txt_header)
        img_relative=findViewById(R.id.img_relative)
        picker_cardview=findViewById(R.id.picker_cardview)

        title!!.text = "Account Verification"
        cancle_img = findViewById<View>(R.id.img_close) as ImageView
      //  uploadimg_cardview = findViewById<View>(R.id.uploadimg_cardview) as CardView
        img_photoId = findViewById<View>(R.id.img_photoId) as ImageView
        img_removePic = findViewById<View>(R.id.img_removePic) as ImageView
        submit_layout=findViewById(R.id.submit_layout)

     //   uncheck_img_productservices=findViewById(R.id.uncheck_img_productservices)
        uncheck_img_document=findViewById(R.id.uncheck_img_document)
        uncheck_img_payment=findViewById(R.id.uncheck_img_payment)
        uncheck_img_upload=findViewById(R.id.uncheck_img_upload)

        //uploadimg_cardview!!.setOnClickListener(this)
        cancle_img!!.setOnClickListener(this)
        img_removePic!!.setOnClickListener(this)

        photoId_cardview=findViewById(R.id.photoId_cardview)
        photoId_cardview?.setOnClickListener(this)

        btn_submit=findViewById(R.id.btn_submit)
        btn_submit?.setOnClickListener(this)


        getStatus()
        document_type_spinner = findViewById(R.id.document_type_spinner) as Spinner

        val adapter = ArrayAdapter.createFromResource(this, R.array.document_array, /*R.layout.spinnertext*/ android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        document_type_spinner?.setAdapter(adapter)

    }



    fun getStatus(){


        val request = DocVerificationStatusRequest(Preferences.getPreference(this@AccountVerificationActivity, PrefEntity.USERID))
        apiUtility?.docVerification(this@AccountVerificationActivity, request, true,  object : APIUtility.APIResponseListener<DocVerificationStatusResponseWrapper>{
            override fun onReceiveResponse(response: DocVerificationStatusResponseWrapper?) {


                if (response?.response?.result?.doc_Verify.equals("1")){

                    uncheck_img_upload?.setImageResource(R.mipmap.small_check)

                    img_relative?.visibility=View.GONE
                    picker_cardview?.visibility=View.GONE
                    txt_header?.setText("Your document is uploaded successfully you will receive approval via email after verification")
                    btn_submit?.visibility=View.GONE
                    submit_layout?.visibility=View.GONE

                }

               else if (response?.response?.result?.doc_Verify.equals("2")){

                    uncheck_img_upload?.setImageResource(R.mipmap.small_check)
                    uncheck_img_document?.setImageResource(R.mipmap.small_check)

                    img_relative?.visibility=View.GONE
                    picker_cardview?.visibility=View.GONE
                    txt_header?.setText("Add a payment method")
                    btn_submit?.visibility=View.GONE
                    submit_layout?.visibility=View.GONE


                }
              else if (response?.response?.result?.doc_Verify.equals("3")){

                    uncheck_img_upload?.setImageResource(R.mipmap.small_check)
                    uncheck_img_document?.setImageResource(R.mipmap.small_check)
                    uncheck_img_payment?.setImageResource(R.mipmap.small_check)

                    img_relative?.visibility=View.GONE
                    picker_cardview?.visibility=View.GONE
                    txt_header?.setText("Add a payment method")
                    btn_submit?.visibility=View.GONE
                    submit_layout?.visibility=View.GONE



                }

                else{
                    img_relative?.visibility=View.VISIBLE
                    picker_cardview?.visibility=View.VISIBLE
                    btn_submit?.visibility=View.VISIBLE
                    submit_layout?.visibility=View.VISIBLE





                }




            }

            override fun onResponseFailed() {
                Log.e("error", "error")
            }

            override fun onStatusFalse(response: DocVerificationStatusResponseWrapper?) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }


        })


    }


    internal fun UploadDocument(user_id: String, documentType: String) {


        val url = "http://18.216.101.125:3000/mobile_api/upload_id"
        APIUtility(this).showDialog(this, true)
        val multipartRequest = object : VolleyMultipartRequest(Request.Method.POST, url, Response.Listener { response ->
            val responseString = String(response.data)
            Log.e("string",responseString)

            Log.e("ERROR", responseString + "ERROR")
            APIUtility(this@AccountVerificationActivity).dismissDialog(true)
            try {
                val jObj = JSONObject(responseString)
                val data = jObj.getJSONObject("data")
                val result = data.getJSONObject("result")
                val code = data.getString("code")
                val docVerify = result.getString("doc_verify")
                if (docVerify != null) {
                    Preferences.setPreference(applicationContext, PrefEntity.DOCVERIFY, docVerify)
                }
                val message = data.getString("message")
                Log.e("MutipartResponse", Gson().toJson(jObj)+" "+code)
                if (code == "1") {
                    Log.e("sucess",""+code)
                    APIUtility(this).showDialog(this,false)
                    Toast.makeText(applicationContext,"Uploaded succesfully",Toast.LENGTH_SHORT).show()


                    getStatus()



                }

            } catch (e: JSONException) {
                Log.e("exception",""+e.message)
                APIUtility(this@AccountVerificationActivity).dismissDialog(false)
                CommonUtils.alert(this@AccountVerificationActivity, e.message.toString())
            }
        }, Response.ErrorListener {
            Log.e("error"," error")

        }) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()

                params.put("user_id",user_id)
                params.put("document_type", documentType)

                Log.e("MultipartRequest", Gson().toJson(params))

                return params


            }

            override fun getByteData(): Map<String, VolleyMultipartRequest.DataPart>? {
                val params = HashMap<String, DataPart>()
                if (image != null) {
                    params["id_image"] = DataPart("User_profile.jpg", image, "image/jpeg")
                }
                return params
            }

        }

        multipartRequest.retryPolicy = DefaultRetryPolicy(
                40000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)
        VolleySingleton.getInstance(this@AccountVerificationActivity).addToRequestQueue(multipartRequest)


    }


    private fun validation() {
        Log.e("document", document_type_spinner?.getSelectedItem().toString())

        if (image == null) {
            CommonUtils.alert(this@AccountVerificationActivity, "Please upload Document")
        } else if (document_type_spinner?.getSelectedItem().toString() == "Select Document") {
            CommonUtils.alert(this@AccountVerificationActivity, "Please select document type.")
        } else {
            Log.e("else","else")

            Preferences.setPreference(applicationContext, PrefEntity.TYPE, document_type_spinner?.getSelectedItem().toString())

            UploadDocument(Preferences.getPreference(this@AccountVerificationActivity, PrefEntity.USERID),document_type_spinner?.getSelectedItem().toString());

        }


    }


    override fun onClick(v: View) {
        when (v.id) {

            R.id.img_close -> {
                finish()
            }
            R.id.btn_submit->{

                validation()
            }

          /*  R.id.uploadimg_cardview -> {

                showPictureDialog()

            }*/

            R.id.photoId_cardview->{
               // showPictureDialog()
                selectPicture()


            }
            R.id.img_removePic -> {


               // img_photoId!!.setImageDrawable(null)
                // img_photoId.setImageResource(0);


            }
        }

    }


    private fun getImageUri(context: Context, inImage: Bitmap): Uri {
        val bytes = ByteArrayOutputStream()
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path = MediaStore.Images.Media.insertImage(context.contentResolver, inImage, "Title", null)
        image = bytes.toByteArray()
        return Uri.parse(path)
    }

    private fun getRealPathFromURI(contentURI: Uri): String? {
        val cursor = this.contentResolver.query(contentURI, null, null, null, null)
        if (cursor == null) { // Source is Dropbox or other similar local file path
            return contentURI.path
        } else {
            cursor.moveToFirst()
            val idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
            return cursor.getString(idx)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("reqcode", " $requestCode $resultCode $data")


        if (resultCode == Activity.RESULT_CANCELED) {

            return
        }
        if (resultCode == Activity.RESULT_OK) {


            if (requestCode == GALLERY_IMAGE) {

                //val imageBitMap = data?.getExtras()!!.get("data") as Bitmap
                val imageBitMap = MediaStore.Images.Media.getBitmap(this@AccountVerificationActivity.getContentResolver(), data?.getData())

                val uri = getImageUri(this@AccountVerificationActivity, imageBitMap)
                Log.e("dfgh1",""+ uri)

                val path = getRealPathFromURI(uri)
                img_photoId?.setImageURI(uri)


            } else if (requestCode == CAMERA) {

                val imageBitMap = MediaStore.Images.Media.getBitmap(this@AccountVerificationActivity.getContentResolver(), data?.getData())
                val uri = getImageUri(this@AccountVerificationActivity, imageBitMap)
                val path = getRealPathFromURI(uri)
                Log.e("dfgh", path.toString())
                img_photoId?.setImageURI(uri)


            }
        }
    }


    private fun selectPicture() {
        val options = arrayOf<CharSequence>("Take Photo", "Choose from Gallery", "Cancel")

        val builder = AlertDialog.Builder(this@AccountVerificationActivity)
        builder.setTitle("Select Profile Photo From")
        builder.setItems(options) { dialog, item ->
            if (options[item] == "Take Photo") {
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@AccountVerificationActivity, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
                } else {
                    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    startActivityForResult(cameraIntent, CAMERA)
                }
            } else if (options[item] == "Choose from Gallery") {
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@AccountVerificationActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 2)
                } else {
                    val intent = Intent()
                    intent.type = "image/*"
                    intent.action = Intent.ACTION_GET_CONTENT
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), GALLERY_IMAGE)
                }
            }
        }
        builder.show()

    }

    private fun askforPermission(permission: String, requestCode: Int?) {


        if (ContextCompat.checkSelfPermission(this@AccountVerificationActivity, permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this@AccountVerificationActivity, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(this@AccountVerificationActivity, arrayOf(permission), requestCode!!)

            } else {

                ActivityCompat.requestPermissions(this@AccountVerificationActivity, arrayOf(permission), requestCode!!)
            }
        } else {
            Toast.makeText(this, "$permission is already granted.", Toast.LENGTH_SHORT).show()
        }


    }
}
