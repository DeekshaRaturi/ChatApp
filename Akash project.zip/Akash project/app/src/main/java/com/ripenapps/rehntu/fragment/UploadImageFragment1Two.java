package com.ripenapps.rehntu.fragment;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.ImageListAdapter1;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.my_util.UploadedImage;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class UploadImageFragment1Two extends Fragment implements View.OnClickListener, ImageListAdapter1.ImageListAdapterCallback, ImageListAdapter1.ImageListAdapterCallback1 {

    private View view;
    private RecyclerView recyclerView;
    private Button upload;
    private ImageListAdapter1 adapter;
    private List<Bitmap> list = new ArrayList<Bitmap>();
    private ArrayList<String> list1 = new ArrayList<>();
    private ArrayList<String> removeString = new ArrayList<>();
    public onSomeEventListener someEventListener;
    int a = 0;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        for (int i = 0; i < RhentoSingleton.getInstance().getUploadedImages().size(); i++) {
            list.add(RhentoSingleton.getInstance().getUploadedImages().get(i).getUploadedImageBitmap());
        }
        list1.addAll(RhentoSingleton.getInstance().getImageurl());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_upload_image_two, container, false);
        InitView();
        return view;
    }

    private void InitView() {
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler);
        upload = (Button) view.findViewById(R.id.btn_upload);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);
        setAdapter();
        upload.setOnClickListener(this);
    }

    void setAdapter() {
        Bitmap addIcon = BitmapFactory.decodeResource(getResources(), R.mipmap.add_plus);
        list.add(addIcon);
        adapter = new ImageListAdapter1(list, list1, UploadImageFragment1Two.this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_upload:
                if ((list.size() + list1.size()) > 1) {
                    someEventListener.onDo(RhentoSingleton.getInstance().getServiceImagesPath(), removeString);


                } else {
                    CommonUtils.alert(getActivity(), "Please upload minimum one Image");
                }
        }
    }


    @Override
    public void onItemClick(int pos) {
        showDialog();
    }

    private void showDialog() {

        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.image_selector);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        final CardView camera = dialog.findViewById(R.id.cv_camera);
        final CardView galary = dialog.findViewById(R.id.cv_gallery);

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakePictureIntent();
                dialog.cancel();
            }
        });

        galary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choosePhotoFromGallary();
                dialog.cancel();
            }
        });

        dialog.setCancelable(true);
        dialog.show();


    }

    private void dispatchTakePictureIntent() {
        if ((ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, 1);
        }
    }

    private void choosePhotoFromGallary() {
        if ((ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
        } else {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {


            if (requestCode == 1) {
                if (a != 1) {
                    RhentoSingleton.getInstance().getUploadedImages().clear();
                    RhentoSingleton.getInstance().getServiceImagesPath().clear();
                    a=1;
                }
                Bitmap imageBitMap = (Bitmap) data.getExtras().get("data");
                Uri uri = getImageUri(getActivity(), imageBitMap);
                String path = getRealPathFromURI(uri);
                RhentoSingleton.getInstance().getServiceImagesPath().add(path);
                RhentoSingleton.getInstance().getUploadedImages().add(new UploadedImage(imageBitMap));
                list.clear();
                for (int i = 0; i < RhentoSingleton.getInstance().getUploadedImages().size(); i++) {
                    list.add(RhentoSingleton.getInstance().getUploadedImages().get(i).getUploadedImageBitmap());
                }
                Log.i("Onresult", "onActivityResult: received result");
                if (adapter != null) {
                    setAdapter();
                }

            } else if (requestCode == 0) {

                if (a != 1) {
                    RhentoSingleton.getInstance().getUploadedImages().clear();
                    RhentoSingleton.getInstance().getServiceImagesPath().clear();
                    a=1;
                }
                Bitmap imageBitMap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), data.getData());
                Uri uri = getImageUri(getActivity(), imageBitMap);
                String path = getRealPathFromURI(uri);
                RhentoSingleton.getInstance().getServiceImagesPath().add(path);
                RhentoSingleton.getInstance().getUploadedImages().add(new UploadedImage(imageBitMap));
                list.clear();
                for (int i = 0; i < RhentoSingleton.getInstance().getUploadedImages().size(); i++) {
                    list.add(RhentoSingleton.getInstance().getUploadedImages().get(i).getUploadedImageBitmap());
                }
                if (adapter != null) {
                    setAdapter();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Uri getImageUri(Context context, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = getActivity().getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            return contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(idx);
        }
    }

    @Override
    public void onItemClick(int p1, String p) {
        if ((RhentoSingleton.getInstance().getUploadedImages().size() + RhentoSingleton.getInstance().getImageurl().size()) <= 0) {
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            android.support.v4.app.FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.container, new UploadImageFragment1One());
            transaction.commit();
        }

        if (!p.equals("-1")) {
            removeString.add(p);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            someEventListener = (onSomeEventListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement onSomeEventListener");
        }
    }

    public interface onSomeEventListener {
        void onDo(ArrayList<String> a, ArrayList<String> a1);
    }
}
