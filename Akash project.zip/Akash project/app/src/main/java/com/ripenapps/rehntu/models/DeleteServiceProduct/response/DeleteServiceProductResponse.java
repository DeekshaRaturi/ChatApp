package com.ripenapps.rehntu.models.DeleteServiceProduct.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class DeleteServiceProductResponse extends BaseResponse{


    @SerializedName("result")
    private DeleteServiceProductResult result;


    public DeleteServiceProductResult getResult() {
        return result;
    }

    public void setResult(DeleteServiceProductResult result) {
        this.result = result;
    }
}
