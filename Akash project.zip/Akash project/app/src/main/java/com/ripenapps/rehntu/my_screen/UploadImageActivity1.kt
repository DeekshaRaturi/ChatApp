package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.view.View
import android.widget.ImageView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.fragment.UploadImageFragment1Two
import com.ripenapps.rehntu.my_util.RhentoSingleton

import java.util.ArrayList

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class UploadImageActivity1 : BaseActivity(), View.OnClickListener, UploadImageFragment1Two.onSomeEventListener {


    private var title: AppCompatTextView? = null
    private var back: ImageView? = null
    private var imageList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_uplaod_image)
        initViews()

    }

    private fun initViews() {
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title!!.text = "Upload Image"
        back!!.setOnClickListener(this)
        if (intent.hasExtra("afterEdit")) {
            imageList = intent.getStringArrayListExtra("imageLIst")
        }

        RhentoSingleton.getInstance().imageurl = imageList
        val bundle = Bundle()
        bundle.putString("EditPicture", "edit")
        val fragment = UploadImageFragment1Two()
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        fragment.arguments = bundle
        fragmentTransaction.replace(R.id.container, fragment)
        fragmentTransaction.commit()


    }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onClick(v: View) {
        finish()
    }

    override fun onDo(a: ArrayList<String>, a1: ArrayList<String>) {
        val intent = Intent()
        intent.putStringArrayListExtra("path", a)
        intent.putStringArrayListExtra("remove", a1)
        setResult(Activity.RESULT_OK, intent)
        //        Toast.makeText(UploadImageActivity1.this,String.valueOf(a.size())+String.valueOf(a1.size()),Toast.LENGTH_LONG).show();
        finish()
    }


}
