package com.ripenapps.rehntu.models.bookNow.response;

public class BookNow {
}
