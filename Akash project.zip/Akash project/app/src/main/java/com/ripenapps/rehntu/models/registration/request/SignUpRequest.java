package com.ripenapps.rehntu.models.registration.request;

import com.google.gson.annotations.SerializedName;

public class SignUpRequest {

    @SerializedName("name")
    String name;
    @SerializedName("email")
    String email;
    @SerializedName("mobile_no")
    String phone;

    @SerializedName("country_code")
    String country_code;

    @SerializedName("password")
    String password;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
