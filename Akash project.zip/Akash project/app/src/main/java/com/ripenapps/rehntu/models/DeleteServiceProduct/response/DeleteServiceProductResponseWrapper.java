package com.ripenapps.rehntu.models.DeleteServiceProduct.response;

import com.google.gson.annotations.SerializedName;

public class DeleteServiceProductResponseWrapper {

    @SerializedName("data")
    private DeleteServiceProductResponse response;

    public DeleteServiceProductResponse getResponse() {
        return response;
    }

    public void setResponse(DeleteServiceProductResponse response) {
        this.response = response;
    }
}
