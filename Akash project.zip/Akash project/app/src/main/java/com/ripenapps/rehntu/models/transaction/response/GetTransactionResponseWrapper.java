package com.ripenapps.rehntu.models.transaction.response;

import com.google.gson.annotations.SerializedName;

public class GetTransactionResponseWrapper {

    @SerializedName("data")
    private GetTransactionResponse response;


    public GetTransactionResponse getResponse() {
        return response;
    }

    public void setResponse(GetTransactionResponse response) {
        this.response = response;
    }



}
