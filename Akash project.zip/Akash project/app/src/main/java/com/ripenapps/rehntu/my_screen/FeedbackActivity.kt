package com.ripenapps.rehntu.my_screen

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView

import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.FeedbackAdapter
import com.ripenapps.rehntu.models.getFeedback.request.GetFeedbackRequest
import com.ripenapps.rehntu.models.getFeedback.response.Feedback
import com.ripenapps.rehntu.models.getFeedback.response.GetFeedbackResponseWrapper
import com.ripenapps.rehntu.models.giveFeedback.request.GiveFeedbackRequest
import com.ripenapps.rehntu.models.giveFeedback.response.GiveFeedbackResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import java.util.ArrayList

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class FeedbackActivity : BaseActivity(), View.OnClickListener {
    private var title: AppCompatTextView? = null
    private var back: ImageView? = null
    private var recyclerView: RecyclerView? = null
    private var adapter: FeedbackAdapter?=null
    internal var list: List<String> = ArrayList()
    internal var rateReview: LinearLayout?=null
    internal var apiUtility: APIUtility?=null
    internal var feedbackList: MutableList<Feedback> = ArrayList()
    internal var noReview: TextView?=null
    internal var productType: String?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feedback)
        apiUtility = APIUtility(this)
        init()
        productType = intent.getStringExtra("productType")
        getFeedback()
    }

    private fun getFeedback() {

        val request = GetFeedbackRequest()
        request.setUserId(Preferences.getPreference(applicationContext, PrefEntity.USERID))
        request.setServiceId(intent.getStringExtra("id"))

        val gson = Gson()
        Log.e("feedgetreq", "" + gson.toJson(request))


        apiUtility?.getFeedback(this@FeedbackActivity, request, true, object : APIUtility.APIResponseListener<GetFeedbackResponseWrapper> {
            override fun onReceiveResponse(response: GetFeedbackResponseWrapper?) {
                if (response != null) {
                    feedbackList.clear()
                    if (response.response.result.getFeedbackList().size > 0) {
                        noReview?.visibility = View.GONE
                        feedbackList.addAll(response.response.result.getFeedbackList())
                        adapter?.notifyDataSetChanged()
                    } else {
                        noReview?.visibility = View.VISIBLE
                        adapter?.notifyDataSetChanged()
                    }
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@FeedbackActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: GetFeedbackResponseWrapper) {
                CommonUtils.alert(this@FeedbackActivity, response.response.message)

            }


        })
    }

    private fun init() {
        noReview = findViewById<View>(R.id.noReview) as TextView
        rateReview = findViewById<View>(R.id.rate) as LinearLayout
        recyclerView = findViewById<View>(R.id.recycler) as RecyclerView
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title!!.text = "Reviews"
        val gridLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager
        adapter = FeedbackAdapter(feedbackList, this@FeedbackActivity)
        recyclerView!!.adapter = adapter
        back!!.setOnClickListener(this)
        rateReview?.setOnClickListener(this)
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.back -> finish()

            R.id.rate -> showDailog()
        }

    }


    private fun showDailog() {

        val dialog = Dialog(this@FeedbackActivity)
        dialog.setContentView(R.layout.rate_service)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val dialogButton = dialog.findViewById<Button>(R.id.submit)
        val editText = dialog.findViewById<EditText>(R.id.feedback)
        val cancle = dialog.findViewById<ImageView>(R.id.iv_cancel)
        val ratingBar = dialog.findViewById<RatingBar>(R.id.rating)
        val userName = dialog.findViewById<TextView>(R.id.user_name)

        userName.text = intent.getStringExtra("name")

        cancle.setOnClickListener { dialog.dismiss() }

        dialogButton.setOnClickListener {
            if (!editText.text.toString().trim { it <= ' ' }.isEmpty()) {
                giveFeedBack(ratingBar.rating.toString(), editText.text.toString().trim { it <= ' ' }, productType!!)
                dialog.dismiss()
            } else {
                CommonUtils.alert(this@FeedbackActivity, "Please enter the review")
            }
        }
        dialog.setCancelable(false)
        dialog.show()
    }

    private fun giveFeedBack(rating: String, review: String, productType: String) {
        val feedbackRequest = GiveFeedbackRequest()
        feedbackRequest.rating = rating
        feedbackRequest.review = review
        feedbackRequest.serviceId = intent.getStringExtra("id")
        feedbackRequest.servicesType = productType
        feedbackRequest.userId = Preferences.getPreference(applicationContext, PrefEntity.USERID)

        val gson = Gson()
        Log.e("feedgivereq", "" + gson.toJson(feedbackRequest))

        apiUtility?.giveFeedback(this, feedbackRequest, true, object : APIUtility.APIResponseListener<GiveFeedbackResponseWrapper> {
            override fun onReceiveResponse(response: GiveFeedbackResponseWrapper?) {
                if (response != null) {

                    getFeedback()
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@FeedbackActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: GiveFeedbackResponseWrapper) {
                CommonUtils.alert(this@FeedbackActivity, response.response.message)
            }
        })
    }


}
