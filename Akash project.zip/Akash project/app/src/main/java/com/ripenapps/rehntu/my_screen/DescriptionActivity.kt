package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class DescriptionActivity : BaseActivity(), View.OnClickListener {
    var description: EditText?=null
    private var done: TextView? = null
    private var back: ImageView? = null
    private var title: AppCompatTextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
        initViews()
    }

    private fun initViews() {
        description = findViewById<View>(R.id.tv_description) as EditText
        if (intent.hasExtra("123")) {
            description?.setText(intent.getStringExtra("123"))
        }
        if (intent.hasExtra("1234")) {
            if (intent.getStringExtra("1234") == "Enter Description") {
                description?.setText("")
            } else {
                description?.setText(intent.getStringExtra("1234"))
            }
        }
        done = findViewById<View>(R.id.done) as TextView
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView

        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Service") {
            title!!.text = "Service Description"
            description?.hint = "Enter  Description"
        } else {
            description?.hint = "Enter product Model, Quality & Conditions etc."
            title!!.text = "Product Description"
        }





        back!!.setOnClickListener(this)
        done!!.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.back -> finish()

            R.id.done -> if (description?.text.toString().trim { it <= ' ' } != "") {
                val description1 = description?.text.toString()
                val returnIntent = Intent()
                returnIntent.putExtra("descriptionResult", description1)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            } else {
                CommonUtils.alert(this, "Please enter the description")
            }
        }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }
}
