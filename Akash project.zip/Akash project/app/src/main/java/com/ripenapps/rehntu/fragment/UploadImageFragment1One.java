package com.ripenapps.rehntu.fragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.my_util.UploadedImage;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;

import java.io.ByteArrayOutputStream;

public class UploadImageFragment1One extends Fragment implements View.OnClickListener {

    private View view;
    private Button upload;
    private TextView upladtxt;
    private CardView camera, gallery;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_upload_image_one, container, false);
        InitView();
        return view;
    }

    private void InitView() {
        upladtxt = (TextView) view.findViewById(R.id.upload_imagetxt);
        camera = (CardView) view.findViewById(R.id.cv_camera);
        gallery = (CardView) view.findViewById(R.id.cv_gallery);
        upload = (Button) view.findViewById(R.id.btn_upload);
        upload.setOnClickListener(this);
        gallery.setOnClickListener(this);
        camera.setOnClickListener(this);


        if (Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM).equals("Service")) {
            upladtxt.setText("Upload your Service image");
        } else {
            upladtxt.setText("Upload your Product image");

        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cv_camera:
                if ((ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                } else {
                    Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent, 1);
                }
                break;
            case R.id.cv_gallery:
                if ((ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
                } else {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);
                }
                break;
            case R.id.btn_upload:
                CommonUtils.alert(getActivity(), "Please upload minimum one Image");
                break;

        }


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {

            if (requestCode == 1) {
                RhentoSingleton.getInstance().getUploadedImages().clear();
                RhentoSingleton.getInstance().getServiceImagesPath().clear();
                Bitmap imageBitMap = (Bitmap) data.getExtras().get("data");
                Uri uri = getImageUri(getActivity(), imageBitMap);
                String path = getRealPathFromURI(uri);
                RhentoSingleton.getInstance().getServiceImagesPath().add(path);
                RhentoSingleton.getInstance().getUploadedImages().add(new UploadedImage(imageBitMap));
                replaceFragment(new UploadImageFragmentTwo());
            } else if (requestCode == 0) {
                RhentoSingleton.getInstance().getUploadedImages().clear();
                RhentoSingleton.getInstance().getServiceImagesPath().clear();
                try {
                    Bitmap imageBitMap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), data.getData());
                    Uri uri = getImageUri(getActivity(), imageBitMap);
                    String path = getRealPathFromURI(uri);
                    RhentoSingleton.getInstance().getServiceImagesPath().add(path);
                    RhentoSingleton.getInstance().getUploadedImages().add(new UploadedImage(imageBitMap));
                    replaceFragment(new UploadImageFragmentTwo());
                } catch (Exception e) {

                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Uri getImageUri(Context context, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = getActivity().getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            return contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(idx);
        }
    }


    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.commit();
    }
}
