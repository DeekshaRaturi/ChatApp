package com.ripenapps.rehntu.my_screen

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

import com.google.android.gms.location.places.ui.PlaceAutocomplete
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.ripenapps.rehntu.BuildConfig
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.geo.GeoCoder
import com.ripenapps.rehntu.models.notification.request.NotificationRequest
import com.ripenapps.rehntu.models.notification.response.NotificationWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.GPSTracker
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import com.ripenapps.rehntu.volleyMultipart.RetrofitClient
import com.ripenapps.rehntu.volleyMultipart.RetrofitInterface

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper
import java.util.*
import kotlin.math.ln

class GetCurrentLocationActivity : BaseActivity(), View.OnClickListener {


    private var allow_autoselectlocation: TextView? = null
    private var select_manually_text: LinearLayout? = null
    private var lat: Double = 0.toDouble()
    private var lng: Double = 0.toDouble()
    internal var gpsTracker: GPSTracker?=null
    var apiUtility:APIUtility?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_current_location)
        initViews()

    }

    private fun initViews() {
        select_manually_text = findViewById<View>(R.id.select_manually_text) as LinearLayout
        allow_autoselectlocation = findViewById<View>(R.id.allow_autoselect_location) as TextView
        select_manually_text!!.setOnClickListener(this)
        allow_autoselectlocation!!.setOnClickListener(this)
        apiUtility= APIUtility(this@GetCurrentLocationActivity)
        getNotification()

    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    private fun getNotification() {

        val request = NotificationRequest()
        request.device_token = Preferences.getPreference(applicationContext, "token")
        request.user_id = Preferences.getPreference(applicationContext, PrefEntity.USERID)
        request.device_type = "Android"



        apiUtility?.showNotification(this, request, true, object : APIUtility.APIResponseListener<NotificationWrapper> {
            override fun onReceiveResponse(response: NotificationWrapper?) {
                if (response != null) {

                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@GetCurrentLocationActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: NotificationWrapper) {
                CommonUtils.alert(this@GetCurrentLocationActivity, response.response.message)
            }
        })


    }


    override fun onClick(v: View) {
        when (v.id) {
            R.id.allow_autoselect_location -> {

                checkMyPermission()

                gpsTracker = GPSTracker(this@GetCurrentLocationActivity)
                lat = gpsTracker!!.latitude
                lng = gpsTracker!!.longitude

                if (lat == 0.0 && lng == 0.0) {
                    gpsTracker!!.location
                    lat = gpsTracker!!.latitude
                    lng = gpsTracker!!.longitude


                    Log.e("gps11",""+lat+" "+ lng)

                    Preferences.setPreference(applicationContext, PrefEntity.LAT, lat.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, lng.toString())

                } else {
                    Preferences.setPreference(applicationContext, PrefEntity.LAT, lat.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, lng.toString())
                    getAddressFromGeoApi(this@GetCurrentLocationActivity, lat, lng)
                    Log.e("gps1",""+lat+" "+ lng)


                    val intent = Intent(baseContext, DashBoardActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)
                }
            }
            //                Toast.makeText(this, String.valueOf(gpsTracker.getLocation()), Toast.LENGTH_LONG).show();

            R.id.select_manually_text -> {
                val intent = Intent(baseContext, SelectLocationManually::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)

            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val place = PlaceAutocomplete.getPlace(this, data!!)
                /* Log.i("TESTING", "Place: " + place.getName());*/
                Toast.makeText(this, "" + place.address, Toast.LENGTH_LONG).show()
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                val status = PlaceAutocomplete.getStatus(this, data!!)
                /* // TODO: Handle the error.
                Log.i("TESTING", status.getStatusMessage());*/

            } else if (resultCode == Activity.RESULT_CANCELED) {
            }
        }
    }

    private fun checkMyPermission() {
        if (ContextCompat.checkSelfPermission(this@GetCurrentLocationActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this@GetCurrentLocationActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            1 -> if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
            } else {

                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + BuildConfig.APPLICATION_ID))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                this.startActivity(intent)


            }
        }
    }


    private fun getAddressFromGeoApi(context: Context, latitude: Double, longitude: Double) {
        val BASE_URL_GEO = "https://maps.googleapis.com/maps/api/geocode/"
        val retrofit = Retrofit.Builder().baseUrl(BASE_URL_GEO).addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create())).client(RetrofitClient.getOkHttpClient()).build()
        val retrofitInterface = retrofit.create(RetrofitInterface::class.java)
        retrofitInterface.getLocaationwithCoordinates(latitude.toString() + "," + longitude, context.resources.getString(R.string.geo_coder_Api_key)).enqueue(object : Callback<GeoCoder> {
            override fun onResponse(call: Call<GeoCoder>, response: Response<GeoCoder>) {
                var address = ""
                try {
                   // address = response.body()!!.getResults()[3].getAddressComponents()[0].getLongName()
                    var geocoder = Geocoder(context, Locale.getDefault());
                    Log.e("geocoder"," "+geocoder)


                    var addressList = geocoder.getFromLocation(latitude, longitude, 1);

                    var  addresses = addressList.get(0)
                    address=addresses.getAddressLine(0)

                } catch (e: Exception) {
                    e.printStackTrace()
                   // address = response.body()!!.getResults()[1].getAddressComponents()[2].getLongName()
                }

                Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                //                Toast.makeText(GetCurrentLocationActivity.this, address, Toast.LENGTH_SHORT).show();
            }

            override fun onFailure(call: Call<GeoCoder>, throwable: Throwable) {}
        })
    }

    companion object {
        private val PLACE_AUTOCOMPLETE_REQUEST_CODE = 1
    }
}
