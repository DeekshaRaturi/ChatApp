package com.ripenapps.rehntu.models.walletamount.response;

public class WalletModel {

    private String name;
    private String date;
    private Boolean status;
    private String totalAmount;

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    private String service_name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }




    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }


    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }


    public WalletModel(String name,String service_name,String totalAmount,Boolean status,String date){

        this.name=name;
        this.totalAmount=totalAmount;
        this.status=status;
        this.date=date;
        this.service_name=service_name;
    }
}
