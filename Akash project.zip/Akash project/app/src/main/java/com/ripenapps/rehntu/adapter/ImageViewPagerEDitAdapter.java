package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.my_util.Constants;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class ImageViewPagerEDitAdapter extends PagerAdapter {
    private Context mContext;
    LayoutInflater inflater;
    private ArrayList<String> listimages = new ArrayList<>();


    public ImageViewPagerEDitAdapter(ArrayList<String> list, Context context) {
        listimages = list;
        mContext = context;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.add_image, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.iv_img_viewpager);
        String s = Constants.IMG_URL + listimages.get(position);
        Picasso.with(mContext.getApplicationContext()).load(Constants.IMG_URL + listimages.get(position)).placeholder(R.drawable.place_holder).into(imageView);


        ViewPager vp = (ViewPager) container;
        vp.addView(view, 0);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ViewPager vp = (ViewPager) container;
        View view = (View) object;
        vp.removeView(view);
    }

    @Override
    public int getCount() {

        return listimages.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }
}
