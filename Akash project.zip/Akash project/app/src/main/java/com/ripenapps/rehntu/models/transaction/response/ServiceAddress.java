package com.ripenapps.rehntu.models.transaction.response;

import com.google.gson.annotations.SerializedName;

public class ServiceAddress {

    @SerializedName("fullAddress")
    private String fullAddress = "";

    @SerializedName("city")
    private String city = "";

    @SerializedName("pincode")
    private String pincode = "";


    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

}
