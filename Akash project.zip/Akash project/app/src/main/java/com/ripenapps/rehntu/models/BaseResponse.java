package com.ripenapps.rehntu.models;

import com.google.gson.annotations.SerializedName;

public class BaseResponse {

    @SerializedName("code")
    int status;

    @SerializedName("statusCode")
    int statusCode;

    @SerializedName("message")
    String message;

    public boolean isSuccess() {
        if (status == 1) {
            return true;
        } else {
            return false;
        }
    }
    public boolean isSucessCode() {
        if (statusCode == 2) {
            return true;
        } else {
            return false;
        }
    }


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
