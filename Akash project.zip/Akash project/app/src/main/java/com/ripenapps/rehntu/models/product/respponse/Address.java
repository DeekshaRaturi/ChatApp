package com.ripenapps.rehntu.models.product.respponse;



import com.google.gson.annotations.SerializedName;

public class Address {

    @SerializedName("location")
    Locations locations;

    @SerializedName("fullAddress")
   String fullAddress;

    @SerializedName("city")
    String city;

    @SerializedName("pincode")
    String pincode;


    public Locations getLocations() {
        return locations;
    }

    public void setLocations(Locations locations) {
        this.locations = locations;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
