package com.ripenapps.rehntu.models.serviceDetail.response;

import com.google.gson.annotations.SerializedName;

public class ServiceDetailResponseWrapper {

    @SerializedName("data")
    private ServiceDetailResponse response;

    public ServiceDetailResponse getResponse() {
        return response;
    }

    public void setResponse(ServiceDetailResponse response) {
        this.response = response;
    }
}
