package com.ripenapps.rehntu.models.giveFeedback.request;

import com.google.gson.annotations.SerializedName;

public class GiveFeedbackRequest {

    @SerializedName("services_type")

    private String servicesType;

    @SerializedName("user_id")
    private String userId;

    @SerializedName("service_id")
    private String serviceId ;


    @SerializedName("rating")
    private String rating ;


    @SerializedName("review")
    private String review ;


    public String getServicesType() {
        return servicesType;
    }

    public void setServicesType(String servicesType) {
        this.servicesType = servicesType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
