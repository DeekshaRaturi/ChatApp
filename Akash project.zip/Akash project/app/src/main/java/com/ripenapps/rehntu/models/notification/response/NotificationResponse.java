package com.ripenapps.rehntu.models.notification.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;
import com.ripenapps.rehntu.models.transaction.response.GetTransactionResult;

public class NotificationResponse extends BaseResponse {

    public NotificationResult getGetNotificationResult() {
        return getNotificationResult;
    }

    public void setGetNotificationResult(NotificationResult getNotificationResult) {
        this.getNotificationResult = getNotificationResult;
    }

    @SerializedName("result")
    private NotificationResult getNotificationResult;

}
