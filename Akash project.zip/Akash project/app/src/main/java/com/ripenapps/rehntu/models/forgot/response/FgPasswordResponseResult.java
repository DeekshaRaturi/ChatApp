package com.ripenapps.rehntu.models.forgot.response;

public class FgPasswordResponseResult {



}
