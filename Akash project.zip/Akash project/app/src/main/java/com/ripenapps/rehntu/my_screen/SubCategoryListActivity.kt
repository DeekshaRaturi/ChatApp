package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.SubCategoryListAdapter
import com.ripenapps.rehntu.models.subcategory.request.SubCategoryRequest
import com.ripenapps.rehntu.models.subcategory.response.SubCategory
import com.ripenapps.rehntu.models.subcategory.response.SubCategoryResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import java.util.ArrayList

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class SubCategoryListActivity : BaseActivity(), SubCategoryListAdapter.SubCategoryListAdapterCallback, View.OnClickListener {
    private var categoryID: String? = null
    private var back: ImageView? = null
    internal var title: AppCompatTextView?=null
    private var done: TextView? = null
    private var noSubcategory: TextView? = null
    private var editText: EditText? = null
    private var subcategoryView: RecyclerView? = null
    private var adapter: SubCategoryListAdapter? = null
    internal var name = ArrayList<String>()
    internal var subCategoryIdlist = ArrayList<String>()
    internal var subCategoryList: MutableList<SubCategory> = ArrayList()
    internal var category: TextView?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub_category_list)
        initViews()
        if (intent != null || intent.hasExtra("cat_id")) {
            categoryID = intent.getStringExtra("cat_id")
        }
        if (intent.hasExtra("requestFrom")) {
            getSubCategoryList1(Preferences.getPreference(applicationContext, PrefEntity.CATEGORYID), "", intent.getStringExtra("serviceType"))

        } else {
            getSubCategoryList(Preferences.getPreference(applicationContext, PrefEntity.CATEGORYID), "")

        }

    }

    private fun initViews() {
        noSubcategory = findViewById<View>(R.id.subcategoryNo) as TextView
        category = findViewById<View>(R.id.categoryTxt) as TextView
        done = findViewById<View>(R.id.done) as TextView
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title?.text = Preferences.getPreference(applicationContext, PrefEntity.CATEGORY)
        back!!.setOnClickListener(this)
        done!!.setOnClickListener(this)
        editText = findViewById<View>(R.id.search) as EditText
        subcategoryView = findViewById<View>(R.id.rv_category) as RecyclerView
        val gridLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        subcategoryView!!.layoutManager = gridLayoutManager
        adapter = SubCategoryListAdapter(subCategoryList, this@SubCategoryListActivity)
        subcategoryView!!.adapter = adapter
        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            category?.text = "Ex:Furniture,Electronics etc"
        } else {
            category?.text = "Ex:Home cleaner,Saloon,Tuition etc"
        }


        editText!!.setOnEditorActionListener { v, actionId, event ->
            var handled = false
            if (actionId == EditorInfo.IME_ACTION_SEND) {

                if (intent.hasExtra("requestFrom")) {
                    getSubCategoryList1(Preferences.getPreference(applicationContext, PrefEntity.CATEGORYID), editText!!.text.toString().toLowerCase().trim { it <= ' ' }, intent.getStringExtra("serviceType"))

                } else {
                    getSubCategoryList(Preferences.getPreference(applicationContext, PrefEntity.CATEGORYID), editText!!.text.toString().toLowerCase().trim { it <= ' ' })

                }

                handled = true
            }
            handled
        }

    }


    internal fun getSubCategoryList(categoryID: String, text: String?) {
        val request = SubCategoryRequest()
        request.category_id = categoryID
        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            request.serviceType = "product"
        } else {
            request.serviceType = "service"
        }
        request.userID = Preferences.getPreference(applicationContext, PrefEntity.USERID)
        if (text != null) {
            request.text = text
        } else {
            request.text = ""
        }

        APIUtility(this).subCategoryList(this, request, true, object : APIUtility.APIResponseListener<SubCategoryResponseWrapper> {
            override fun onReceiveResponse(response: SubCategoryResponseWrapper?) {
                if (response != null) {
                    if (response.response.result.subCategoryList.size > 0) {
                        subCategoryList.clear()
                        noSubcategory!!.visibility = View.GONE
                        subCategoryList.addAll(response.response.result.subCategoryList)
                        adapter!!.notifyDataSetChanged()
                    } else {
                        noSubcategory!!.visibility = View.VISIBLE
                        subCategoryList.clear()
                        subCategoryList.addAll(response.response.result.subCategoryList)
                        adapter!!.notifyDataSetChanged()
                    }
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@SubCategoryListActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: SubCategoryResponseWrapper) {
                CommonUtils.alert(this@SubCategoryListActivity, response.response.message)

            }
        })
    }

    internal fun getSubCategoryList1(categoryID: String, text: String?, serviceType: String) {
        val request = SubCategoryRequest()
        request.category_id = categoryID

        request.serviceType = serviceType

        request.userID = Preferences.getPreference(applicationContext, PrefEntity.USERID)
        if (text != null) {
            request.text = text
        } else {
            request.text = ""
        }

        APIUtility(this).subCategoryList(this, request, true, object : APIUtility.APIResponseListener<SubCategoryResponseWrapper> {
            override fun onReceiveResponse(response: SubCategoryResponseWrapper?) {
                if (response != null) {
                    if (response.response.result.subCategoryList.size > 0) {
                        subCategoryList.clear()
                        noSubcategory!!.visibility = View.GONE
                        subCategoryList.addAll(response.response.result.subCategoryList)
                        adapter!!.notifyDataSetChanged()
                    } else {
                        noSubcategory!!.visibility = View.VISIBLE
                        subCategoryList.clear()
                        subCategoryList.addAll(response.response.result.subCategoryList)
                        adapter!!.notifyDataSetChanged()
                    }
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@SubCategoryListActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: SubCategoryResponseWrapper) {
                CommonUtils.alert(this@SubCategoryListActivity, response.response.message)

            }
        })
    }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }


    override fun onClick(v: View) {
        when (v.id) {
            R.id.back -> finish()

            R.id.done -> if (name.size > 0) {
                if (intent.hasExtra("subcategory")) {

                    val intent = Intent()
                    intent.putStringArrayListExtra("name", name)
                    intent.putStringArrayListExtra("id", subCategoryIdlist)
                    setResult(Activity.RESULT_OK, intent)
                    finish()


                } else if (intent.hasExtra("requestFrom")) {

                    val intent = Intent()
                    intent.putStringArrayListExtra("name", name)
                    intent.putStringArrayListExtra("id", subCategoryIdlist)
                    setResult(Activity.RESULT_OK, intent)
                    finish()


                } else {
                    val intent = Intent(this@SubCategoryListActivity, AddServicesAndProductActivity::class.java)
                    intent.putStringArrayListExtra("name", name)
                    intent.putStringArrayListExtra("id", subCategoryIdlist)
                    startActivity(intent)
                }
            } else {
                CommonUtils.alert(this, "Select Atleast one Subcategory")
            }
        }

    }

    override fun addItem(list: ArrayList<String>, subCategoryId: ArrayList<String>) {
        name = list
        subCategoryIdlist = subCategoryId
    }
}
