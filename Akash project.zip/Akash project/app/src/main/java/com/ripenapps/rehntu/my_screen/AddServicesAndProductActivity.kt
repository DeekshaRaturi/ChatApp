package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RelativeLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.adapter.ImageViewPagerAdapter
import com.ripenapps.rehntu.models.serviceDetail.response.ServiceDetailResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.RhentoSingleton
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import com.ripenapps.rehntu.volleyMultipart.RetrofitClientInstance
import com.ripenapps.rehntu.volleyMultipart.RetrofitInterface

import java.io.File
import java.util.ArrayList

import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class AddServicesAndProductActivity : BaseActivity(), View.OnClickListener {
    private var viewPager: ViewPager? = null
    internal var subcategoryList = ArrayList<String>()
    internal var subcategoryIdList = ArrayList<String>()
    private var tvCategory: TextView? = null
    private var tvSubCategory: TextView? = null
    private var tvDescription: TextView? = null
    private var tvAddress: TextView? = null
    private var removeService: TextView? = null
    private var productnameText: TextView? = null
    private var productDescriptionText: TextView? = null
    private var etProductName: EditText? = null
    private var etBasePrice: EditText? = null
    private var etrateperYear: EditText? = null
    private val etYearofPur: EditText? = null
    private var etSecurityDeposite: EditText? = null
    private val ivBack: ImageView? = null
    private var categoryName: String? = null
    private var strSubCategory = ""
    private var btnSubmit: Button? = null
    private var descriptionResult: String? = null
    private var ivFoerword: ImageView? = null
    private var baseprice: RelativeLayout? = null
    private var rateperHour: RelativeLayout? = null
    private var yaerofPurchase: RelativeLayout? = null
    private var securityDeposite: RelativeLayout? = null
    private var homeServiceAvailable: RelativeLayout? = null
    private var rlAddress: RelativeLayout? = null
    private var rlCategory: RelativeLayout? = null
    private var rlSubCategory: RelativeLayout? = null
    private var llDescription: LinearLayout? = null
    private var title: AppCompatTextView? = null
    private var back: ImageView? = null
    private var document_type_spinner: Spinner?=null
    private var home: RadioGroup? = null
    private var rate: RadioGroup? = null
    private var perDay: RadioButton? = null
    private var perHour: RadioButton? = null
    private var yes: RadioButton? = null
    private var no: RadioButton? = null
    internal var perHourString = "0"
    internal var noString = "0"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_services_and_product)
        init()
        categoryName = Preferences.getPreference(this, PrefEntity.CATEGORY)

        if (intent != null && intent.hasExtra("name")) {
            subcategoryList = intent.getStringArrayListExtra("name")
        }

        if (intent != null && intent.hasExtra("id")) {
            subcategoryIdList = intent.getStringArrayListExtra("id")
        }

        setText()
        viewPager!!.adapter = ImageViewPagerAdapter(this)
        val tabLayout = findViewById<View>(R.id.tab_layout) as TabLayout
        tabLayout.setupWithViewPager(viewPager, true)
    }

    private fun setText() {
        if (categoryName != null)
            tvCategory!!.text = categoryName
        setSubCategoryList()
    }

    private fun setSubCategoryList() {
        for (i in subcategoryList.indices) {
            if (i == 0) {
                strSubCategory = subcategoryList[i]
            } else {
                strSubCategory = strSubCategory + "," + subcategoryList[i]
            }
        }
        tvSubCategory!!.text = "" + strSubCategory
    }


    private fun init() {
        yes = findViewById<View>(R.id.yes) as RadioButton
        no = findViewById<View>(R.id.no) as RadioButton
        perDay = findViewById<View>(R.id.ratePerdaybutton) as RadioButton
        perHour = findViewById<View>(R.id.ratePerhourbutton) as RadioButton
        home = findViewById<View>(R.id.radioGroup1) as RadioGroup
        rate = findViewById<View>(R.id.radioGroup) as RadioGroup

        home!!.setOnCheckedChangeListener { group, checkedId ->
            if (checkedId == R.id.yes) {
                noString = "1"
            } else {
                noString = "0"
            }
        }

        rate!!.setOnCheckedChangeListener { group, checkedId ->
            if (checkedId == R.id.ratePerhourbutton) {
                perHourString = "0"
            } else {
                perHourString = "1"

            }
        }


        productDescriptionText = findViewById<View>(R.id.product_description) as TextView
        productnameText = findViewById<View>(R.id.product_name) as TextView
        removeService = findViewById<View>(R.id.removeService) as TextView
        removeService!!.visibility = View.GONE
        title = findViewById<View>(R.id.title) as AppCompatTextView
        viewPager = findViewById(R.id.photos_viewpager)
        etrateperYear = findViewById(R.id.ratePerhour)
        etSecurityDeposite = findViewById(R.id.securityDeposit)
        document_type_spinner = findViewById<View>(R.id.document_type_spinner) as Spinner
        val adapter = ArrayAdapter.createFromResource(this, R.array.document_array1, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        document_type_spinner?.adapter = adapter

        baseprice = findViewById(R.id.baseprice_rl)
        rateperHour = findViewById(R.id.ratePerhour_rl)
        homeServiceAvailable = findViewById(R.id.homeAvailable_rl)
        securityDeposite = findViewById(R.id.securityDeposit_rl)
        yaerofPurchase = findViewById(R.id.yearofPurchase_rl)
        tvAddress = findViewById(R.id.tv_address)
        etBasePrice = findViewById(R.id.et_base_price)
        rlAddress = findViewById(R.id.rl_address)
        tvDescription = findViewById(R.id.tv_description)
        etProductName = findViewById(R.id.et_product_name)
        rlCategory = findViewById(R.id.rl_category)
        rlSubCategory = findViewById(R.id.rl_subcategory)
        tvCategory = findViewById(R.id.tv_category)
        tvSubCategory = findViewById(R.id.tv_subcategory)
        btnSubmit = findViewById(R.id.btn_submit)
        back = findViewById<View>(R.id.back) as ImageView
        back!!.setOnClickListener(this)
        btnSubmit!!.setOnClickListener(this)
        ivFoerword = findViewById(R.id.iv_forword)
        ivFoerword!!.setOnClickListener(this)
        llDescription = findViewById(R.id.ll_descr)
        llDescription!!.setOnClickListener(this)
        rlAddress!!.setOnClickListener(this)
        rlCategory!!.setOnClickListener(this)
        rlSubCategory!!.setOnClickListener(this)
        tvDescription!!.setOnClickListener(this)

        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Service") {
            baseprice!!.visibility = View.VISIBLE
            rateperHour!!.visibility = View.GONE
            securityDeposite!!.visibility = View.GONE
            yaerofPurchase!!.visibility = View.GONE
            homeServiceAvailable!!.visibility = View.VISIBLE
            productnameText!!.text = "Service Name"
            etProductName!!.hint = "Service Name"
            title!!.text = "Service Details"
            removeService!!.text = "Remove Service"
            //            productDescriptionText.setText("Service Description");

        } else {
            productnameText!!.text = "Product Name"
            etProductName!!.hint = "Product Name"
            baseprice!!.visibility = View.GONE
            homeServiceAvailable!!.visibility = View.GONE
            rateperHour!!.visibility = View.VISIBLE
            securityDeposite!!.visibility = View.VISIBLE
            yaerofPurchase!!.visibility = View.VISIBLE
            title!!.text = "Product Details"
            removeService!!.text = "Remove Product"
            //            productDescriptionText.setText("Product Description");

        }


    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_submit -> checkValidation()
            R.id.rl_address -> startActivityResultAddress()
            R.id.ll_descr -> startActivityResultDescr()
            R.id.rl_category -> startActivityResultCategory()
            R.id.rl_subcategory -> startActivityResultSubCategory()
            R.id.back -> finish()
        }
    }

    private fun startActivityResultSubCategory() {
        val subCategoryIntent = Intent(this, SubCategoryListActivity::class.java)
        subCategoryIntent.putStringArrayListExtra("subcategory", subcategoryList)
        startActivityForResult(subCategoryIntent, PERMISSIONS_REQUEST_SUBCATEGORY)
    }

    private fun startActivityResultCategory() {
        val categoryIntent = Intent(this, CategoryListActivity::class.java)
        categoryIntent.putExtra("category", "categoryActivity")
        startActivityForResult(categoryIntent, PERMISSIONS_REQUEST_CATEGORY)
    }

    private fun startActivityResultDescr() {
        val derscriptionIntent = Intent(this, DescriptionActivity::class.java)
        derscriptionIntent.putExtra("1234", tvDescription!!.text.toString().trim { it <= ' ' })
        startActivityForResult(derscriptionIntent, PERMISSIONS_REQUEST_DESCRIPTION)
    }

    private fun startActivityResultAddress() {
        val addressIntent = Intent(this, SelectLocationManually::class.java)
        addressIntent.putExtra("activityName", "ServiceDetailActivity")
        startActivityForResult(addressIntent, PERMISSIONS_REQUEST_ADDRESS)
    }

    private fun checkValidation() {
        val productName = etProductName!!.text.toString()
        val basePrice = etBasePrice!!.text.toString()
        val description = tvDescription!!.text.toString()
        val address = tvAddress!!.text.toString().trim { it <= ' ' }
        val ratePerhour = etrateperYear!!.text.toString()
        val securityDeposite = etSecurityDeposite!!.text.toString()
        val yearofPur = ""

        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Service") {
            if (TextUtils.isEmpty(productName)) {
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter service name")
                //                etProductName.setError("Please enter service Name");
            } else if (TextUtils.isEmpty(basePrice)) {
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter base Price")

                //                etBasePrice.setError("Please enter basePrice");
            } else if (TextUtils.isEmpty(description) || description == "Enter Description") {
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter  the description")

                //                tvDescription.setError("please enter the service description");
            } else if (TextUtils.isEmpty(address) || address == "Address") {
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter the address")

                //                tvAddress.setError("Please select Address");
            } else {
                uploadImagesWithText(productName, basePrice, ratePerhour, securityDeposite, yearofPur, description, address)

            }
        } else {

            if (TextUtils.isEmpty(productName)) {

                //                etProductName.setError("Please enter product Name");
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter the product name")
            } else if (TextUtils.isEmpty(ratePerhour)) {
                //                etrateperYear.setError("Please enter rate per Hour");
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter rate per hour")
            } else if (TextUtils.isEmpty(securityDeposite)) {
                //                etSecurityDeposite.setError("Please enter Security Deposit");
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter security deposit amount")
            } else if (TextUtils.isEmpty(description) || description == "Enter Description") {
                //                tvDescription.setError("please enter the product description");
                CommonUtils.alert(this@AddServicesAndProductActivity, "please enter the  description")
            } else if (TextUtils.isEmpty(address) || address == "Address") {
                //                tvAddress.setError("Please select Address");
                CommonUtils.alert(this@AddServicesAndProductActivity, "Please enter the address")
            } else {
                uploadImagesWithText(productName, basePrice, ratePerhour, securityDeposite, document_type_spinner?.selectedItem.toString(), description, address)
            }

        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        Log.e("addressresult1",""+requestCode+"  "+resultCode)


        if (requestCode == PERMISSIONS_REQUEST_DESCRIPTION) {
            if (resultCode == Activity.RESULT_OK) {
                descriptionResult = data!!.getStringExtra("descriptionResult")
                tvDescription!!.text = descriptionResult
            }
            if (resultCode == Activity.RESULT_CANCELED) {

            }
        } else if (requestCode == PERMISSIONS_REQUEST_ADDRESS) {
            if (resultCode == Activity.RESULT_OK) {
                val address = data!!.getStringExtra("fullAdress")
                tvAddress!!.text = "" + address
            }
            if (resultCode == Activity.RESULT_CANCELED) {

            }

        } else if (requestCode == PERMISSIONS_REQUEST_CATEGORY) {
            if (resultCode == Activity.RESULT_OK) {
                tvSubCategory!!.text = ""
                categoryName = Preferences.getPreference(this, PrefEntity.CATEGORY)
                tvCategory!!.text = "" + categoryName!!
            }
            if (resultCode == Activity.RESULT_CANCELED) {
            }

        } else if (requestCode == PERMISSIONS_REQUEST_SUBCATEGORY) {
            if (resultCode == Activity.RESULT_OK) {
                if (data != null)
                    subcategoryList = data.getStringArrayListExtra("name")
                subcategoryIdList = data!!.getStringArrayListExtra("id")
                setSubCategoryList()
            }
            if (resultCode == Activity.RESULT_CANCELED) {

            }


        }

    }


    private fun uploadImagesWithText(productName: String, basePrice: String, rateperhour: String, securityDeposite: String, yearofPur: String, description: String, address: String) {
        val imageList = ArrayList<String>()
        APIUtility(this@AddServicesAndProductActivity).showDialog(this@AddServicesAndProductActivity, true)
        for (path in RhentoSingleton.getInstance().serviceImagesPath) {
            imageList.add(path)
        }
        val builder = MultipartBody.Builder()
        builder.setType(MultipartBody.FORM)
        builder.addFormDataPart("name", productName)
        builder.addFormDataPart("categoryId", Preferences.getPreference(this, PrefEntity.CATEGORYID))
        if (subcategoryIdList.size > 0)
            builder.addFormDataPart("subcategoryId", Gson().toJson(subcategoryIdList))
        builder.addFormDataPart("description", description)
        builder.addFormDataPart("fullAddress", address)
        builder.addFormDataPart("city", "Noida")


        builder.addFormDataPart("pincode", "201301")


        builder.addFormDataPart("lat", Preferences.getPreference(applicationContext, PrefEntity.LAT))
        builder.addFormDataPart("long", Preferences.getPreference(applicationContext, PrefEntity.LONG))


        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Product") {
            builder.addFormDataPart("services_type", "product")
            builder.addFormDataPart("yearPurchase", yearofPur)
            builder.addFormDataPart("securityDeposite", securityDeposite)
            builder.addFormDataPart("ratePerHour", rateperhour)
            builder.addFormDataPart("rate_type", perHourString)
        } else {

            builder.addFormDataPart("basePrice", basePrice)
            builder.addFormDataPart("services_type", "service")
            builder.addFormDataPart("home_service_available", noString)

        }


        builder.addFormDataPart("user_id", Preferences.getPreference(applicationContext, PrefEntity.USERID))


        for (i in imageList.indices) {
            if (imageList[i] != null) {
                val file = File(imageList[i])
                builder.addFormDataPart("image", file.name, RequestBody.create(MediaType.parse("multipart/form-data"), file))
            }
        }

        val requestBody = builder.build()
        Log.e("requestBody", requestBody.toString())
        val retrofitInterface = RetrofitClientInstance.getRetrofitInstance().create(RetrofitInterface::class.java)
        val call = retrofitInterface.uploadMultiFile(requestBody)
        call.enqueue(object : Callback<ServiceDetailResponseWrapper> {
            override fun onResponse(call: Call<ServiceDetailResponseWrapper>, response: Response<ServiceDetailResponseWrapper>) {

                try {
                    Log.e("IMAGE_DATA", response.body().toString())
                    val signUpResponseWrapper = response.body()
                    if (signUpResponseWrapper!!.response.status == 1) {
                        val intent = Intent(this@AddServicesAndProductActivity, DashBoardActivity::class.java)
                        intent.putExtra("AddService", "Addservice")
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        startActivity(intent)

                        if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Service") {
                            Toast.makeText(this@AddServicesAndProductActivity, "Service uploaded successfully", Toast.LENGTH_SHORT).show()

                        } else {

                            Toast.makeText(this@AddServicesAndProductActivity, "Product uploaded successfully", Toast.LENGTH_SHORT).show()

                        }
                        APIUtility(this@AddServicesAndProductActivity).dismissDialog(true)
                    } else {

                        if (signUpResponseWrapper.response.status == 0);

                        APIUtility(this@AddServicesAndProductActivity).dismissDialog(true)
                        CommonUtils.alert(this@AddServicesAndProductActivity, signUpResponseWrapper.response.message)


                    }
                    Preferences.removePreference(applicationContext, PrefEntity.COMEFROM)
                } catch (e: Exception) {
                    e.printStackTrace()
                    APIUtility(this@AddServicesAndProductActivity).dismissDialog(true)

                }

            }

            override fun onFailure(call: Call<ServiceDetailResponseWrapper>, t: Throwable) {

                val intent = Intent(this@AddServicesAndProductActivity, DashBoardActivity::class.java)
                intent.putExtra("AddService", "Addservice")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)

                if (Preferences.getPreference(applicationContext, PrefEntity.COMEFROM) == "Service") {
                    Toast.makeText(this@AddServicesAndProductActivity, "Service uploaded successfully", Toast.LENGTH_SHORT).show()

                } else {

                    Toast.makeText(this@AddServicesAndProductActivity, "Product uploaded successfully", Toast.LENGTH_SHORT).show()

                }


                Preferences.removePreference(applicationContext, PrefEntity.COMEFROM)
                //               CommonUtils.alert(AddServicesAndProductActivity.this,getString(R.string.VolleyError));
                APIUtility(this@AddServicesAndProductActivity).dismissDialog(true)
            }
        })

    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    companion object {
        private val PERMISSIONS_REQUEST_DESCRIPTION = 1001
        private val PERMISSIONS_REQUEST_ADDRESS = 1002
        private val PERMISSIONS_REQUEST_CATEGORY = 1003
        private val PERMISSIONS_REQUEST_SUBCATEGORY = 1004
    }


}
