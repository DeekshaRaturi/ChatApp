package com.ripenapps.rehntu.adapter;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.FragmentOne;
import com.ripenapps.rehntu.models.transaction.response.Transaction;
import com.ripenapps.rehntu.my_screen.ChatActivity;
import com.ripenapps.rehntu.my_screen.OnLoadMoreListener;

import java.util.ArrayList;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

   private ArrayList<Transaction>transactionlist;
   private Fragment mcontext;
   private TransactionAdapter context;
   private ArrayList<String> servicetype,serviceId,servicename,transaction_id,id,serviceprovidername,buyer_id,is_buyer_list,serviceproviderid,buyername,security_deposit,rate_type;
   private ArrayList<Integer>price_list,countlist,status_list;
    private OnLoadMoreListener mOnLoadMoreListener = null;

    private Boolean isLoading = false;

    private Integer visibleThreshold = 1;

    private Integer lastVisibleItem=0;
    private Integer totalItemCount =0;
    private LinearLayoutManager mLinearLayoutManager;
    private RecyclerView recyclerView;


    public TransactionAdapter(Fragment mcontext, ArrayList<Transaction>transactionlist, ArrayList<String> servicetype, ArrayList<String> serviceId, ArrayList<String> servicename, ArrayList<String> transaction_id, ArrayList<String> id, ArrayList<String> serviceprovidername
            , ArrayList<String> buyer_id, ArrayList<String>is_buyer_list, ArrayList<Integer>status_list, ArrayList<Integer>price_list, ArrayList<String>serviceproviderid, ArrayList<String>buyername, ArrayList<Integer>countlist, ArrayList<String>security_deposit,ArrayList<String>rate_type, RecyclerView recyclerView) {

        this.transactionlist = transactionlist;
        this.mcontext = mcontext;
        this.serviceId = serviceId;
        this.servicetype = servicetype;
        this.servicename = servicename;
        this.transaction_id = transaction_id;
        this.id = id;
        this.serviceprovidername = serviceprovidername;
        this.buyer_id = buyer_id;
        this.is_buyer_list=is_buyer_list;
        this.status_list=status_list;
        this.price_list=price_list;
        this.serviceproviderid=serviceproviderid;
        this.buyername=buyername;
        this.countlist=countlist;
        this.recyclerView=recyclerView;
        context=this;
        this.security_deposit=security_deposit;
        this.rate_type=rate_type;

        Log.e("statlistdata2",""+status_list+" "+rate_type);


        //  mLinearLayoutManager=new LinearLayoutManager(recyclerView.getContext());
       // scroller();


    }

    private void scroller() {

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                totalItemCount = mLinearLayoutManager.getItemCount();


                lastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();

                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold )&& dy > 0) {

                    if (mOnLoadMoreListener != null) {

                        mOnLoadMoreListener.onLoadMore();


                    }

                    isLoading = true;

                }

                mLinearLayoutManager.scrollToPosition(totalItemCount);
            }

        });



    }
    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener ) {

        this.mOnLoadMoreListener = mOnLoadMoreListener;
    }

    public void setLoaded() {
        isLoading = false;
    }

    @Override
    public TransactionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new TransactionAdapter.ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.transaction_fragment_item, viewGroup, false));
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull final TransactionAdapter.ViewHolder viewHolder, final int i) {

        viewHolder.location.setText(transactionlist.get(i).getLocation());
        viewHolder.servicename.setText(transactionlist.get(i).getServicename());
        viewHolder.txt_providername.setText(transactionlist.get(i).getProvidername());
        Log.e("buyername"," "+transactionlist.get(i).getStatus());

        if (transactionlist.get(i).getStatus()==0){
            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.butn_book_now_downarrow.setText("Negotiation");
            viewHolder.butn_book_now_uparrow.setText("Negotiation");
            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.yellow));
        }
        else if (transactionlist.get(i).getStatus()==1){
            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.butn_book_now_downarrow.setText("Booked");
            viewHolder.butn_book_now_uparrow.setText("Booked");

            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.green));

        }
        else if (transactionlist.get(i).getStatus()==2){
            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.butn_book_now_downarrow.setText("Accepted");
            viewHolder.txt_confirmed.setText("Accepted");
            viewHolder.butn_book_now_uparrow.setText("Accepted");

            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.colorAccent));
        }
        else if (transactionlist.get(i).getStatus()==3){
            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
//            viewHolder.uncheckimg_inprogress.setImageResource(R.mipmap.small_check);
            viewHolder.butn_book_now_downarrow.setText("Booked");
            viewHolder.butn_book_now_uparrow.setText("Booked");



        }
        else if (transactionlist.get(i).getStatus()==4){
            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_inprogress.setImageResource(R.mipmap.small_check);
            viewHolder.butn_book_now_downarrow.setText("Payment");
            viewHolder.butn_book_now_uparrow.setText("Payment");

            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.black));
        }
        else if (transactionlist.get(i).getStatus()==5){


            viewHolder.butn_book_now_downarrow.setText("Canceled");
            viewHolder.txt_confirmed.setText("Canceled");
            viewHolder.butn_book_now_uparrow.setText("Canceled");


            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.red));
                   }

          else if (transactionlist.get(i).getStatus()==6){
            viewHolder.butn_book_now_downarrow.setText("Canceled");
            viewHolder.txt_confirmed.setText("Canceled");
            viewHolder.butn_book_now_uparrow.setText("Canceled");


            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.red));



        }

        else  if (transactionlist.get(i).getStatus()==7){

            viewHolder.butn_book_now_downarrow.setText("Complete");
            //viewHolder.txt_confirmed.setText("Complete");
            viewHolder.butn_book_now_uparrow.setText("Complete");


            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_inprogress.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_payment.setImageResource(R.mipmap.small_check);
            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.yellow));
                  }



       /* else  if (transactionlist.get(i).getStatus()==8 || transactionlist.get(i).getStatus()==9||transactionlist.get(i).getStatus()==10|| transactionlist.get(i).getStatus()==11){

            viewHolder.butn_book_now_downarrow.setText("Complete");
            //viewHolder.txt_confirmed.setText("Complete");
            viewHolder.butn_book_now_uparrow.setText("Complete");


            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_inprogress.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_payment.setImageResource(R.mipmap.small_check);
            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.yellow));
        }
*/



        else  {

            viewHolder.butn_book_now_downarrow.setText("Service done");

            viewHolder.uncheckimg_negotition.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_booked.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_confirmed.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_inprogress.setImageResource(R.mipmap.small_check);
            viewHolder.uncheckimg_payment.setImageResource(R.mipmap.small_check);
            viewHolder.butn_book_now_uparrow.setText("Service done");


            viewHolder.bookNowLayoutDown.setBackgroundColor(mcontext.getResources().getColor(R.color.yellow));
           }


        Log.e("transcount",""+transactionlist.get(i).getCount()+"    "+i);


        if (transactionlist.get(i).getCount()!=0){


            viewHolder.txt_count.setText(transactionlist.get(i).getCount().toString());
            viewHolder.txt_count.setVisibility(View.VISIBLE);

        }

        else {
            viewHolder.txt_count.setVisibility(View.GONE);

        }

       if (transactionlist.get(i).getIsexpanded()){

           viewHolder.expand_layout.setVisibility(View.VISIBLE);
       }
        else {

            viewHolder.expand_layout.setVisibility(View.GONE);

       }

        viewHolder.bookNowLayoutDown.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    if (transactionlist.get(i).getIsexpanded()){
                        transactionlist.get(i).setIsexpanded(false);
                        notifyDataSetChanged();
                        Log.e("false","false");
                        viewHolder.butn_book_now_downarrow.setVisibility(View.VISIBLE);
                        viewHolder.butn_book_now_uparrow.setVisibility(View.GONE);


                    }
                    else {
                        for (int i =0;i<=transactionlist.size()-1;i++){

                            if(transactionlist.get(i).getIsexpanded())
                            {
                                transactionlist.get(i).setIsexpanded(false);
                            }
                        }
                        Log.e("true","false");
                        viewHolder.butn_book_now_uparrow.setVisibility(View.VISIBLE);
                        viewHolder.butn_book_now_downarrow.setVisibility(View.GONE);


                        transactionlist.get(i).setIsexpanded(true);
                        notifyDataSetChanged();

                    }






                }
            });

        viewHolder.txt_address_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mcontext.getActivity(), ChatActivity.class);
                intent.putExtra("service_type",servicetype.get(i));
                intent.putExtra("serviceId",serviceId.get(i));
                intent.putExtra("service_name",servicename.get(i));
                intent.putExtra("transaction_id",transaction_id.get(i));
                intent.putExtra("userid",id.get(i));
                intent.putExtra("serviceprovidername",serviceprovidername.get(i));
                intent.putExtra("securityDeposite",security_deposit.get(i));
                intent.putExtra("rate_type",rate_type.get(i));

                intent.putExtra("isbuyer",is_buyer_list.get(i));

                Log.e("posStatus",""+i+"  "+" "+security_deposit.get(i));

                if (is_buyer_list.get(i).equals("true")){
                    intent.putExtra("buyer_id",serviceproviderid.get(i));
                    intent.putExtra("recievername",serviceprovidername);

                }

                else {
                    intent.putExtra("buyer_id",buyer_id.get(i));
                    intent.putExtra("recievername",buyername.get(i));

                }


                intent.putExtra("status",status_list.get(i).toString());
                intent.putExtra("price",price_list.get(i));

                mcontext.startActivityForResult(intent,1200);


            }
        });




//        viewHolder.book_now_layout_up.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                viewHolder.book_now_layout_up.setVisibility(View.GONE);
//                viewHolder.bookNowLayoutDown.setVisibility(View.VISIBLE);
//                viewHolder.expand_layout.setVisibility(View.GONE);
//
//
//
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return transactionlist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView servicename,txt_confirmed,txt_providername;
        private TextView location,txt_count;
        private RecyclerView butn_book_details_recycler;
        private TextView butn_book_now_uparrow,butn_book_now_downarrow;
        private CardView booked_cardview, negotiation_cardview, confirmed_cardview, inprogress_cardview, payment_cardview;
        private RelativeLayout expand_layout, bookNowLayoutDown,book_now_layout_up,txt_address_layout;
        private ImageView img_forward,uncheckimg_negotition,uncheckimg_booked,uncheckimg_confirmed,uncheckimg_inprogress,uncheckimg_payment;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            servicename=(TextView)itemView.findViewById(R.id.txt_servicename);
            location=(TextView)itemView.findViewById(R.id.txt_location);
            txt_providername=(TextView)itemView.findViewById(R.id.txt_providername);

            txt_count=(TextView)itemView.findViewById(R.id.txt_count);

            txt_address_layout=(RelativeLayout) itemView.findViewById(R.id.txt_address_layout);

            butn_book_now_uparrow=(TextView) itemView.findViewById(R.id.butn_book_now_uparrow);
            butn_book_now_downarrow=(TextView)itemView.findViewById(R.id.butn_book_now_downarrow);



            negotiation_cardview =(CardView)itemView.findViewById(R.id.negotiation_cardview);
            booked_cardview =(CardView)itemView.findViewById(R.id.booked_cardview);

            confirmed_cardview =(CardView)itemView.findViewById(R.id.confirmed_cardview);
            inprogress_cardview =(CardView)itemView.findViewById(R.id.inprogress_cardview);

            payment_cardview =(CardView)itemView.findViewById(R.id.payment_cardview);
            expand_layout =(RelativeLayout)itemView.findViewById(R.id.expand_layout);

            bookNowLayoutDown =(RelativeLayout)itemView.findViewById(R.id.book_now_layout_down);
           // book_now_layout_up=(RelativeLayout)itemView.findViewById(R.id.book_now_layout_up);

            img_forward=(ImageView)itemView.findViewById(R.id.img_forward);
            uncheckimg_negotition=(ImageView)itemView.findViewById(R.id.uncheckimg_negotition);
            uncheckimg_booked=(ImageView)itemView.findViewById(R.id.uncheckimg_booked);
            uncheckimg_confirmed=(ImageView)itemView.findViewById(R.id.uncheckimg_confirmed);
            uncheckimg_inprogress=(ImageView)itemView.findViewById(R.id.uncheckimg_inprogress);
            uncheckimg_payment=(ImageView)itemView.findViewById(R.id.uncheckimg_payment);

            txt_confirmed=(TextView)itemView.findViewById(R.id.txt_confirmed);



        }
    }

}
