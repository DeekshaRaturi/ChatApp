package com.ripenapps.rehntu.my_screen

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.acceptDeclineChat.request.AcceptDeclineRequest
import com.ripenapps.rehntu.models.acceptDeclineChat.response.AcceptDeclineWrapper
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.lang.Exception
import java.net.URISyntaxException
import java.text.SimpleDateFormat
import java.util.*

class PaymentActivity : AppCompatActivity(),View.OnClickListener {

    private var payment_text:TextView?= null
    private var price:String?=null
    private var transaction:String?=null
    private var service_name:String?=null
    private var serviceId:String?=null
    private var service_type:String?=null
    private var user_id:String?=null
    private var apiUtility: APIUtility? = null

    private val socket_url = "http://18.216.101.125:3000"
    private var mSocket: Socket? = null
    private var currenttime: String? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        payment_text=findViewById(R.id.payment_text)
        payment_text?.setOnClickListener(this)

        price=intent.getStringExtra("price")
        transaction=intent.getStringExtra("transaction")
        serviceId=intent.getStringExtra("serviceId")
        service_type=intent.getStringExtra("service_type")
        service_name=intent.getStringExtra("service_name")
        user_id=intent.getStringExtra("user_id")

        apiUtility=APIUtility(this@PaymentActivity)
        socketConnection()
        socketTestConnection()
        getConvertedTime()


    }

    override fun onClick(v: View?) {
        when(v?.id){

            R.id.payment_text->{

                getPaymentStatus()


            }
        }



    }
    fun socketConnection() {

        try {
            mSocket = IO.socket(socket_url)


        } catch (e: URISyntaxException) {

        }

        mSocket!!.connect()




        mSocket!!.on("connected") {

        }


        mSocket!!.on("socket") { args ->


        }

    }
    private fun socketTestConnection() {


        val jsonObject: JSONObject = JSONObject()

        jsonObject?.put("room", transaction)
        jsonObject?.put("user_id", Preferences.getPreference(this@PaymentActivity, PrefEntity.USERID))

        mSocket?.emit("test", jsonObject)


        mSocket?.on("test") { args ->

            val data = args[0] as JSONObject


        }

    }




    fun getPaymentStatus() {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@PaymentActivity, PrefEntity.USERID)
        request.transaction_id = transaction;
        request.status = "4"
        request.price = price
        var gson=Gson()
        Log.e("payment"," "+gson.toJson(request))


        apiUtility?.getAcceptDecline(this@PaymentActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                Toast.makeText(applicationContext,"Payment Successfully",Toast.LENGTH_SHORT).show()


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@PaymentActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@PaymentActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", "4")
                    jsonObject1.put("price",price)

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })
    }

    fun getConvertedTime() {

        var currentTime = Calendar.getInstance().getTime()

        var dateFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
        // var dateFormatter =  SimpleDateFormat("dd-MM-yyyy HH:mm:ss")

        dateFormatter.setTimeZone(TimeZone.getDefault())
        currenttime = dateFormatter.format(currentTime)


    }

}
