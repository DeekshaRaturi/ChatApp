package com.ripenapps.rehntu.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.ServiceFragment;
import com.ripenapps.rehntu.models.services.respponse.Services;
import com.ripenapps.rehntu.my_util.Constants;
import com.squareup.picasso.Picasso;

import java.util.List;

public class ServiceListAdapter extends RecyclerView.Adapter<ServiceListAdapter.ViewHolder> {

    private ServiceFragment mContext;
    private List<Services> serviceList;
    ServiceLIstAdapterCallback callback;


    public ServiceListAdapter(List<Services> streetList, ServiceFragment mContext) {
        this.mContext = mContext;
        this.serviceList = streetList;
        this.callback=(ServiceLIstAdapterCallback)mContext;


    }

    @Override
    public ServiceListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ServiceListAdapter.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.service_list, parent, false));
    }


    @Override
    public void onBindViewHolder(final ServiceListAdapter.ViewHolder holder, final int position) {
        holder.tvProductName.setText(serviceList.get(position).getName());
        holder.tvPrice.setText(" $ "+serviceList.get(position).getBasePrice());
        if(serviceList.get(position).getImages().size()>0)
            Picasso.with(mContext.getActivity()).load(Constants.IMG_URL + serviceList.get(position).getImages().get(0)).placeholder(R.drawable.place_holder).into(holder.ivProduct);

        holder.ivProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.OnItemClick(position);
            }
        });

    }


    @Override
    public int getItemCount() {
        return serviceList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {


            private ImageView  ivProduct;
            private TextView tvPrice,tvProductName;

            public ViewHolder( View itemView) {
                super(itemView);
                ivProduct = itemView.findViewById(R.id.iv_product);
                tvPrice = itemView.findViewById(R.id.tv_price);
                tvProductName = itemView.findViewById(R.id.tv_product);
            }

        }



    public  interface ServiceLIstAdapterCallback{
        void OnItemClick(int pos);
    }
}




