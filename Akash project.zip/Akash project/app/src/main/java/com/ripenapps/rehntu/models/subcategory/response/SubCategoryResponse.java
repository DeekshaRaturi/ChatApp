package com.ripenapps.rehntu.models.subcategory.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class SubCategoryResponse extends BaseResponse {

    @SerializedName("result")
    private SubCategoryResponseResult result;

    public SubCategoryResponseResult getResult() {
        return result;
    }

    public void setResult(SubCategoryResponseResult result) {
        this.result = result;
    }
}
