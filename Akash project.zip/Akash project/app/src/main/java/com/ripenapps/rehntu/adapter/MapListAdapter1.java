package com.ripenapps.rehntu.adapter;

import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.ListFragment;
import com.ripenapps.rehntu.models.product.respponse.Product;
import com.ripenapps.rehntu.my_screen.ServiceAndProductDetailActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MapListAdapter1 extends RecyclerView.Adapter<MapListAdapter1.ViewHolder> {

    private ListFragment mContext;
    private ArrayList<Product> productList;
    DecimalFormat format = new DecimalFormat("##.##");

    public MapListAdapter1(ArrayList<Product> productArrayList, ListFragment listFragment) {
        this.mContext=listFragment;
        this.productList=productArrayList;
    }


    @Override
    public MapListAdapter1.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MapListAdapter1.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.maplist, parent, false));
    }


    @Override
    public void onBindViewHolder(final MapListAdapter1.ViewHolder holder, final int i) {
        holder.textViewName.setText(productList.get(i).getName());
        holder.textViewAddress.setText(productList.get(i).getAddress().getFullAddress());
        if (productList.get(i).getDistance() != null) {
            holder.textViewDistance.setText(format.format(Double.parseDouble(productList.get(i).getDistance())) + " miles");

        } else {
            holder.textViewDistance.setText("0.00" + " miles");
        }

        holder.textViewRating.setText("0.00");
        holder.textViewPrice.setText(productList.get(i).getRatePerHour() + "/h");
        holder.detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(mContext.getActivity(), ServiceAndProductDetailActivity.class);
                intent.putExtra("id",productList.get(i).getId());
                intent.putExtra("userid",productList.get(i).getUser_id());

                Log.e("toast"," "+productList.get(i).getUser_id());
                Log.e("useriddata"," "+productList.get(i).getUser_id());
                mContext.startActivity(intent);

            }
        });

    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textViewName, textViewAddress, textViewDistance, textViewRating, textViewPrice;
        private CardView detail;

        public ViewHolder(View itemView) {
            super(itemView);

            textViewName = itemView.findViewById(R.id.tv_name);
            detail = itemView.findViewById(R.id.detail);
            textViewAddress = itemView.findViewById(R.id.tv_address);
            textViewDistance = itemView.findViewById(R.id.tv_distance);
            textViewRating = itemView.findViewById(R.id.tv_rating);
            textViewPrice = itemView.findViewById(R.id.tv_price);
        }


    }


}
