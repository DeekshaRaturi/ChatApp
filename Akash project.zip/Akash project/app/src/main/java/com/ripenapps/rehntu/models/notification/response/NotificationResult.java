package com.ripenapps.rehntu.models.notification.response;

import com.google.gson.annotations.SerializedName;

public class NotificationResult {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @SerializedName("name")
    String name;
}
