package com.ripenapps.rehntu.models.acceptDeclineChat.response;

import com.google.gson.annotations.SerializedName;

public class AcceptDeclineWrapper {


    @SerializedName("data")
    private AcceptDeclineResponse response;

    public AcceptDeclineResponse getResponse() {
        return response;
    }

    public void setResponse(AcceptDeclineResponse response) {
        this.response = response;
    }


}
