package com.ripenapps.rehntu.models.walletamount.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.showBooking.response.ShowBookingResponse;

public class GetWalletWrapper {

    public GetWalletResponse getResponse() {
        return response;
    }

    public void setResponse(GetWalletResponse response) {
        this.response = response;
    }

    @SerializedName("data")
    private GetWalletResponse response;

}
