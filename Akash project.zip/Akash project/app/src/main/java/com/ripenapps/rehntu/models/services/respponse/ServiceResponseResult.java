package com.ripenapps.rehntu.models.services.respponse;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ServiceResponseResult {

    @SerializedName("service")
    List<Services> servicesList = new ArrayList<>();

    public List<Services> getServicesList() {
        return servicesList;
    }

    public void setServicesList(List<Services> servicesList) {
        this.servicesList = servicesList;
    }
}
