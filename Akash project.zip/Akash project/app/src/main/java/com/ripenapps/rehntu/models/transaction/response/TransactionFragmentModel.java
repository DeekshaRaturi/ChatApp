package com.ripenapps.rehntu.models.transaction.response;

import android.os.Parcel;
import android.os.Parcelable;

public class TransactionFragmentModel implements Parcelable {

    String address;
    String service_id;
    String service_type;
    String status;
    String service_provider_id;
    Integer price;
    String service_name;
    String transaction_id;
    String _id;
    String buyer_id;
    String is_buyer;
    String unseen_Count;


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getService_provider_id() {
        return service_provider_id;
    }

    public void setService_provider_id(String service_provider_id) {
        this.service_provider_id = service_provider_id;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getBuyer_id() {
        return buyer_id;
    }

    public void setBuyer_id(String buyer_id) {
        this.buyer_id = buyer_id;
    }

    public String getIs_buyer() {
        return is_buyer;
    }

    public void setIs_buyer(String is_buyer) {
        this.is_buyer = is_buyer;
    }

    public String getUnseen_Count() {
        return unseen_Count;
    }

    public void setUnseen_Count(String unseen_Count) {
        this.unseen_Count = unseen_Count;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {


    }
    public  TransactionFragmentModel(){




    }
}
