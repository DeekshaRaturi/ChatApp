package com.ripenapps.rehntu.models.checkRegistration.response;

import com.google.gson.annotations.SerializedName;

public class CheckRegistrationResponseWrapper {

    @SerializedName("data")
    private CheckRegistrationRes response;

    public CheckRegistrationRes getResponse() {
        return response;
    }

    public void setResponse(CheckRegistrationRes response) {
        this.response = response;
    }
}
