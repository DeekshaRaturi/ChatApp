package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.map.response.Service;

public class MarkerInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
    private Context context;
    private Service service;

    public MarkerInfoWindowAdapter(Context context, final Service service) {
        this.context = context.getApplicationContext();
        this.service = service;
    }


    @Override
    public View getInfoWindow(Marker arg0) {
        return null;
    }

    @Override
    public View getInfoContents(Marker arg0) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


        View v = inflater.inflate(R.layout.custom_window, null);
        v.setLayoutParams(new LinearLayout.LayoutParams(500, ViewGroup.LayoutParams.WRAP_CONTENT));

        final TextView name = v.findViewById(R.id.tv_name);
        final TextView rating = v.findViewById(R.id.tv_rating);
        final TextView price = v.findViewById(R.id.tv_price);
        if (service.getServices_type().equals("product")) {
            name.setText(service.getName());
            rating.setText("0.00");
            price.setText(service.getRatePerHour()+"/h");
        }else {
            name.setText(service.getName());
            rating.setText(service.getAvgRating());
            price.setText(service.getBasePrice());
        }


        return v;


    }
}
