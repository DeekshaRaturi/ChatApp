package com.ripenapps.rehntu.models.chat.response;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class GetChatResult {

    @SerializedName("first_user_name")
    private String first_user_name = "";

   @SerializedName("user_msgs")
    private ArrayList<JsonObject>user_msgs;

    public ArrayList<JsonObject> getUser_msgs() {
        return user_msgs;
    }

    public void setUser_msgs(ArrayList<JsonObject> user_msgs) {
        this.user_msgs = user_msgs;
    }


    public String getFirst_user_name() {
        return first_user_name;
    }

    public void setFirst_user_name(String first_user_name) {
        this.first_user_name = first_user_name;
    }
}
