package com.ripenapps.rehntu.models.giveFeedback.response;

public class GiveFeedbackResult {


}


