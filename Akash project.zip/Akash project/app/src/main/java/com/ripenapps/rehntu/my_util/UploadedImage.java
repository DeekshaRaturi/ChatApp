package com.ripenapps.rehntu.my_util;

import android.graphics.Bitmap;

public class UploadedImage {

    int imageRresource;
    private Bitmap uploadedImageBitmap;

    public UploadedImage(Bitmap uploadedImageBitmap) {
        this.uploadedImageBitmap = uploadedImageBitmap;
    }

    public Bitmap getUploadedImageBitmap() {
        return uploadedImageBitmap;
    }

    public void setUploadedImageBitmap(Bitmap uploadedImageBitmap) {
        this.uploadedImageBitmap = uploadedImageBitmap;
    }

    public int getImageRresource() {
        return imageRresource;
    }

    public void setImageRresource(int imageRresource) {
        this.imageRresource = imageRresource;
    }
}
