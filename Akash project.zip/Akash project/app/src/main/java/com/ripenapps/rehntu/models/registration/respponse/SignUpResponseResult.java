package com.ripenapps.rehntu.models.registration.respponse;

import com.google.gson.annotations.SerializedName;

public class SignUpResponseResult {

    @SerializedName("status")
    private boolean status;
    @SerializedName("is_verified")
    private boolean is_verified;
    @SerializedName("_id")
    private String _id;
    @SerializedName("name")
    private String name;
    @SerializedName("email")
    private String email;
    @SerializedName("password")
    private String password;
    @SerializedName("mobile_no")
    private String mobile_no;
    @SerializedName("created_at")
    private String created_at;
    @SerializedName("_v")
    private String __v;

    @SerializedName("doc_verify")
    private String doc_Verify;

    public String getDoc_Verify() {
        return doc_Verify;
    }

    public void setDoc_Verify(String doc_Verify) {
        this.doc_Verify = doc_Verify;
    }

    public String getDocument_type() {
        return document_type;
    }

    public void setDocument_type(String document_type) {
        this.document_type = document_type;
    }

    @SerializedName("document_type")
    private String document_type;

    @SerializedName("country_code")
    private String country_code;

    public boolean isStatus() {
        return status;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isIs_verified() {
        return is_verified;
    }

    public void setIs_verified(boolean is_verified) {
        this.is_verified = is_verified;
    }

    public String get__v() {
        return __v;
    }

    public void set__v(String __v) {
        this.__v = __v;
    }

}
