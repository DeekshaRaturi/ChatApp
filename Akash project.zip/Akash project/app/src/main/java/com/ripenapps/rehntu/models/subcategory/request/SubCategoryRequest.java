package com.ripenapps.rehntu.models.subcategory.request;

import com.google.gson.annotations.SerializedName;

public class SubCategoryRequest {


    @SerializedName("user_id")
    private String userID;

    @SerializedName("service_type")
    private String serviceType;

    @SerializedName("text")
    private String text;


    @SerializedName("category_id")
    private String category_id;


    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }
}
