package com.ripenapps.rehntu.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.TabAdapter;
import com.ripenapps.rehntu.adapter.TransactionAdapter;
import com.ripenapps.rehntu.models.transaction.request.GetTransactionRequest;
import com.ripenapps.rehntu.models.transaction.response.GetTransactionResponseWrapper;
import com.ripenapps.rehntu.models.transaction.response.Transaction;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.DialogBoxs;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;
import com.ripenapps.rehntu.volley.AppController;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import static com.facebook.FacebookSdk.getApplicationContext;

public class FragmentOne extends Fragment {
    View view;
    APIUtility apiUtility;
    private RecyclerView recyclerView;
    private ArrayList<Transaction> transactionlist = new ArrayList<>();
    private TransactionAdapter transactionAdapter;
    private Context context;
    private Button butn_book_now;
    private RecyclerView butn_book_details_recycler;
    // private ImageView filter;
    private String user_id;
    private ProgressBar progressBar;
    private String serviceId;
    private String servicename, buyer_id, is_buyer,securitydeposit;
    private String servicetype, transaction_id, id, serviceprovidername, service_providerId, buyername,security_deposite,rate_type;
    private DialogBoxs dialogBoxs;
    private int status;
    private TextView no_datafound;
    private SwipeRefreshLayout swiper;
    private ArrayList<String> service_type_list = new ArrayList<>();
    private ArrayList<String>security_deposite_list=new ArrayList<>();
    private ArrayList<String> transaction_id_list = new ArrayList<>();
    private ArrayList<String> serviceprovidername_list = new ArrayList<>();
    private ArrayList<String> buyer_id_list = new ArrayList<>();
    private ArrayList<String> servicename_list = new ArrayList<>();
    private ArrayList<String> serviceId_list = new ArrayList<>();
    private ArrayList<String>rate_type_list=new ArrayList<>();
    private ArrayList<String>security_deposit=new ArrayList<>();
    private ArrayList<String> id_list = new ArrayList<>();
    private ArrayList<String> is_buyer_list = new ArrayList<>();
    private ArrayList<Integer> status_list = new ArrayList<>();
    private ArrayList<Integer> price_list = new ArrayList<>();
    private ArrayList<String> Serviceproviderid_list = new ArrayList<>();
    private ArrayList<String> Buyer_name = new ArrayList<>();
    private final int interval = 1000; // 1 Second
    private Timer mTimer1;
    private TimerTask mTt1;
    private Handler mTimerHandler = new Handler();
    private Integer unseen_Count;
    private ArrayList<Integer> count_list = new ArrayList<>();
    private Boolean aBoolean = false;
    private LinearLayoutManager layoutManager;
    private Integer currentPage = 1;
    private Boolean NextPage = false;
    private Integer firstVisiblesItems = 0;
    private Integer lastVisiblesItems = 0;
    private Integer totalPages = 0;// get your total pages from web service first response

    private Boolean canLoadMoreData = true;
    private Integer visibleItemCount = 0;
    private Integer totalItemCount = 0;
    private Integer PAGE_SIZE = 10;

    private Integer PAGE_STARTED = 1;
    private Integer PAGE_REFRESH = 1;
    private JsonArray array=new JsonArray();
    private String from=null;
    private String to=null;
    private String service_type=null;
    private JsonArray status_list_value=new JsonArray();


    private Integer price;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragmentone, container, false);
        context=getActivity();

        init();
        return view;


    }

    private void init() {
        apiUtility = new APIUtility(getActivity());
        recyclerView=(RecyclerView)view.findViewById(R.id.transaction_recyclerview);
        user_id= Preferences.getPreference(getApplicationContext(), PrefEntity.USERID);

        from = ((AppController) getApplicationContext()).getFrom();
        to = ((AppController) getApplicationContext()).getTo();
        status_list_value = ((AppController) getApplicationContext()).getStatus_value();
        service_type=((AppController) getApplicationContext()).getService_type();






        butn_book_details_recycler = (RecyclerView) view.findViewById(R.id.transaction_recyclerview);

        no_datafound = (TextView) view.findViewById(R.id.no_datafound);

        swiper = (SwipeRefreshLayout) view.findViewById(R.id.swiper);


             /* if (isNetworkAvailable()) {

                  transactionDetails(user_id);
              }else {

                  CommonUtils.alert(getActivity(),"Please check Internet Connection");
              }*/

        //startTimer();

        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {


                transactionlist.clear();
                transactionDetails(user_id);

            }
        });


    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void startTimer(){
        mTimer1 = new Timer();
        mTt1 = new TimerTask() {
            public void run() {
                mTimerHandler.post(new Runnable() {
                    public void run(){
                        // transactionlist.clear();
                        count_list.clear();
                        transactionDetails(user_id);
                    }
                });
            }
        };

        mTimer1.schedule(mTt1, 1, 5000);
    }


    private void transactionDetails(final String user_id) {

        final GetTransactionRequest request = new GetTransactionRequest();


        request.setUser_id(user_id);

        if (!TextUtils.isEmpty(from)){

            request.setFrom(from);
        }
        else {
            request.setFrom("");
        }
        if (!TextUtils.isEmpty(to)) {
            request.setTo(to);
        }
        else {

            request.setTo("");
        }

        if (!TextUtils.isEmpty(service_type)) {

            request.setService_type(service_type);
        }
        else {
            request.setService_type("");
        }

          request.setCustomer(" ");


            request.setStatus(status_list_value);


        apiUtility.getTransactionDetails(context, request, true, new APIUtility.APIResponseListener<GetTransactionResponseWrapper>() {


            @Override
            public void onReceiveResponse(GetTransactionResponseWrapper response) {

                if (response != null) {

                    swiper.setRefreshing(false);

                    transactionlist.clear();
                    status_list.clear();

                    if (response.getResponse().getGetTransactionResult().getBooking_list().size() > 0) {


                        for (int i = 0; i <= response.getResponse().getGetTransactionResult().getBooking_list().size() - 1; i++) {

                            String address = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("address").getAsJsonObject().get("fullAddress").getAsString();
                            String serviceAddress=response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("serviceAddress").getAsJsonObject().get("fullAddress").getAsString();

                            serviceId = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_id").getAsString();
                            serviceId_list.add(serviceId);

                            servicetype = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_type").getAsString();
                            service_type_list.add(servicetype);

                            rate_type=response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("rate_type").getAsString();
                            rate_type_list.add(rate_type);

                            if (response.getResponse().getGetTransactionResult().getBooking_list().get(i).has("security_deposite")) {
                                security_deposite = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("security_deposite").getAsString();
                                security_deposite_list.add(security_deposite);
                            }
                            else {
                                security_deposite_list.add("");
                            }


                            status = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("status").getAsInt();

                            status_list.add(status);

                            service_providerId = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_provider_id").getAsString();
                            Serviceproviderid_list.add(service_providerId);
                            buyername=response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("buyer_name").getAsString();



                            if (response.getResponse().getGetTransactionResult().getBooking_list().get(i).has("price")) {
                                price = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("price").getAsInt();

                                price_list.add(price);
                            } else {
                                price_list.add(0);

                            }

                            servicename = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_name").getAsString();
                            servicename_list.add(servicename);

                            transaction_id = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("transaction_id").getAsString();
                            transaction_id_list.add(transaction_id);

                            id = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("_id").getAsString();
                            id_list.add(id);

                            buyer_id = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("buyer_id").getAsString();
                            buyer_id_list.add(buyer_id);

                            is_buyer = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("is_buyer").getAsString();
                            is_buyer_list.add(is_buyer);

                            unseen_Count = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("unseen_Count").getAsInt();

                            count_list.add(unseen_Count);


                            serviceprovidername = response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_provider_name").getAsString();
                            serviceprovidername_list.add(serviceprovidername);

                            if (is_buyer.equals("true")) {

                                transactionlist.add(new Transaction(response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_name").getAsString(), serviceAddress, false, response.getResponse().getGetTransactionResult().
                                        getBooking_list().get(i).get("status").getAsInt(), count_list.get(i), serviceprovidername));
                                Buyer_name.add("");
                            }
                            else {
                                transactionlist.add(new Transaction(response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("service_name").getAsString(), address, false, response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("status").getAsInt(), count_list.get(i), buyername));
                                Buyer_name.add(response.getResponse().getGetTransactionResult().getBooking_list().get(i).get("buyer_name").getAsString());


                            }

                            setAdapter(serviceId_list, service_type_list, servicename_list, transaction_id_list, id_list, serviceprovidername_list,
                                    buyer_id_list, is_buyer_list, status_list, price_list, Serviceproviderid_list, Buyer_name, count_list,security_deposite_list,rate_type_list, recyclerView);




                        }

                        no_datafound.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                    }
                    else {

                        no_datafound.setVisibility(View.VISIBLE);
                        no_datafound.setText("No Transactions Found");
                        recyclerView.setVisibility(View.GONE);

                    }
                }


            }

            @Override
            public void onResponseFailed() {


                CommonUtils.alert(context, getString(R.string.VolleyError));
            }

            @Override
            public void onStatusFalse(GetTransactionResponseWrapper response) {

                no_datafound.setVisibility(View.VISIBLE);
                no_datafound.setText("No Transactions Found");
                recyclerView.setVisibility(View.GONE);


            }


        });


    }



    private void setAdapter(ArrayList<String> serviceId,ArrayList<String> servicetype,ArrayList<String> servicename,ArrayList<String> transaction_id,ArrayList<String> id,ArrayList<String> serviceprovidername,
                            ArrayList<String> buyer_id,ArrayList<String>is_buyer_list,ArrayList<Integer>status_list,ArrayList<Integer>price_list,
                            ArrayList<String>serviceproviderid_list,ArrayList<String>buyer_name,ArrayList<Integer>count_list,ArrayList<String>security_deposite_list,ArrayList<String>rate_type_list,RecyclerView recyclerView){


       // transactionAdapter=new TransactionAdapter(getActivity(),transactionlist,servicetype,serviceId,servicename,transaction_id,id,serviceprovidername,buyer_id,is_buyer_list,status_list,price_list,serviceproviderid_list,buyer_name,count_list,recyclerView);
       transactionAdapter=new TransactionAdapter(FragmentOne.this,transactionlist,servicetype,serviceId,servicename,transaction_id,id,serviceprovidername,buyer_id,is_buyer_list,status_list,price_list,serviceproviderid_list,buyer_name,count_list,security_deposite_list,rate_type_list,recyclerView);
        recyclerView.setAdapter(transactionAdapter);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        transactionAdapter.notifyDataSetChanged();




    }

    @Override
    public void onResume() {
        super.onResume();

        from = ((AppController) getApplicationContext()).getFrom();
        to = ((AppController) getApplicationContext()).getTo();
        status_list_value = ((AppController) getApplicationContext()).getStatus_value();
        service_type=((AppController) getApplicationContext()).getService_type();

        transactionDetails(user_id);
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }
}
