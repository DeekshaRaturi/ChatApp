package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.NotificationFragment;
import com.ripenapps.rehntu.models.getAllNotification.request.Notification;

import java.util.ArrayList;

public class NotificationAdapter  extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {


    private ArrayList<Notification> notificationlist;
    private Context context;
    private NotificationFragment notificationFragment;



    public NotificationAdapter(NotificationFragment notificationFragment, ArrayList<Notification> notificationlist) {
        this.context=context;
        this.notificationlist=notificationlist;
        this.notificationFragment=notificationFragment;
    }


    @NonNull
    @Override
    public NotificationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return  new NotificationAdapter.ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.notification_items, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationAdapter.ViewHolder viewHolder, int i) {

        viewHolder.txt_date.setText(notificationlist.get(i).getDate());
        viewHolder.txt_notification.setText(notificationlist.get(i).getNotification());

    }

    @Override
    public int getItemCount() {
        return notificationlist.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView txt_notification,txt_date;


        public ViewHolder(@NonNull View itemView) {

            super(itemView);
            txt_notification=(TextView)itemView.findViewById(R.id.txt_notification);
            txt_date=(TextView)itemView.findViewById(R.id.txt_date);
        }
    }
}
