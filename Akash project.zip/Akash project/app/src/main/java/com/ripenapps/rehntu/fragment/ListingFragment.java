package com.ripenapps.rehntu.fragment;

import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewCompat;
import android.support.v7.content.res.AppCompatResources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.checkDocVerificationStatus.request.DocVerificationStatusRequest;
import com.ripenapps.rehntu.models.checkDocVerificationStatus.response.DocVerificationStatusResponseWrapper;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;


public class ListingFragment extends Fragment {
    private View view;
    private APIUtility apiUtility;
    private TabLayout tabLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_listing, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
//        showServiceFragment();
        docVerificationStatus();
        return view;
    }


    private void InitView() {
        tabLayout = (TabLayout) view.findViewById(R.id.tabs);
        tabLayout.addTab(tabLayout.newTab().setText("Services"));
        tabLayout.addTab(tabLayout.newTab().setText("Products"));
        setTabBG(R.drawable.tab_left_select, R.drawable.tab_right_unselect);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tabLayout.getSelectedTabPosition() == 0) {
                    showServiceFragment();

                } else {
                    showProductFragment();

                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }


    private void setTabBG(int tab1, int tab2) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ViewGroup tabStrip = (ViewGroup) tabLayout.getChildAt(0);
            View tabView1 = tabStrip.getChildAt(0);
            View tabView2 = tabStrip.getChildAt(1);
            if (tabView1 != null) {
                int paddingStart = tabView1.getPaddingStart();
                int paddingTop = tabView1.getPaddingTop();
                int paddingEnd = tabView1.getPaddingEnd();
                int paddingBottom = tabView1.getPaddingBottom();
                ViewCompat.setBackground(tabView1, AppCompatResources.getDrawable(tabView1.getContext(), tab1));
                ViewCompat.setPaddingRelative(tabView1, paddingStart, paddingTop, paddingEnd, paddingBottom);
            }

            if (tabView2 != null) {
                int paddingStart = tabView2.getPaddingStart();
                int paddingTop = tabView2.getPaddingTop();
                int paddingEnd = tabView2.getPaddingEnd();
                int paddingBottom = tabView2.getPaddingBottom();
                ViewCompat.setBackground(tabView2, AppCompatResources.getDrawable(tabView2.getContext(), tab2));
                ViewCompat.setPaddingRelative(tabView2, paddingStart, paddingTop, paddingEnd, paddingBottom);
            }
        }
    }


    private void docVerificationStatus() {


        DocVerificationStatusRequest request = new DocVerificationStatusRequest(Preferences.getPreference(getActivity(), PrefEntity.USERID));
        apiUtility.docVerification(getActivity(), request, true, new APIUtility.APIResponseListener<DocVerificationStatusResponseWrapper>() {
            @Override
            public void onReceiveResponse(DocVerificationStatusResponseWrapper response) {
                if (response != null) {
                    if (response.getResponse().getResult().getDoc_Verify().equals("0") || response.getResponse().getResult().getDoc_Verify().equals("1")) {
                        tabLayout.setVisibility(View.GONE);
                        showDocVerificationFragment();
                    } else {
                        tabLayout.setVisibility(View.VISIBLE);
                        /*if (Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM).equals("Product")){
                            showProductFragment();
                        }*/
                            /*else{*/
                            showServiceFragment();
                       /* }*/

                    }

                    Preferences.setPreference(getActivity(),PrefEntity.DOCVERIFY,response.getResponse().result.getDoc_Verify());
                }
            }

            @Override
            public void onResponseFailed() {
                CommonUtils.alert(getActivity(), getString(R.string.VolleyError));
            }

            @Override
            public void onStatusFalse(DocVerificationStatusResponseWrapper response) {
                CommonUtils.alert(getActivity(), response.getResponse().getMessage());

            }
        });
    }

    private void showServiceFragment() {
        setTabBG(R.drawable.tab_left_select, R.drawable.tab_right_unselect);
        ServiceFragment fragment = new ServiceFragment();
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.root_layout, fragment);
        fragmentTransaction.commit();
    }

    private void showProductFragment() {
        setTabBG(R.drawable.tab_left_unselect, R.drawable.tab_right_select);
        ProductFragment fragment = new ProductFragment();
        FragmentTransaction fragmentTransaction = (getChildFragmentManager().beginTransaction());
        fragmentTransaction.replace(R.id.root_layout, fragment);
        fragmentTransaction.commit();
    }

    private void showDocVerificationFragment() {
        DocVerifyFragment fragment = new DocVerifyFragment();
        FragmentTransaction fragmentTransaction = (getChildFragmentManager().beginTransaction());
        fragmentTransaction.replace(R.id.root_layout, fragment);
        fragmentTransaction.commit();
    }
}
