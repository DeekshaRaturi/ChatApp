package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.CardView
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.adyen.checkout.core.CheckoutException
import com.adyen.checkout.core.PaymentController
import com.adyen.checkout.core.PaymentMethodHandler
import com.adyen.checkout.core.StartPaymentParameters
import com.adyen.checkout.core.handler.StartPaymentParametersHandler
import com.adyen.checkout.ui.CheckoutController
import com.adyen.checkout.ui.CheckoutSetupParameters
import com.adyen.checkout.ui.CheckoutSetupParametersHandler
import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.acceptDeclineChat.request.AcceptDeclineRequest
import com.ripenapps.rehntu.models.acceptDeclineChat.response.AcceptDeclineWrapper
import com.ripenapps.rehntu.models.bookNow.request.BooknowRequest
import com.ripenapps.rehntu.models.bookNow.response.BookNowWrapper
import com.ripenapps.rehntu.models.chat.response.Chat
import com.ripenapps.rehntu.models.payment.request.Payment
import com.ripenapps.rehntu.models.payment.response.PaymentWrapperValue
import com.ripenapps.rehntu.models.paymentSession.request.PaymentRequest
import com.ripenapps.rehntu.models.paymentSession.response.PaymentWrapper
import com.ripenapps.rehntu.models.showBooking.request.ShowBookingRequest
import com.ripenapps.rehntu.models.showBooking.response.ShowBookingWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.Constants
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_service_booking_detail.*
import kotlinx.android.synthetic.main.fragment_home.*
import org.json.JSONException
import org.json.JSONObject
import java.lang.Exception
import java.net.URISyntaxException
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class ProductBookingDetailsActivity : AppCompatActivity(), View.OnClickListener {

    private var apiUtility: APIUtility? = null
    private var transaction: String? = null
    private var mcontext: Context? = null
    private var txt_product_owner_text: TextView? = null
    private var txt_productname: TextView? = null
    private var txt_from: EditText? = null
    private var txt_to: EditText? = null
    private var txt_amount: TextView? = null
    private var txt_amount_value: EditText? = null
    private var txt_address_place: EditText? = null
    private var back: ImageView? = null
    private var status: String? = null
    private var isbuyer: String? = null
    private var title: AppCompatTextView? = null
    private var btn_damage: Button? = null
    private var btn_handover: Button? = null

    private var address_cardview: CardView? = null


    private var mYear: Int = 0
    private var mMonth: Int = 0
    private var mDay: Int = 0
    private var cancle_edit_layout: LinearLayout? = null
    private var paymentcancle_layout: LinearLayout? = null
    private var accept_decline_layout: LinearLayout? = null
    private var accept_cancle_layout: LinearLayout? = null
    private var accept_btn: Button? = null
    private var decline_btn: Button? = null
    private val socket_url = "http://18.216.101.125:3000"
    private var mSocket: Socket? = null
    private var currenttime: String? = null
    private var service_type: String? = null
    private var serviceId: String? = null
    private var user_id: String? = null
    private var service_name: String? = null
    private var edit_butn: Button? = null
    private var payment_cancle_butn: Button? = null
    private var edit_cancle_butn: Button? = null
    private var accept_butn: Button? = null
    private var accept_cancle_btn: Button? = null
    private var txt_securitydeposit_value: TextView? = null
    private var btn_book_now: Button? = null
    private var price: Int? = null
    private var request = BooknowRequest()
    private var serviceprovidername: String? = null
    private var rate_type: String? = null

    private var day: String? = null
    private var time: String? = null
    private var address: String? = null
    private var city: String? = null
    private var postal: String? = null
    private var datetime: String? = null
    private var convertedTime: String? = null
    private var payment_butn: Button? = null
    private var btn_confirm: Button? = null
    private var btn_return: Button? = null
    private var fromdate: Long? = null
    private var newtime: String? = null
    private var securityDeposite: String? = null
    private var btn_confirmUser: Button? = null
    private var confirm_damage_layout: LinearLayout? = null

    private var btn_damaged: Button? = null
    private var btn_confirmed_user: Button? = null
    private var btn_confirm_damage: Button? = null
    private var rent: Double? = null
    private var paid_amount:Double?= null
    private var btn_complete: Button? = null
    private var btn_confirm_status:Button?=null
    private var payment_price:Double?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_booking_details)

        initViews()
        getConvertedTime()
        socketConnection()
        socketTestConnection()
        getBookingDetails()


    }


    private fun initViews() {

        apiUtility = APIUtility(this@ProductBookingDetailsActivity)
        title = findViewById(R.id.title)
        transaction = intent.getStringExtra("transaction")
        serviceprovidername = intent.getStringExtra("serviceprovidername")
        txt_product_owner_text = findViewById(R.id.txt_product_owner_text)
        txt_productname = findViewById(R.id.txt_productname)
        btn_book_now = findViewById(R.id.btn_book_now)
        btn_book_now?.setOnClickListener(this)
        txt_from = findViewById(R.id.txt_from)
        txt_to = findViewById(R.id.txt_to)
        txt_address_place = findViewById(R.id.txt_address_place)
        isbuyer = intent.getStringExtra("isbuyer")
        cancle_edit_layout = findViewById(R.id.cancle_edit_layout)
        paymentcancle_layout = findViewById(R.id.paymentcancle_layout)
        accept_decline_layout = findViewById(R.id.accept_decline_layout)
        accept_btn = findViewById(R.id.accept_btn)
        decline_btn = findViewById(R.id.decline_btn)
        accept_btn?.setOnClickListener(this)
        decline_btn?.setOnClickListener(this)
        edit_butn = findViewById(R.id.edit_butn)
        edit_cancle_butn = findViewById(R.id.edit_cancle_butn)
        payment_cancle_butn = findViewById(R.id.payment_cancle_butn)
        accept_cancle_layout = findViewById(R.id.accept_cancle_layout)
        txt_securitydeposit_value = findViewById(R.id.txt_securitydeposit_value)
        txt_amount = findViewById(R.id.txt_amount)
        address_cardview = findViewById(R.id.address_cardview)
        txt_amount_value = findViewById(R.id.txt_amount_value)
        payment_butn = findViewById(R.id.payment_butn)
        payment_butn?.setOnClickListener(this)
        btn_confirm = findViewById(R.id.btn_confirm)
        btn_confirm?.setOnClickListener(this)
        btn_return = findViewById(R.id.btn_return)
        btn_return?.setOnClickListener(this)
        btn_handover = findViewById(R.id.btn_handover)
        btn_handover?.setOnClickListener(this)
        btn_damage = findViewById(R.id.btn_damage)
        btn_damage?.setOnClickListener(this)
        btn_confirmUser = findViewById(R.id.btn_confirmUser)
        btn_confirmUser?.setOnClickListener(this)
        confirm_damage_layout = findViewById(R.id.damage_confirm_layout)
        btn_damaged = findViewById(R.id.damage_butn)
        btn_confirmed_user = findViewById(R.id.confirm_butn_user)

        btn_confirm_status=findViewById(R.id.btn_confirm_status)
        btn_confirm_status?.setOnClickListener(this)


        btn_complete = findViewById(R.id.btn_complete)
        btn_complete?.setOnClickListener(this)

        btn_damaged?.setOnClickListener(this)
        btn_confirmed_user?.setOnClickListener(this)
        btn_confirm_damage = findViewById(R.id.btn_confirm_damage)

        btn_confirm_damage?.setOnClickListener(this)

        edit_butn?.setOnClickListener(this)
        edit_cancle_butn?.setOnClickListener(this)
        payment_cancle_butn?.setOnClickListener(this)

        service_name = intent.getStringExtra("service_name")
        transaction = intent.getStringExtra("transaction")
        service_type = intent.getStringExtra("service_type")
        serviceId = intent.getStringExtra("serviceId")
        user_id = intent.getStringExtra("user_id")
        securityDeposite = intent.getStringExtra("securityDeposite")
        rate_type = intent.getStringExtra("rate_type")

        Log.e("securi", securityDeposite);

        accept_butn = findViewById(R.id.accept_butn)
        accept_cancle_btn = findViewById(R.id.accept_cancle_btn)
        accept_butn?.setOnClickListener(this)
        accept_cancle_btn?.setOnClickListener(this)

        txt_securitydeposit_value?.setText(securityDeposite)


        back = findViewById(R.id.back)
        back?.setOnClickListener(this)

        status = intent.getStringExtra("status")



        txt_product_owner_text?.setFocusable(false)
        txt_product_owner_text?.setFocusableInTouchMode(false)
        txt_product_owner_text?.setClickable(false)

        txt_productname?.setFocusable(false)
        txt_productname?.setFocusableInTouchMode(false)
        txt_productname?.setClickable(false)

        txt_address_place?.setFocusable(false)
        txt_address_place?.setFocusableInTouchMode(false)
        txt_address_place?.setClickable(false)

        txt_to?.setFocusable(false)
        txt_to?.setFocusableInTouchMode(false)
        txt_to?.setClickable(false)

        txt_from?.setFocusable(false)
        txt_from?.setFocusableInTouchMode(false)
        txt_from?.setClickable(false)

        txt_amount_value?.setFocusable(false)
        txt_amount_value?.setFocusableInTouchMode(false)
        txt_amount_value?.setClickable(false)


        if (isbuyer.equals("true")) {

            if (status.equals("1")) {

                cancle_edit_layout?.visibility = View.VISIBLE
            } else if (status.equals("2")) {

                paymentcancle_layout?.visibility = View.VISIBLE

            } else if (status.equals("3")) {

                cancle_edit_layout?.visibility = View.VISIBLE

            } else if (status.equals("4")) {
                btn_handover?.visibility = View.VISIBLE

            } else if (status.equals("7")) {

                btn_confirmUser?.visibility = View.VISIBLE

            } else if (status.equals("8")) {

                btn_confirm?.visibility = View.VISIBLE

            } else if (status.equals("10")) {

               btn_confirm_damage?.visibility = View.VISIBLE





            } else if (status.equals("12")) {

                btn_confirm_status?.visibility=View.VISIBLE




            } else if (status.equals("11")) {
                btn_confirm_damage?.visibility = View.VISIBLE


            }


        } else {
            if (status.equals("1")) {

                accept_decline_layout?.visibility = View.VISIBLE

            } else if (status.equals("2")) {

                accept_cancle_layout?.visibility = View.VISIBLE
                //accept_butn?.setBackgroundColor(getResources().getColor(R.color.garycolor));
                accept_butn?.setBackgroundDrawable(ContextCompat.getDrawable(this@ProductBookingDetailsActivity, R.drawable.grey_butn_corner))
            } else if (status.equals("3")) {

                accept_cancle_layout?.visibility = View.VISIBLE
                // accept_butn?.setBackgroundColor(getResources().getColor(R.color.garycolor));
                accept_butn?.setBackgroundDrawable(ContextCompat.getDrawable(this@ProductBookingDetailsActivity, R.drawable.grey_butn_corner))


            } else if (status.equals("4")) {
                btn_handover?.visibility = View.VISIBLE

            } else if (status.equals("9")) {

                confirm_damage_layout?.visibility = View.VISIBLE


            }

            else if (status.equals("12")) {

                btn_complete?.visibility = View.VISIBLE

            }
        }


    }

    fun getConvertedTime() {

        var currentTime = Calendar.getInstance().getTime()

        var dateFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")

        dateFormatter.setTimeZone(TimeZone.getDefault())
        currenttime = dateFormatter.format(currentTime)


    }


    fun getAcceptStatus() {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)
        request.transaction_id = transaction;
        request.status = "2"
        request.price = price.toString()


        apiUtility?.getAcceptDecline(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", "2")
                    jsonObject1.put("price", price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })
    }


    fun getDeclineStatus(status: String) {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)
        request.transaction_id = transaction;
        request.status = status

        apiUtility?.getAcceptDecline(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price", price.toString())


                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

                finish()


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })


    }

    fun socketConnection() {

        try {
            mSocket = IO.socket(socket_url)


        } catch (e: URISyntaxException) {

        }

        mSocket!!.connect()




        mSocket!!.on("connected") {

        }



        mSocket!!.on("socket") { args ->

            // `object` = args[0] as Any


        }

    }


    private fun socketTestConnection() {


        val jsonObject: JSONObject = JSONObject()

        jsonObject?.put("room", transaction)
        jsonObject?.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))

        mSocket?.emit("test", jsonObject)


        mSocket?.on("test") { args ->

            val data = args[0] as JSONObject


        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        mSocket?.disconnect()
        mSocket?.close()
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.back -> {

                finish()
                mSocket?.disconnect()
                mSocket?.close()
            }
            R.id.accept_btn -> {

                getAcceptStatus()
            }
            R.id.decline_btn -> {

                getDeclineStatus("6")
            }
            R.id.payment_cancle_butn -> {
                getDeclineStatus("5")


            }
            R.id.edit_cancle_butn -> {
                getDeclineStatus("5")


            }
            R.id.btn_handover -> {
                getConfirmed("7", "")


            }
            R.id.btn_confirmUser -> {

                getConfirmed("9", "")


            }

            R.id.btn_confirm_damage -> {
                damageProduct_confirm("12", rent!!)


            }

            R.id.btn_confirm_status->{




            }

            //damage confirm
            R.id.confirm_butn_user -> {

                damageProduct("11", 0.0)


            }
            // damage
            R.id.damage_butn -> {

                val dialog = Dialog(this)
                dialog.setContentView(R.layout.damage_product)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

                dialog.show()

                val imageView = dialog.findViewById<ImageView>(R.id.cancle_image)
                val edt_price = dialog.findViewById<EditText>(R.id.edit_price)


                val submit = dialog.findViewById<Button>(R.id.submit)

                submit.setOnClickListener(object : View.OnClickListener {
                    override fun onClick(v: View?) {
                        val price: String = edt_price.text.toString()

                        damageProduct("10", price.toDouble())

                    }

                })


            }

            R.id.btn_complete -> {
                getConfirmed("14", "")


            }


            R.id.payment_butn -> {

                checkpayment()


            }
            R.id.edit_butn -> {


                txt_address_place?.setClickable(true)

                txt_from?.setClickable(true)

                txt_to?.setClickable(true)

                txt_amount_value?.setFocusable(true)
                txt_amount_value?.setFocusableInTouchMode(true)
                txt_amount_value?.setClickable(true)
                txt_amount_value?.isCursorVisible = true

                accept_decline_layout?.visibility = View.GONE
                accept_cancle_btn?.visibility = View.GONE
                paymentcancle_layout?.visibility = View.GONE
                btn_book_now?.visibility = View.VISIBLE
                cancle_edit_layout?.visibility = View.GONE

                address_cardview?.setOnClickListener(this)
                txt_from?.setOnClickListener(this)
                txt_to?.setOnClickListener(this)


            }

            R.id.address_cardview -> {

                val intent = Intent(this@ProductBookingDetailsActivity, SelectLocationManually::class.java)
                intent.putExtra("requestFrom", "FILTER")

                startActivityForResult(intent, Constants.REQUESTCODE_1)


            }


            R.id.txt_from -> {

                val c = Calendar.getInstance()
                mYear = c.get(Calendar.YEAR)
                mMonth = c.get(Calendar.MONTH)
                mDay = c.get(Calendar.DAY_OF_MONTH)


                val datePickerDialog = DatePickerDialog(this,
                        DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                            val datenew: String = "" + year + "-" + String.format("%02d", (monthOfYear + 1)) + "-" + String.format("%02d", dayOfMonth)
                            getConvertedTime(datenew)
                            day = datetime


                            var formatter = SimpleDateFormat("yyyy-MM-dd");
                            var date = formatter!!.parse(datenew)
                            fromdate = date.time


                            txt_from!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                        }, mYear, mMonth, mDay)
                datePickerDialog.show()
                datePickerDialog.getDatePicker().minDate = System.currentTimeMillis() - 1000


            }

            R.id.txt_to -> {

                if (!txt_from?.text.toString().equals("")!!) {


                    val c = Calendar.getInstance()
                    mYear = c.get(Calendar.YEAR)
                    mMonth = c.get(Calendar.MONTH)
                    mDay = c.get(Calendar.DAY_OF_MONTH)


                    val datePickerDialog = DatePickerDialog(this,
                            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                                val datenew: String = "" + year + "-" + String.format("%02d", (monthOfYear + 1)) + "-" + String.format("%02d", dayOfMonth)
                                getConvertedTime(datenew)
                                time = datetime


                                txt_to!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                            }, mYear, mMonth, mDay)
                    datePickerDialog.show()
                    // datePickerDialog.datePicker.minDate=System.currentTimeMillis()-1000

                    datePickerDialog.getDatePicker().minDate = fromdate!!
                } else {

                    Toast.makeText(applicationContext, "Please Select from date", Toast.LENGTH_SHORT).show()
                }


            }
            R.id.accept_butn -> {
                getAcceptStatus()


            }
            R.id.accept_cancle_btn -> {
                getDeclineStatus("6")


            }

            R.id.back -> {
                finish()


            }


            R.id.btn_book_now -> {

                if (TextUtils.isEmpty(txt_product_owner_text?.text.toString()) || TextUtils.isEmpty(txt_productname?.text.toString()) || TextUtils.isEmpty(txt_from?.text.toString()) || TextUtils.isEmpty(txt_to?.text.toString())
                        || TextUtils.isEmpty(txt_amount_value?.text.toString()) || TextUtils.isEmpty(txt_address_place?.text.toString())) {
                    CommonUtils.AlertDialogDefault(this@ProductBookingDetailsActivity, "", "Enter all fields")


                } else {
                    Booknow()
                }


            }

        }


    }

    fun getConfirmed(status: String, amount: String) {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)
        request.transaction_id = transaction;
        request.status = status
        request.price = price.toString()


        apiUtility?.getAcceptDecline(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price", price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })


    }




    fun damageProduct_confirm(status: String, price: Double) {


        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)
        request.transaction_id = transaction
        request.status = status
        request.damage_Amount = price
        var gson = Gson()


        apiUtility?.getAcceptDecline(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                rent=response?.response!!.rent.rent

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price",price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })


    }




    fun damageProduct(status: String, price: Double) {


        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)
        request.transaction_id = transaction
        request.status = status
        request.damage_Amount = price
        var gson = Gson()


        apiUtility?.getAcceptDecline(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                rent=response?.response?.rent?.rent

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price",price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })


    }

    fun getConvertedTimeReverse(strDate: String) {

        try {

            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("dd-MM-yyyy");
            convertedTime = targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }

    fun getConvertedTime(strDate: String) {

        try {
            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            datetime = targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }

    fun Booknow() {

        request.buyer_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)
        request.from = day
        request.price = txt_amount_value?.text.toString()
        request.service_id = serviceId
        request.service_provider_id = user_id
        request.rate_type = rate_type

        request.to = time
        request.security_deposite = securityDeposite



        request.transaction_id = transaction
        request.service_type = service_type


        var gson = Gson()

        apiUtility?.getBookNow(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<BookNowWrapper> {


            override fun onReceiveResponse(response: BookNowWrapper?) {

                price = response?.response?.getBooknowresult?.price

                var status_code = response?.response?.getBooknowresult?.status
                status = status_code.toString()

                Toast.makeText(this@ProductBookingDetailsActivity, "Booking Updated", Toast.LENGTH_SHORT).show()

                intent.putExtra("price", price)
                intent.putExtra("status", status)

                setResult(Activity.RESULT_OK, intent)
                finish()


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price", price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {
            }

            override fun onStatusFalse(response: BookNowWrapper?) {
            }

        })


    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1003) {


            if (resultCode == Activity.RESULT_OK) {

                finish()

            }
        }

        if (requestCode == 1999) {
            if (resultCode == PaymentMethodHandler.RESULT_CODE_OK) {

                var paymentResult = PaymentMethodHandler.Util.getPaymentResult(data)

                paymentSucess(paymentResult?.payload!!)

                // Handle PaymentResult.
            } else {
                var checkoutException = PaymentMethodHandler.Util.getCheckoutException(data)


                if (resultCode == PaymentMethodHandler.RESULT_CODE_CANCELED) {
                    // Handle cancellation and optional CheckoutException.
                } else {
                    // Handle CheckoutException.
                }
            }
        }




        if (requestCode == Constants.REQUESTCODE_1) {

            if (resultCode == Activity.RESULT_OK) {
                address = data!!.getStringExtra("fullAdress")

                postal = data?.getStringExtra("postal")
                city = data?.getStringExtra("city")

                Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                val Address = address
                txt_address_place!!.setText(address)

                request.longtitude = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.LONG)
                request.lat = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.LAT)
                if (postal != null) {
                    request.pincode = postal

                } else {
                    request.pincode = "201303"

                }

                request.city = city
                request.fullAddress = address
            }

        }


    }

    fun getBookingDetails() {


        var request = ShowBookingRequest()

        request.transaction_id = transaction
        request.user_id = Preferences.getPreference(this, PrefEntity.USERID)
        var gson = Gson()

        apiUtility?.showBooking(this@ProductBookingDetailsActivity, request, true, object : APIUtility.APIResponseListener<ShowBookingWrapper> {
            override fun onReceiveResponse(response: ShowBookingWrapper?) {


                txt_product_owner_text?.setText(response?.response?.getBookingresult?.booking?.service_provider_name)

                txt_productname?.setText(response?.response?.getBookingresult?.booking?.service_name)
                title?.text = response?.response?.getBookingresult?.booking?.service_name

                paid_amount=response?.response?.getBookingresult?.booking?.paid_amount

                Log.e("paidamount",""+paid_amount)

                rent=response?.response?.getBookingresult?.booking?.rent


                var jsonResponse = Gson().toJson(response?.response?.getBookingresult?.booking)
                var jsonObject = JSONObject(jsonResponse)


                if (jsonObject.has("from")) {
                    var from = response?.response?.getBookingresult?.booking?.from
                    getConvertedTimeReverse(from!!)
                    txt_from?.setText(convertedTime)


                    try {

                        val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("dd-MM-yyyy");

                        val date: Date = sourceDateFormat.parse(convertedTime)

                        val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");
                        newtime = targetDateFormat.format(date)

                    } catch (e: ParseException) {
                        e.printStackTrace();
                    }


                    var formatter = SimpleDateFormat("yyyy-MM-dd")
                    var date = formatter!!.parse(newtime)
                    fromdate = date.time


                }
                if (jsonObject.has("to")) {
                    var to = response?.response?.getBookingresult?.booking?.to
                    getConvertedTimeReverse(to!!)
                    txt_to?.setText(convertedTime)

                }


                txt_amount_value?.setText(response?.response!!.getBookingresult?.booking!!.price.toString())
                price = response?.response!!.getBookingresult?.booking!!.price

                txt_address_place?.setText(response?.response?.getBookingresult?.booking?.address?.fullAddress)

                txt_securitydeposit_value?.setText(response?.response?.getBookingresult?.booking?.security_deposit)



                txt_address_place?.setText(response?.response?.getBookingresult?.booking?.address?.fullAddress)
            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: ShowBookingWrapper?) {

            }

        })
    }


    fun paymentSucess(payload: String) {
        var payment = Payment()
        payment.payload = payload
        payment.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)



        apiUtility?.displayAllPayment(this@ProductBookingDetailsActivity, payment, true, object : APIUtility.APIResponseListener<PaymentWrapperValue> {
            override fun onReceiveResponse(response: PaymentWrapperValue?) {
                var gson = Gson()

                updateStatus()


            }

            override fun onResponseFailed() {
                Log.e("error", "error")

            }

            override fun onStatusFalse(response: PaymentWrapperValue?) {

            }


        })

    }


    fun updateStatus() {


        var acceptDeclineRequest = AcceptDeclineRequest()
        acceptDeclineRequest.status = "4"
        acceptDeclineRequest.transaction_id = transaction
        acceptDeclineRequest.user_id = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)




        apiUtility?.getAcceptDecline(this@ProductBookingDetailsActivity, acceptDeclineRequest, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", "4")
                    jsonObject1.put("price", price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()
                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }


            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }

        })


    }


    fun checkpayment() {

        CheckoutController.startPayment(this, object : CheckoutSetupParametersHandler {
            override fun onRequestPaymentSession(checkoutSetupParameters: CheckoutSetupParameters) {


                var date = Date(System.currentTimeMillis() + 120000)
                var sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                sdf.setTimeZone(TimeZone.getTimeZone("CET"))
                var timestamp = sdf.format(date)

                var paid:Double?=null
                paid=paid_amount!!+securityDeposite!!.toDouble()


                var paymentRequest = PaymentRequest()
                paymentRequest.am.currency = "USD"
                paymentRequest.am.value = paid
                paymentRequest.channel = "Android"
                paymentRequest.countryCode = "US"
                paymentRequest.reference = transaction
                paymentRequest.returnUrl = checkoutSetupParameters.returnUrl

                paymentRequest.shopperLocale = "en_US"


                paymentRequest.token = checkoutSetupParameters.sdkToken
                paymentRequest.merchantAccount = "RhentuLLCCOM122"


                paymentRequest.enableOneClick = true
                paymentRequest.enableRecurring = true
                paymentRequest.origin = "https://www.yourwebsite.com"


                paymentRequest.shopperReference = Preferences.getPreference(this@ProductBookingDetailsActivity, PrefEntity.USERID)



                //paymentRequest.shopperReference=transaction


                apiUtility?.displayAllPaymentSession(this@ProductBookingDetailsActivity, paymentRequest, true, object : APIUtility.APIResponseListener<PaymentWrapper> {
                    override fun onReceiveResponse(response: PaymentWrapper?) {
                        var gson = Gson()
                        var encodedSessiion = response?.response?.getPaymentResult?.paymentSession

                        PaymentController.handlePaymentSessionResponse(this@ProductBookingDetailsActivity, encodedSessiion!!, object : StartPaymentParametersHandler {
                            override fun onPaymentInitialized(startPaymentParameters: StartPaymentParameters) {


                                val paymentMethodHandler = CheckoutController.getCheckoutHandler(startPaymentParameters)
                                paymentMethodHandler.handlePaymentMethodDetails(this@ProductBookingDetailsActivity, 1999)

                            }

                            override fun onError(checkoutException: CheckoutException) {

                            }
                        })


                    }

                    override fun onResponseFailed() {

                    }

                    override fun onStatusFalse(response: PaymentWrapper?) {

                    }

                })

            }

            override fun onError(checkoutException: CheckoutException) {
                Log.e("error", checkoutException.payload + " " + checkoutException.message)
            }
        })


    }

}
