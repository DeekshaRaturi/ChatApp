package com.ripenapps.rehntu.models.VerifieMobile.RESPONSE;

public class VerifieMobileResult {
}
