package com.ripenapps.rehntu.models.map.response;

import com.google.gson.annotations.SerializedName;

public class MapResponseWrapper {

    @SerializedName("data")
    private MapResponse response;


    public MapResponse getResponse() {
        return response;
    }

    public void setResponse(MapResponse response) {
        this.response = response;
    }
}
