package com.ripenapps.rehntu.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.map.reguest.MapRequest;
import com.ripenapps.rehntu.models.map.response.MapResponse;
import com.ripenapps.rehntu.models.map.response.MapResponseResult;
import com.ripenapps.rehntu.models.map.response.MapResponseWrapper;
import com.ripenapps.rehntu.models.map.response.Service;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;


public class HomeFragment extends Fragment implements View.OnClickListener {

    private View view;
    private EditText search;
    APIUtility apiUtility;
    private ImageView fab;
    boolean ismap = true;
    public Context context;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);
        apiUtility = new APIUtility(getActivity());
        this.context = getActivity();
        initViews();
        return view;
    }

    private void initViews() {
        search = (EditText) view.findViewById(R.id.et_search);
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == EditorInfo.IME_ACTION_DONE) {
                    getData(search.getText().toString().trim());
                }
                return false;
            }
        });

        fab = (ImageView) view.findViewById(R.id.fab);
        fab.setOnClickListener(this);
        FragmentManager fragmentManager = getChildFragmentManager();
        android.support.v4.app.FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.container, new MapFragment());
        transaction.commit();
        ismap = true;
        getData("");
    }

    @Override
    public void onClick(View v) {
        if (ismap) {
            fab.setImageResource(R.drawable.map);
            ismap = false;
            FragmentManager fragmentManager = getChildFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.container, new ListFragment());
            transaction.commit();
        } else {
            ismap = true;
            fab.setImageResource(R.drawable.listing);
            FragmentManager fragmentManager = getChildFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.container, new MapFragment());
            transaction.commit();
        }

    }

    void getData(String text) {
        final MapRequest serviceRequestPojo;
        if (!Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.ISFILTER).equals("1")) {
            serviceRequestPojo = new MapRequest();
            if (text != null) {
                serviceRequestPojo.setText(text);

            } else {
                serviceRequestPojo.setText("");
            }


            if (Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM1).equals("service") && Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM2).equals("product")) {
                serviceRequestPojo.setServicesType(" ");


            } else if (Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM1).equals("") && Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM2).equals("")) {
                serviceRequestPojo.setServicesType(" ");


            } else if (Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM1).equals("") && Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM2).equals("product")) {
                serviceRequestPojo.setServicesType("product");

            } else if (Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM1).equals("service") && Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.COMEFROM2).equals("")) {

                serviceRequestPojo.setServicesType("service");

            }

            serviceRequestPojo.setLat(Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.LAT));
            serviceRequestPojo.setLng(Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.LONG));
            serviceRequestPojo.setMaxMile(200.0f);
            serviceRequestPojo.setMaxPrice(5000.0f);
            serviceRequestPojo.setMinPrice(0.0f);
            serviceRequestPojo.setRating(0);
            serviceRequestPojo.setUserId(Preferences.getPreference(getActivity(), PrefEntity.USERID));
            serviceRequestPojo.setMinMile(0.0f);
            serviceRequestPojo.setPage_size(150);
            serviceRequestPojo.setPage_number(1);

        } else {
            serviceRequestPojo = RhentoSingleton.getInstance().getMapRequest();
            Preferences.removePreference(getActivity(), PrefEntity.ISFILTER);

        }
        new APIUtility(getActivity()).getPinsData(getActivity(), serviceRequestPojo, true, new APIUtility.APIResponseListener<MapResponseWrapper>() {
            @Override
            public void onReceiveResponse(MapResponseWrapper response) {
                if (response != null) {
                    Log.e("size",""+response.getResponse().getResult().getServiceArrayList().size()+"   "+Preferences.getPreference(context, PrefEntity.COMEFROM1));


                    if (Preferences.getPreference(context, PrefEntity.COMEFROM1).equals("product")) {
                        if (response.getResponse().getResult().getServiceArrayList().size() > 0) {
                            RhentoSingleton.getInstance().setResponseResult(response.getResponse().getResult());
                        } else {
                            RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().clear();
                            RhentoSingleton.getInstance().getResponseResult().getProductArrayList().clear();
                            CommonUtils.alert(context, "No Product has matched with your search criteria." + "Please Expand your Horizon and Search again.");
                        }
                    }
                    else if (Preferences.getPreference(context, PrefEntity.COMEFROM1).equals("service")) {

                        if (response.getResponse().getResult().getServiceArrayList().size() > 0) {
                            RhentoSingleton.getInstance().setResponseResult(response.getResponse().getResult());

                        } else {
                            RhentoSingleton.getInstance().getResponseResult().getProductArrayList().clear();
                            RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().clear();
                            CommonUtils.alert(context, "No Service has matched with your search criteria." + "Please Expand your Horizon and Search again.");
                        }
                    } else {
                        if ((response.getResponse().getResult().getServiceArrayList().size() <= 0)) {
                            RhentoSingleton.getInstance().getResponseResult().getProductArrayList().clear();
                            RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().clear();
                            RhentoSingleton.getInstance().setResponseResult(response.getResponse().getResult());

                            Log.e("novalue", "found");
                            CommonUtils.alert(context, "No Product and Service has matched with your search criteria." + "Please Expand your Horizon and Search again.");


                        }
                        else {
                            RhentoSingleton.getInstance().setResponseResult(response.getResponse().getResult());


                        }

                    }


                    if (isAdded()) {
                        try {
                            if (ismap) {
                                fab.setImageResource(R.drawable.listing);
                                android.support.v4.app.FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
                                transaction.replace(R.id.container, new MapFragment());
                                transaction.commit();
                            } else {
                                fab.setImageResource(R.drawable.map);
                                android.support.v4.app.FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
                                transaction.replace(R.id.container, new ListFragment());
                                transaction.commit();
                            }
                        } catch (Exception e) {

                        }
                    }
                }
            }

            @Override
            public void onResponseFailed() {
                RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().clear();
                RhentoSingleton.getInstance().getResponseResult().getProductArrayList().clear();


            }

            @Override
            public void onStatusFalse(MapResponseWrapper response) {
                RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().clear();
                RhentoSingleton.getInstance().getResponseResult().getProductArrayList().clear();

            }
        });
    }



   /* private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }
*/

}
