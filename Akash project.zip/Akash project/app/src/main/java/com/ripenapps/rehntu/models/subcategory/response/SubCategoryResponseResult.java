package com.ripenapps.rehntu.models.subcategory.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class SubCategoryResponseResult {
    @SerializedName("subcategory")
    List<SubCategory> subCategoryList = new ArrayList<>();

    public List<SubCategory> getSubCategoryList() {
        return subCategoryList;
    }

    public void setSubCategoryList(List<SubCategory> subCategoryList) {
        this.subCategoryList = subCategoryList;
    }
}
