package com.ripenapps.rehntu.my_screen;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.map.reguest.MapRequest;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;

import org.florescu.android.rangeseekbar.RangeSeekBar;

import java.util.ArrayList;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class MapFilterActivity extends AppCompatActivity implements View.OnClickListener {
    ArrayList<String> subcategoryList = new ArrayList<String>();
    ArrayList<String> subcategoryIdList = new ArrayList<String>();
    String strSubCategory;
    private ImageView imageViewCross;
    private Button buttonProduct, buttonService, Apply;
    private String serviceType = "";
    Number tMaxMile = 100;
    Number setMaxPrice = 1000;
    Number setMinPrice = 0;
    int setRating = 0;
    Number setMinMile = 0;
    String CategoryID;
    String serviceTyp;
    TextView filter;
    boolean isServiceSelected = false;
    boolean isProductSelected = false;

    private CardView cardViewRating, cardViewLocation, cvCategory, cvSubcategory;
    private LinearLayout linearLayoutRating;
    private boolean isRatingLayoutOpen = false;
    private TextView textViewClearFilter, tvCategory, tvSubcategory, tvRating, tprice, tmile;
    private LinearLayout linearLayout2Rating, linearLayout3Rating, linearLayout4Rating, linearLayout5Rating;
    private TextView textViewLocation, textView2Rating, textView2RatingLabel, textView3Rating, textView3RatingLabel, textView4Rating, textView4RatingLabel, textView5Rating, textView5RatingLabel;
    private RangeSeekBar rangeSeekBar, rangeSeekBar1;
    private String Address = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_filter);
        rangeSeekBar = (RangeSeekBar) findViewById(R.id.mile);
        rangeSeekBar1 = (RangeSeekBar) findViewById(R.id.price);
        rangeSeekBar.setRangeValues(0, 200);
        rangeSeekBar1.setRangeValues(10, 5000);
        tMaxMile = rangeSeekBar.getSelectedMaxValue();
        setMinMile = rangeSeekBar.getSelectedMinValue();
        setMaxPrice = rangeSeekBar1.getSelectedMaxValue();
        setMinPrice = rangeSeekBar1.getSelectedMinValue();
        tprice = findViewById(R.id.pricetext);
        tmile = findViewById(R.id.milestext);
        tvRating = findViewById(R.id.tv_rating);
        tvCategory = findViewById(R.id.tv_category);
        tvSubcategory = findViewById(R.id.tv_subcategory);
        cvCategory = (CardView) findViewById(R.id.cv_category);
        cvSubcategory = (CardView) findViewById(R.id.cv_sub_category);
        Apply = (Button) findViewById(R.id.btn_book_now);
        Apply.setOnClickListener(this);
        cvSubcategory.setOnClickListener(this);
        cvCategory.setOnClickListener(this);
        buttonProduct = findViewById(R.id.btn_product);
        buttonProduct.setOnClickListener(this);
        buttonService = findViewById(R.id.btnn_service);
        buttonService.setOnClickListener(this);

        imageViewCross = findViewById(R.id.iv_filter);
        imageViewCross.setImageDrawable(getResources().getDrawable(R.mipmap.close));
        imageViewCross.setOnClickListener(this);

        textViewClearFilter = findViewById(R.id.tv_clear);
        textViewClearFilter.setVisibility(View.VISIBLE);
        textViewClearFilter.setOnClickListener(this);

        linearLayoutRating = findViewById(R.id.ll_rating);
        cardViewRating = findViewById(R.id.cv_rating);
        cardViewRating.setOnClickListener(this);

        linearLayout2Rating = findViewById(R.id.ll_rating_2);
        linearLayout2Rating.setOnClickListener(this);

        linearLayout3Rating = findViewById(R.id.ll_rating_3);
        linearLayout3Rating.setOnClickListener(this);

        linearLayout4Rating = findViewById(R.id.ll_rating_4);
        linearLayout4Rating.setOnClickListener(this);

        linearLayout5Rating = findViewById(R.id.ll_rating_5);
        linearLayout5Rating.setOnClickListener(this);

        textView2Rating = findViewById(R.id.tv_2);
        textView2RatingLabel = findViewById(R.id.label_2);

        textView3Rating = findViewById(R.id.tv_3);
        textView3RatingLabel = findViewById(R.id.label_3);

        textView4Rating = findViewById(R.id.tv_4);
        textView4RatingLabel = findViewById(R.id.label_4);

        textView5Rating = findViewById(R.id.tv_5);
        textView5RatingLabel = findViewById(R.id.label_5);

        cardViewLocation = findViewById(R.id.cv_location);
        cardViewLocation.setOnClickListener(this);

        textViewLocation = findViewById(R.id.tv_location);
//        resetButton();
        setText();
    }

    private void setText() {
        if (!RhentoSingleton.getInstance().getMapRequest().getCategoryId().equals("")) {
            tvCategory.setText("" + Preferences.getPreference(this, PrefEntity.CATEGORY));
        }
        if (RhentoSingleton.getInstance().getMapRequest().getSubcategoryId().size() > 0) {

        }


        textViewLocation.setText(Preferences.getPreference(getApplicationContext(), PrefEntity.ADDRESS));


        if (RhentoSingleton.getInstance().getMapRequest().getMaxMile() != null) {
            rangeSeekBar.setSelectedMaxValue(RhentoSingleton.getInstance().getMapRequest().getMaxMile());
            rangeSeekBar.setSelectedMinValue(RhentoSingleton.getInstance().getMapRequest().getMinMile());
            tmile.setText(String.valueOf(RhentoSingleton.getInstance().getMapRequest().getMinMile()) + " to " + String.valueOf(RhentoSingleton.getInstance().getMapRequest().getMaxMile()));
            tMaxMile = RhentoSingleton.getInstance().getMapRequest().getMaxMile();
            setMinMile = RhentoSingleton.getInstance().getMapRequest().getMinMile();


        }

        if (RhentoSingleton.getInstance().getMapRequest().getMaxPrice() != null) {
            tprice.setText(String.valueOf(RhentoSingleton.getInstance().getMapRequest().getMinPrice()) + " to " + String.valueOf(RhentoSingleton.getInstance().getMapRequest().getMaxPrice()));
            rangeSeekBar1.setSelectedMaxValue(RhentoSingleton.getInstance().getMapRequest().getMaxPrice());
            rangeSeekBar1.setSelectedMinValue(RhentoSingleton.getInstance().getMapRequest().getMinPrice());
            setMaxPrice = RhentoSingleton.getInstance().getMapRequest().getMaxPrice();
            setMinPrice = RhentoSingleton.getInstance().getMapRequest().getMinPrice();
        }

        if (RhentoSingleton.getInstance().getMapRequest().getRating() != 0) {
            tvRating.setText(String.valueOf(RhentoSingleton.getInstance().getMapRequest().getRating()));
        }

        if (Preferences.getPreference(getApplicationContext(), PrefEntity.COMEFROM2).equals("product")) {
            buttonProduct.setBackgroundResource(R.drawable.tab_right_select);
            buttonProduct.setTextColor(getResources().getColor(R.color.colorWhite));
            isProductSelected=true;
        } else {

            buttonProduct.setBackgroundResource(R.drawable.tab_right_unselect);
            buttonProduct.setTextColor(getResources().getColor(R.color.black));
            isProductSelected=false;
        }

        if(Preferences.getPreference(getApplicationContext(), PrefEntity.COMEFROM1).equals("service"))
        {
            buttonService.setBackgroundResource(R.drawable.tab_left_select);
            buttonService.setTextColor(getResources().getColor(R.color.colorWhite));
            isServiceSelected=true;
        }else{
            buttonService.setBackgroundResource(R.drawable.tab_left_unselect);
            buttonService.setTextColor(getResources().getColor(R.color.black));
            isServiceSelected=false;
        }

        rangeSeekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener() {
            @Override
            public void onRangeSeekBarValuesChanged(RangeSeekBar rangeSeekBar, Object minValue, Object maxValue) {
                tMaxMile = rangeSeekBar.getSelectedMaxValue();
                setMinMile = rangeSeekBar.getSelectedMinValue();
                tmile.setText(String.valueOf(setMinMile) + " to " + String.valueOf(tMaxMile));

            }
        });

        rangeSeekBar1.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener() {
            @Override
            public void onRangeSeekBarValuesChanged(RangeSeekBar rangeSeekBar1, Object minValue, Object maxValue) {

                setMaxPrice = rangeSeekBar1.getSelectedMaxValue();
                setMinPrice = rangeSeekBar1.getSelectedMinValue();

                tprice.setText(String.valueOf(setMinPrice) + " to " + String.valueOf(setMaxPrice));
            }
        });


    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_filter:
                finish();
                break;
            case R.id.btn_product:

                resetButton1();
                break;
            case R.id.btnn_service:
                resetButton();
                break;
            case R.id.cv_rating:
                ratingLayoutShowHide();
                break;
            case R.id.tv_clear:
                showDialog();
               /* filter("");
                Preferences.removePreference(getApplicationContext(), PrefEntity.ISFILTER);
                Preferences.removePreference(getApplicationContext(), PrefEntity.COMEFROM1);
                Intent intent11 = new Intent(this, DashBoardActivity.class);
                intent11.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent11);
                finish();*/
                break;
            case R.id.ll_rating_2:
                tvRating.setText("2");
                resetRating();
                textView2Rating.setTextColor(getResources().getColor(R.color.colorAccent));
                textView2RatingLabel.setTextColor(getResources().getColor(R.color.colorAccent));
                break;
            case R.id.ll_rating_3:
                tvRating.setText("3");
                resetRating();
                textView3Rating.setTextColor(getResources().getColor(R.color.colorAccent));
                textView3RatingLabel.setTextColor(getResources().getColor(R.color.colorAccent));
                break;
            case R.id.ll_rating_4:
                tvRating.setText("4");
                resetRating();
                textView4Rating.setTextColor(getResources().getColor(R.color.colorAccent));
                textView4RatingLabel.setTextColor(getResources().getColor(R.color.colorAccent));
                break;
            case R.id.ll_rating_5:
                tvRating.setText("5");
                resetRating();
                textView5Rating.setTextColor(getResources().getColor(R.color.colorAccent));
                textView5RatingLabel.setTextColor(getResources().getColor(R.color.colorAccent));
                break;
            case R.id.cv_location:
                final Intent intent = new Intent(MapFilterActivity.this, SelectLocationManually.class);
                intent.putExtra("requestFrom", "FILTER");
                startActivityForResult(intent, 9001);
                break;

            case R.id.cv_category:
                final Intent intent1 = new Intent(MapFilterActivity.this, CategoryListActivity.class);
                intent1.putExtra("requestFrom", "FILTER");
                if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("service")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals("product"))
                {
                    intent1.putExtra("service"," ");
                }else if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals(""))
                {
                    intent1.putExtra("service"," ");
                }else if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals("product"))
                {
                    intent1.putExtra("service","product");
                }else if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("service")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals(""))
                {
                    intent1.putExtra("service","service");
                }

                startActivityForResult(intent1, 9002);
                break;

            case R.id.cv_sub_category:
                if (tvCategory.getText().toString().trim().equals("")) {
                    CommonUtils.alert(MapFilterActivity.this, "Please select a category");
                } else {
                    final Intent intent2 = new Intent(MapFilterActivity.this, SubCategoryListActivity.class);
                    intent2.putExtra("requestFrom", "FILTER");
                    intent2.putExtra("serviceType",serviceTyp);
                    startActivityForResult(intent2, 9003);
                }
                break;


            case R.id.btn_book_now:

                if (tvRating.getText().toString().trim() != null && !tvRating.getText().toString().trim().equals(""))
                    setRating = Integer.parseInt(tvRating.getText().toString().trim());
                else {
                    setRating = 0;
                }

                if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("service")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals("product"))
                {
                    SetFilterData("", "", tMaxMile, setMaxPrice, setMinPrice, setRating, setMinMile);

                }else if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals(""))
                {
                    SetFilterData("", "", tMaxMile, setMaxPrice, setMinPrice, setRating, setMinMile);

                }else if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals("product"))
                {
                    SetFilterData("", "product", tMaxMile, setMaxPrice, setMinPrice, setRating, setMinMile);

                }else if(Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM1).equals("service")&& Preferences.getPreference(getApplicationContext(),PrefEntity.COMEFROM2).equals(""))
                {
                    SetFilterData("", "service", tMaxMile, setMaxPrice, setMinPrice, setRating, setMinMile);

                }
                final Intent intent3 = new Intent(MapFilterActivity.this, DashBoardActivity.class);
                intent3.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Preferences.setPreference(getApplicationContext(), PrefEntity.ISFILTER, "1");
                startActivity(intent3);
                break;
        }
    }

    private void ratingLayoutShowHide() {
        if (isRatingLayoutOpen) {
            isRatingLayoutOpen = false;
            linearLayoutRating.setVisibility(View.GONE);
        } else {
            isRatingLayoutOpen = true;
            linearLayoutRating.setVisibility(View.VISIBLE);
        }

    }

    private void resetButton() {

        if (!isServiceSelected) {
            buttonService.setBackgroundResource(R.drawable.tab_left_select);
            buttonService.setTextColor(getResources().getColor(R.color.colorWhite));
            isServiceSelected = true;
            Preferences.setPreference(getApplicationContext(),PrefEntity.COMEFROM1,"service");

        } else {
            Preferences.removePreference(getApplicationContext(),PrefEntity.COMEFROM1);
            isServiceSelected = false;
            buttonService.setBackgroundResource(R.drawable.tab_left_unselect);
            buttonService.setTextColor(getResources().getColor(R.color.black));
        }
    }


   void resetButton1() {

        if (!isProductSelected) {
            Preferences.setPreference(getApplicationContext(),PrefEntity.COMEFROM2,"product");
            isProductSelected = true;
            buttonProduct.setTextColor(getResources().getColor(R.color.colorWhite));
            buttonProduct.setBackgroundResource(R.drawable.tab_right_select);

        } else {
            Preferences.removePreference(getApplicationContext(),PrefEntity.COMEFROM2);
            buttonProduct.setBackgroundResource(R.drawable.tab_right_unselect);
            buttonProduct.setTextColor(getResources().getColor(R.color.black));
            isProductSelected = false;
        }




   }




    private void resetRating() {
        textView2Rating.setTextColor(getResources().getColor(R.color.black));
        textView2RatingLabel.setTextColor(getResources().getColor(R.color.black));
        textView3Rating.setTextColor(getResources().getColor(R.color.black));
        textView3RatingLabel.setTextColor(getResources().getColor(R.color.black));
        textView4Rating.setTextColor(getResources().getColor(R.color.black));
        textView4RatingLabel.setTextColor(getResources().getColor(R.color.black));
        textView5Rating.setTextColor(getResources().getColor(R.color.black));
        textView5RatingLabel.setTextColor(getResources().getColor(R.color.black));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 9001) {
            if (resultCode == Activity.RESULT_OK) {
                String address = data.getStringExtra("fullAdress");
                Preferences.setPreference(getApplicationContext(), PrefEntity.ADDRESS, address);
                Address = address;
                textViewLocation.setText("" + address);
                String city=data.getStringExtra("city");
                String lat=data.getStringExtra("lat");
                String longitude=data.getStringExtra("lng");
                Log.e("lattu"," "+city+" "+lat+" "+longitude);


            } else {
            }
        }
        if (requestCode == 9002) {
            if (resultCode == Activity.RESULT_OK) {
                CategoryID = data.getStringExtra("cat_id");
                serviceTyp=data.getStringExtra("service_type");
                tvSubcategory.setText("");
                tvCategory.setText("" + Preferences.getPreference(this, PrefEntity.CATEGORY));

            }
        }

        if (requestCode == 9003) {
            if (resultCode == Activity.RESULT_OK) {
                if (data != null)
                    subcategoryList = data.getStringArrayListExtra("name");
                subcategoryIdList = data.getStringArrayListExtra("id");
                setSubCategoryList();

            }
        }
    }

    private void setSubCategoryList() {
        for (int i = 0; i < subcategoryList.size(); i++) {
            if (i == 0) {
                strSubCategory = subcategoryList.get(i);
            } else {
                strSubCategory = strSubCategory + "," + subcategoryList.get(i);
            }
        }
        tvSubcategory.setText("" + strSubCategory);
    }

    void SetFilterData(String text, String serviceType, Number maxmile, Number maxprice, Number minprice, int rating, Number minmile) {

        MapRequest serviceRequestPojo = new MapRequest();
        if (text != null) {
            serviceRequestPojo.setText(text);

        } else {
            serviceRequestPojo.setText("");
        }

        serviceRequestPojo.setServicesType(serviceType);

        serviceRequestPojo.setLat(Preferences.getPreference(getApplicationContext().getApplicationContext(), PrefEntity.LAT));
        serviceRequestPojo.setLng(Preferences.getPreference(getApplicationContext().getApplicationContext(), PrefEntity.LONG));


        serviceRequestPojo.setMaxMile(maxmile);
        serviceRequestPojo.setMaxPrice(maxprice);
        serviceRequestPojo.setMinPrice(minprice);
        serviceRequestPojo.setRating(rating);
        serviceRequestPojo.setUserId(Preferences.getPreference(getApplicationContext(), PrefEntity.USERID));
        serviceRequestPojo.setMinMile(minmile);
        serviceRequestPojo.setAddress(Address);
        if (CategoryID != null)
            serviceRequestPojo.setCategoryId(CategoryID);
        if (subcategoryIdList.size() > 0)
            serviceRequestPojo.setSubcategoryId(subcategoryIdList);
        RhentoSingleton.getInstance().setMapRequest(serviceRequestPojo);
    }


    void filter(String text) {
        MapRequest serviceRequestPojo;

        serviceRequestPojo = new MapRequest();
        if (text != null) {
            serviceRequestPojo.setText(text);

        } else {
            serviceRequestPojo.setText("");
        }
        Preferences.removePreference(getApplicationContext(), PrefEntity.COMEFROM1);
        Preferences.removePreference(getApplicationContext(),PrefEntity.COMEFROM2);
        serviceRequestPojo.setServicesType(Preferences.getPreference(getApplicationContext(), PrefEntity.COMEFROM1));
        serviceRequestPojo.setLat(Preferences.getPreference(getApplicationContext(), PrefEntity.LAT));
        serviceRequestPojo.setLng(Preferences.getPreference(getApplicationContext(), PrefEntity.LONG));
        serviceRequestPojo.setMaxMile(15);
        serviceRequestPojo.setMaxPrice(1500);
        serviceRequestPojo.setMinPrice(0);
        serviceRequestPojo.setRating(0);
        serviceRequestPojo.setUserId(Preferences.getPreference(getApplicationContext(), PrefEntity.USERID));
        serviceRequestPojo.setMinMile(0);
        serviceRequestPojo.setAddress(Address);
        serviceRequestPojo.setCategoryId("");
        RhentoSingleton.getInstance().setMapRequest(serviceRequestPojo);
    }

    void showDialog() {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_name))
                .setMessage("Are you sure you want to clear filter?")
                .setNegativeButton("No", null)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        filter("");
                        Preferences.removePreference(getApplicationContext(), PrefEntity.ISFILTER);
                        Preferences.removePreference(getApplicationContext(), PrefEntity.COMEFROM1);
                        Intent intent11 = new Intent(MapFilterActivity.this, DashBoardActivity.class);
                        intent11.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent11);
                        finish();
                        arg0.dismiss();
                    }
                }).create().show();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}



