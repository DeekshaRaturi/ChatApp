package com.ripenapps.rehntu.models.bankDetails.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class BankDetailResponse extends BaseResponse {

    @SerializedName("result")
    private BankDetailResult result;
}
