package com.ripenapps.rehntu.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.MarkerInfoWindowAdapter;
import com.ripenapps.rehntu.models.map.response.Service;
import com.ripenapps.rehntu.my_screen.ServiceAndProductDetailActivity;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapFragment extends Fragment implements View.OnClickListener, OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener {

    private View view;
    private SupportMapFragment mapFragment;
    private Toolbar toolbar;
    private AppCompatTextView title;
    private ImageView back;
    APIUtility apiUtility;
    private ArrayList<Service> pinResults;
    private Map<Marker, Service> pins = new HashMap<>();
    private GoogleMap gMap;
    MarkerInfoWindowAdapter markerInfoWindowAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (view==null) {

            view = inflater.inflate(R.layout.fragmnet_map, container, false);

        }


        apiUtility = new APIUtility(getActivity());
        initViews();


        return view;
    }

    private void initViews() {

        mapFragment = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onClick(View view) {

    }


    public void onMapReady(final GoogleMap googleMap) {
        gMap = googleMap;
            plotMarker();


        googleMap.setOnInfoWindowClickListener(this);
        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                int index = (int) marker.getZIndex();
                markerInfoWindowAdapter = new MarkerInfoWindowAdapter(getActivity(), RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().get(index));
                gMap.setInfoWindowAdapter(markerInfoWindowAdapter);
                return false;
            }
        });

    }

    private void plotMarker() {
        gMap.clear();
        LatLng latLng = null;

        for (int i = 0; i < RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().size(); i++) {
            latLng = new LatLng(Double.parseDouble(RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().get(i).getAddress().getLocation().getCoordinateArrayList().get(1)), Double.parseDouble(RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().get(i).getAddress().getLocation().getCoordinateArrayList().get(0)));
           Marker marker = gMap.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.fromResource(R.mipmap.location)).title("").zIndex(i));
           pins.put(marker, RhentoSingleton.getInstance().getResponseResult().getServiceArrayList().get(i));

        }

        if (latLng != null) {
            gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12));
        }
        else {
            Double lat= Double.parseDouble(Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.LAT));
            Double lng=Double.parseDouble(Preferences.getPreference(getActivity().getApplicationContext(), PrefEntity.LONG));
            LatLng latlng1= new LatLng(lat, lng);
            gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng1, 9));


        }


    }


    @Override
    public void onInfoWindowClick(Marker marker) {
        Intent intent = new Intent(getContext(), ServiceAndProductDetailActivity.class);
        if (pins.get(marker).getServices_type().equals("product")) {

            intent.putExtra("id", pins.get(marker).getId());
            intent.putExtra("productType", "product");
            intent.putExtra("userid",pins.get(marker).getUserId());
        } else {
            intent.putExtra("id", pins.get(marker).getId());
            intent.putExtra("productType", "service");
            intent.putExtra("userid",pins.get(marker).getUserId());


        }

        startActivity(intent);
    }
}
