package com.ripenapps.rehntu.models.serviceDetail.response;

public class ServiceDetailResponseResult {
    /*@SerializedName("address")
    Address addressList ;

    @SerializedName("subcategoryId")
    private ArrayList<String> subcategoryIdList=new ArrayList<>();

    @SerializedName("images")
    private ArrayList<String> imagesList=new ArrayList<>();

    private String Uid;

    public Address getAddressList() {
        return addressList;
    }

    public void setAddressList(Address addressList) {
        this.addressList = addressList;
    }

    public ArrayList<String> getSubcategoryIdList() {
        return subcategoryIdList;
    }

    public void setSubcategoryIdList(ArrayList<String> subcategoryIdList) {
        this.subcategoryIdList = subcategoryIdList;
    }

    public ArrayList<String> getImagesList() {
        return imagesList;
    }

    public void setImagesList(ArrayList<String> imagesList) {
        this.imagesList = imagesList;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }*/
}
