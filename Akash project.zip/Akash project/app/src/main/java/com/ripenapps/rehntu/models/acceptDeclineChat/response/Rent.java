package com.ripenapps.rehntu.models.acceptDeclineChat.response;

import com.google.gson.annotations.SerializedName;

public class Rent {
    @SerializedName("rent")
    private double rent;

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }
}
