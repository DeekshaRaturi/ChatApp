package com.ripenapps.rehntu.models.sendDate.response;

import com.google.gson.annotations.SerializedName;

public class SendDateWrapper {


    @SerializedName("data")
    private SendDateResponse response;



    public SendDateResponse getResponse() {
        return response;
    }

    public void setResponse(SendDateResponse response) {
        this.response = response;
    }


}


