package com.ripenapps.rehntu.models.getFeedback.request;

import com.google.gson.annotations.SerializedName;

public class GetFeedbackRequest {



    @SerializedName("user_id")
    private String userId;

    @SerializedName("service_id")
    private String serviceId ;


    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }
}
