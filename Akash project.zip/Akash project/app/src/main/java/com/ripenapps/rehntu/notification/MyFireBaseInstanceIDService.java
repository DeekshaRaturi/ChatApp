package com.ripenapps.rehntu.notification;

import android.util.Log;

import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.google.firebase.iid.zzw;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

public class MyFireBaseInstanceIDService extends FirebaseInstanceIdService {

    public MyFireBaseInstanceIDService() {
        super();
    }

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();

        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Preferences.setPreference(getApplicationContext(),"token",refreshedToken);
        sendRegistrationToServer(refreshedToken);


        Log.e("token", refreshedToken);

    }

    public void sendRegistrationToServer(String token){


    }
}
