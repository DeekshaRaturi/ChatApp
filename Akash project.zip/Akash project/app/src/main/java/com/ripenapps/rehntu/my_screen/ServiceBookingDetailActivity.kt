package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.CardView
import android.text.InputType
import android.text.TextUtils
import android.util.JsonReader
import android.util.Log
import com.google.gson.Gson
import com.ripenapps.rehntu.models.showBooking.request.ShowBookingRequest
import com.ripenapps.rehntu.models.showBooking.response.ShowBookingWrapper
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import java.text.ParseException
import java.text.SimpleDateFormat
import android.view.View
import android.widget.*
import com.adyen.checkout.core.CheckoutException
import com.adyen.checkout.core.PaymentController
import com.adyen.checkout.core.PaymentMethodHandler
import com.adyen.checkout.core.StartPaymentParameters
import com.adyen.checkout.core.handler.StartPaymentParametersHandler
import com.adyen.checkout.ui.CheckoutController
import com.adyen.checkout.ui.CheckoutSetupParameters
import com.adyen.checkout.ui.CheckoutSetupParametersHandler
import com.google.android.gms.vision.text.Line
import com.google.gson.JsonObject
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.acceptDeclineChat.request.AcceptDeclineRequest
import com.ripenapps.rehntu.models.acceptDeclineChat.response.AcceptDeclineWrapper
import com.ripenapps.rehntu.models.bookNow.request.BooknowRequest
import com.ripenapps.rehntu.models.bookNow.response.BookNowWrapper
import com.ripenapps.rehntu.models.payment.request.Payment
import com.ripenapps.rehntu.models.payment.response.PaymentWrapperValue
import com.ripenapps.rehntu.models.paymentSession.request.PaymentRequest
import com.ripenapps.rehntu.models.paymentSession.response.PaymentWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.Constants
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.android.synthetic.main.activity_service_booking_detail.view.*
import org.json.JSONObject
import java.lang.Exception
import java.net.URISyntaxException
import java.text.DateFormat
import java.util.*


class ServiceBookingDetailActivity : AppCompatActivity(), View.OnClickListener {

    private var apiUtility: APIUtility? = null
    private var transaction: String? = null
    private var mcontext: Context? = null
    private var txt_provider_name: TextView? = null
    private var txt_servicename: TextView? = null
    private var selectdate_txt: EditText? = null
    private var img_to: EditText? = null
    private var txt_amount_value: EditText? = null
    private var txt_place_name: EditText? = null
    private var convertedTime: String? = null
    private var request= BooknowRequest()
    private var time:String?=null

    private var mYear: Int = 0
    private var mMonth: Int = 0
    private var mDay: Int = 0
    private var date:String?=null

    private var serviceprovidername:String?=null


    private var back: ImageView? = null
    private var status: String? = null
    private var cancle_edit_layout: LinearLayout? = null
    private var paymentcancle_layout: LinearLayout? = null
    private var isbuyer: String? = null
    private var accept_decline_layout: LinearLayout? = null
    private var accept_btn: Button? = null
    private var accept_cancle_layout: LinearLayout? = null
    private var decline_btn: Button? = null
    private val socket_url = "http://18.216.101.125:3000"
    private var mSocket: Socket? = null
    private var currenttime: String? = null
    private var service_type: String? = null
    private var serviceId: String? = null
    private var user_id: String? = null
    private var service_name: String? = null
    private var edit_butn: Button? = null
    private var payment_cancle_butn: Button? = null
    private var edit_cancle_butn: Button? = null
    private var accept_butn: Button? = null
    private var accept_cancle_btn: Button? = null
    private var price: Int? = null
    private var status_value: String? = null
    private var btn_book_now:Button?=null
    private var address:String?=null
    private var city:String?=null
    private var postal:String?=null
    private var lat:String?=null
    private var longitude:String?=null
    private var place_cardview:CardView?=null
    private var datetime:String?=null
    private var set_time:String?=null
    private var title:AppCompatTextView?=null
    private var local_time:String?=null
    private var payment_butn:TextView?=null
    private var btn_confirm:Button?=null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.ripenapps.rehntu.R.layout.activity_service_booking_detail)

        initViews()
    }

    private fun initViews() {
        apiUtility = APIUtility(this@ServiceBookingDetailActivity)


        transaction = intent.getStringExtra("transaction")
        isbuyer = intent.getStringExtra("isbuyer")

        serviceprovidername=intent.getStringExtra("serviceprovidername")
        txt_provider_name = findViewById(com.ripenapps.rehntu.R.id.txt_provider_name)
        txt_servicename = findViewById(com.ripenapps.rehntu.R.id.txt_servicename)
        selectdate_txt = findViewById(com.ripenapps.rehntu.R.id.img_from)
        img_to = findViewById(com.ripenapps.rehntu.R.id.img_to)
        txt_amount_value = findViewById(com.ripenapps.rehntu.R.id.txt_amount_value)
        txt_place_name = findViewById(com.ripenapps.rehntu.R.id.txt_place_name)
        back = findViewById(com.ripenapps.rehntu.R.id.back)
        back?.setOnClickListener(this)
        status = intent.getStringExtra("status")
        Log.e("stttt"," "+status)
        cancle_edit_layout = findViewById(R.id.cancle_edit_layout)
        btn_confirm=findViewById(R.id.btn_confirm)
        btn_confirm?.setOnClickListener(this)

        title=findViewById(R.id.title)

        paymentcancle_layout = findViewById(R.id.paymentcancle_layout)

        accept_decline_layout = findViewById(R.id.accept_decline_layout)

        accept_cancle_btn=findViewById(R.id.accept_cancle_btn)

        accept_btn = findViewById(R.id.accept_btn)
        accept_butn=findViewById(R.id.accept_butn)
        decline_btn = findViewById(R.id.decline_btn)
        payment_butn=findViewById(R.id.payment_butn)

        edit_butn = findViewById(R.id.edit_butn)
        edit_cancle_butn = findViewById(R.id.edit_cancle_butn)
        payment_cancle_butn = findViewById(R.id.payment_cancle_butn)

        accept_cancle_layout = findViewById(R.id.accept_cancle_layout)

        btn_book_now=findViewById(R.id.btn_book_now)
        place_cardview=findViewById(R.id.place_cardview)



        txt_place_name?.setOnClickListener(this)

        payment_butn?.setOnClickListener(this)

        edit_butn?.setOnClickListener(this)
        edit_cancle_butn?.setOnClickListener(this)
        payment_cancle_butn?.setOnClickListener(this)
        accept_btn?.setOnClickListener(this)
        accept_butn?.setOnClickListener(this)
        decline_btn?.setOnClickListener(this)
        accept_cancle_btn?.setOnClickListener(this)
        // PAYMENTBUTIION


        btn_book_now?.setOnClickListener(this)



        service_name = intent.getStringExtra("service_name")
        transaction = intent.getStringExtra("transaction")
        service_type = intent.getStringExtra("service_type")
        serviceId = intent.getStringExtra("serviceId")
        user_id = intent.getStringExtra("user_id")


        socketConnection()
        socketTestConnection()
        getConvertedTime()
        getBookingDetails()





        if (isbuyer.equals("true")) {

            if (status.equals("1")) {

                cancle_edit_layout?.visibility = View.VISIBLE
            }
            else if (status.equals("2")) {

                paymentcancle_layout?.visibility = View.VISIBLE
            }
            else if (status.equals("4")) {

                cancle_edit_layout?.visibility = View.VISIBLE

            }
            else if (status.equals("8")){

                btn_confirm?.visibility=View.VISIBLE

            }
            else if(status.equals("10")){


            }

              }


            else {

            if (status.equals("1")) {

                accept_decline_layout?.visibility = View.VISIBLE


            }
            else if (status.equals("2")) {

                accept_cancle_layout?.visibility = View.VISIBLE
                accept_butn?.isClickable=false
                accept_butn?.setBackgroundDrawable(ContextCompat.getDrawable(this@ServiceBookingDetailActivity,R.drawable.grey_butn_corner))

            }
            else if (status.equals("3")) {

                accept_butn?.isClickable=false
                accept_cancle_layout?.visibility = View.VISIBLE
                accept_butn?.setBackgroundDrawable(ContextCompat.getDrawable(this@ServiceBookingDetailActivity,R.drawable.grey_butn_corner))


            }
            else if (status.equals("4")){
                btn_confirm?.visibility=View.VISIBLE

            }
            else if(status.equals("8")){


            }
        }



        txt_provider_name?.setFocusable(false)
        txt_provider_name?.setFocusableInTouchMode(false)
        txt_provider_name?.setClickable(false)

        txt_place_name?.setFocusable(false)
        txt_place_name?.setFocusableInTouchMode(false)
        txt_place_name?.setClickable(false)

        txt_amount_value?.setFocusable(false)
        txt_amount_value?.setFocusableInTouchMode(false)
        txt_amount_value?.setClickable(false)

        txt_servicename?.setFocusable(false)
        txt_servicename?.setFocusableInTouchMode(false)
        txt_servicename?.setClickable(false)

        img_to?.setFocusable(false)
        img_to?.setFocusableInTouchMode(false)
        img_to?.setClickable(false)

        selectdate_txt?.setFocusable(false)
        selectdate_txt?.setFocusableInTouchMode(false)
        selectdate_txt?.setClickable(false)



    }


    fun socketConnection() {

        try {
            mSocket = IO.socket(socket_url)


        } catch (e: URISyntaxException) {

        }

        mSocket!!.connect()




        mSocket!!.on("connected") {

        }


        mSocket!!.on("socket") { args ->


        }

    }
    fun getConvertedTime() {

        var currentTime = Calendar.getInstance().getTime()

        var dateFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
        // var dateFormatter =  SimpleDateFormat("dd-MM-yyyy HH:mm:ss")

        dateFormatter.setTimeZone(TimeZone.getDefault())
        currenttime = dateFormatter.format(currentTime)


    }

    fun getConvertedTimeReverse(strDate: String) {

        try {

            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");


            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("dd-MM-yyyy");
            convertedTime=targetDateFormat.format(date)


        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }


    fun getConvertedTime(strDate: String) {

        try {
            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            datetime=targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }







    private fun socketTestConnection() {


        val jsonObject: JSONObject = JSONObject()

        jsonObject?.put("room", transaction)
        jsonObject?.put("user_id", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID))

        mSocket?.emit("test", jsonObject)


        mSocket?.on("test") { args ->

            val data = args[0] as JSONObject


        }

    }



    fun getAcceptStatus() {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)
        request.transaction_id = transaction;
        request.status = "2"
        request.price = price.toString()


        apiUtility?.getAcceptDecline(this@ServiceBookingDetailActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", "2")
                    jsonObject1.put("price",price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })
    }


    fun getDeclineStatus(status: String) {

        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)
        request.transaction_id = transaction
        request.status = status
        request._id = " "
        request.price=price.toString()

        apiUtility?.getAcceptDecline(this@ServiceBookingDetailActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price",price.toString())


                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }

        })


    }


    override fun onClick(v: View?) {

        when (v?.id) {

            com.ripenapps.rehntu.R.id.back -> {

                finish()
                mSocket?.disconnect()
                mSocket?.close()

            }

            R.id.accept_btn -> {

                getAcceptStatus()
            }
            R.id.decline_btn -> {

                getDeclineStatus("6")
            }

            R.id.payment_cancle_butn -> {
                getDeclineStatus("5")


            }
            R.id.edit_cancle_butn -> {
                getDeclineStatus("5")


            }

            R.id.payment_butn->{

                checkpayment()


            }

            R.id.btn_book_now->{


                if(TextUtils.isEmpty(txt_provider_name?.text.toString())||TextUtils.isEmpty(txt_servicename?.text.toString())||TextUtils.isEmpty(selectdate_txt?.text.toString())||TextUtils.isEmpty(img_to?.text.toString())
                        ||TextUtils.isEmpty(txt_amount_value?.text.toString())||TextUtils.isEmpty(txt_place_name?.text.toString()))

                {

//                if(TextUtils.isEmpty(txt_amount_value?.text.toString())|| TextUtils.isEmpty(txt_place_name?.text.toString())|| TextUtils.isEmpty(img_to?.text.toString())|| TextUtils.isEmpty(selectdate_txt?.text.toString())){

                    CommonUtils.AlertDialogDefault(this@ServiceBookingDetailActivity,"","Enter all fields")

             }
                else{
                    Booknow()
                }

            }

            R.id.place_cardview->{

                val intent = Intent(this@ServiceBookingDetailActivity, SelectLocationManually::class.java)
                intent.putExtra("requestFrom", "FILTER")

                startActivityForResult(intent, Constants.REQUESTCODE_2)

            }

            R.id.edit_butn -> {

                txt_amount_value?.setFocusable(true)
                txt_amount_value?.setFocusableInTouchMode(true)
                txt_amount_value?.setClickable(true)
                txt_amount_value?.isCursorVisible=true

                txt_place_name?.setFocusable(true)
                txt_place_name?.setFocusableInTouchMode(true)
                txt_place_name?.setClickable(true)

                img_to?.setFocusable(true)
                img_to?.setFocusableInTouchMode(true)
                img_to?.setClickable(true)

                selectdate_txt?.setFocusable(true)
                selectdate_txt?.setFocusableInTouchMode(true)
                selectdate_txt?.setClickable(true)


                accept_decline_layout?.visibility=View.GONE
                accept_cancle_layout?.visibility=View.GONE
                paymentcancle_layout?.visibility=View.GONE
                cancle_edit_layout?.visibility=View.GONE

                btn_book_now?.visibility=View.VISIBLE



                img_to?.setOnClickListener(this)
                selectdate_txt?.setOnClickListener(this)
                place_cardview?.setOnClickListener(this)



            }
            R.id.btn_confirm->{
                if (isbuyer.equals("true")){
                    getConfirmed("13")
                }
                else{
                    getConfirmed("8")
                }


            }


            R.id.img_to -> {


                val c = Calendar.getInstance()

                val mHour = c.get(Calendar.HOUR_OF_DAY)
                val mMinute = c.get(Calendar.MINUTE)


                val timePickerDialog = TimePickerDialog(this,
                        TimePickerDialog.OnTimeSetListener { view, hourOfDay, minute ->

                            var datetime = Calendar.getInstance();

                            datetime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                            datetime.set(Calendar.MINUTE, minute);


                            if (datetime.getTimeInMillis() >= c.getTimeInMillis()+1800000) {

                                var hour = hourOfDay % 12;
                                Log.e("houre"," "+hour)


                                img_to!!.setText(hourOfDay.toString()+":"+minute)
                                time=hourOfDay.toString()+":"+minute



                            } else {

                                Toast.makeText(getApplicationContext(), "Select valid Time", Toast.LENGTH_LONG).show();
                            }



                        }, mHour, mMinute, false)

                timePickerDialog.show()




            }

            R.id.img_from -> {

                val c = Calendar.getInstance()
                mYear = c.get(Calendar.YEAR)
                mMonth = c.get(Calendar.MONTH)
                mDay = c.get(Calendar.DAY_OF_MONTH)


                val datePickerDialog = DatePickerDialog(this,
                        DatePickerDialog.OnDateSetListener {
                            view, year, monthOfYear, dayOfMonth ->

                            var datetime1=dayOfMonth.toString()+"-"+monthOfYear+1+"-"+year
                            val datenew:String = ""+year+"-"+String.format("%02d", (monthOfYear+1))+"-"+String.format("%02d", dayOfMonth)
                            getConvertedTime(datenew)
                            date=datetime
                            selectdate_txt!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)

                        }, mYear, mMonth, mDay)
                datePickerDialog.show()
                datePickerDialog.getDatePicker().minDate=System.currentTimeMillis()-1000



            }


            R.id.accept_butn -> {
                getAcceptStatus()


            }
            R.id.accept_cancle_btn -> {
                getDeclineStatus("6")


            }


        }

    }

    fun updateStatus(){


        var acceptDeclineRequest=AcceptDeclineRequest()
        acceptDeclineRequest.status="4"
        acceptDeclineRequest.transaction_id=transaction
        acceptDeclineRequest.user_id=Preferences.getPreference(this@ServiceBookingDetailActivity,PrefEntity.USERID)




        apiUtility?.getAcceptDecline(this@ServiceBookingDetailActivity, acceptDeclineRequest, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", "4")
                    jsonObject1.put("price",price.toString())


                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)



            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }

        })


    }

    fun paymentSucess(payload:String) {
        var payment = Payment()
        payment.payload = payload
        payment.user_id = Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)



        apiUtility?.displayAllPayment(this@ServiceBookingDetailActivity, payment, true, object : APIUtility.APIResponseListener<PaymentWrapperValue> {
            override fun onReceiveResponse(response: PaymentWrapperValue?) {
                var gson = Gson()
                Log.e("displaysucess", "" + gson.toJson(response)+" "+response?.response?.getPaymentResult?.pspReference)
                updateStatus()


            }

            override fun onResponseFailed() {
                Log.e("error", "error")

            }

            override fun onStatusFalse(response: PaymentWrapperValue?) {

            }


        })

    }


    fun checkpayment() {

        CheckoutController.startPayment(this, object : CheckoutSetupParametersHandler {
            override fun onRequestPaymentSession(checkoutSetupParameters: CheckoutSetupParameters) {
                Log.e("chekout", " " + checkoutSetupParameters.returnUrl + "   " + checkoutSetupParameters.sdkToken)


                var date =  Date(System.currentTimeMillis()+120000)
                var sdf =  SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                sdf.setTimeZone(TimeZone.getTimeZone("CET"))
                var timestamp= sdf.format(date)
                Log.e("sdf",""+timestamp)


                var paymentRequest = PaymentRequest()
                paymentRequest.am.currency = "USD"
                paymentRequest.am.value = 10.0
                paymentRequest.channel = "Android"
                paymentRequest.countryCode = "US"
                paymentRequest.reference = transaction
                paymentRequest.returnUrl = checkoutSetupParameters.returnUrl

                paymentRequest.shopperLocale = "en_US"


                paymentRequest.token = checkoutSetupParameters.sdkToken
                paymentRequest.merchantAccount = "RhentuLLCCOM122"

              //  paymentRequest.sessionValidity=timestamp

                paymentRequest.enableOneClick=true
                paymentRequest.enableRecurring=true
                paymentRequest.origin="https://www.yourwebsite.com"


                paymentRequest.shopperReference=Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)
                //paymentRequest.sessionValidity = "2017-04-06T13:09:13Z"

               //  paymentRequest.user_id = Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)

               // paymentRequest.shopperReference=transaction


                apiUtility?.displayAllPaymentSession(this@ServiceBookingDetailActivity, paymentRequest, true, object : APIUtility.APIResponseListener<PaymentWrapper> {
                    override fun onReceiveResponse(response: PaymentWrapper?) {
                        var gson = Gson()
                        var encodedSessiion=response?.response?.getPaymentResult?.paymentSession

                        PaymentController.handlePaymentSessionResponse(this@ServiceBookingDetailActivity, encodedSessiion!!, object : StartPaymentParametersHandler {
                            override fun onPaymentInitialized(startPaymentParameters: StartPaymentParameters) {



                                val paymentMethodHandler = CheckoutController.getCheckoutHandler(startPaymentParameters)
                                paymentMethodHandler.handlePaymentMethodDetails(this@ServiceBookingDetailActivity, 1999)

                            }

                            override fun onError(checkoutException: CheckoutException) {

                            }
                        })


                    }

                    override fun onResponseFailed() {

                    }

                    override fun onStatusFalse(response: PaymentWrapper?) {

                    }

                })

            }

            override fun onError(checkoutException: CheckoutException) {
                Log.e("error", checkoutException.payload + " " + checkoutException.message)
            }
        })


    }



    override fun onBackPressed() {
        super.onBackPressed()
        mSocket?.disconnect()
        mSocket?.close()
    }

    fun getLocalTime(){


        var formatter =  SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"))
        var value = formatter.parse(time)
        var dateFormatter =  SimpleDateFormat("MM-dd-yyyy HH:mm") //this format changeable
        dateFormatter.setTimeZone(TimeZone.getDefault())
        local_time = dateFormatter.format(value)




    }





    fun Booknow(){

        request.buyer_id= Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)
       // request.buyer_name= Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USER_NAME)

        request.from=date

        request.price=txt_amount_value?.text.toString()
        request.service_id=serviceId
        request.service_provider_id=user_id
        //request.service_name=service_name
        request.time=time
       // request.service_provider_name=serviceprovidername

        request.transaction_id=transaction
        request.service_type=service_type



        apiUtility?.getBookNow(this@ServiceBookingDetailActivity, request, true, object : APIUtility.APIResponseListener<BookNowWrapper> {


            override fun onReceiveResponse(response: BookNowWrapper?) {

                Toast.makeText(this@ServiceBookingDetailActivity,"Booking Updated",Toast.LENGTH_SHORT).show()
                var price=response?.response?.getBooknowresult?.price
                var code=response?.response?.getBooknowresult?.status
                var status=code.toString()


                intent.putExtra("price",price)
                intent.putExtra("status",status)

                setResult(Activity.RESULT_OK, intent)
                finish()

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", time)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status",status)
                    jsonObject1.put("price",price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")



                }
                catch (e: Exception){


                }
                mSocket?.emit("createMessage", jsonObject1, object1)



            }

            override fun onResponseFailed() {
            }

            override fun onStatusFalse(response: BookNowWrapper?) {
            }

        })




    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("requ", "" + resultCode + " " + requestCode)

        if (requestCode == 1002) {


            if (resultCode == Activity.RESULT_OK) {

                finish()

            }
        }


        if (requestCode == 1999) {
            if (resultCode == PaymentMethodHandler.RESULT_CODE_OK) {

                var paymentResult = PaymentMethodHandler.Util.getPaymentResult(data)
                Log.e("paymentres"," "+paymentResult?.payload)

                paymentSucess(paymentResult?.payload!!)

                // Handle PaymentResult.
            } else {
                var checkoutException = PaymentMethodHandler.Util.getCheckoutException(data)
                Log.e("paymentresexcep"," "+checkoutException?.localizedMessage)


                if (resultCode == PaymentMethodHandler.RESULT_CODE_CANCELED) {
                    // Handle cancellation and optional CheckoutException.
                } else {
                    // Handle CheckoutException.
                }
            }
        }



        if (requestCode == Constants.REQUESTCODE_2) {


            if (resultCode == Activity.RESULT_OK) {
                address = data!!.getStringExtra("fullAdress")

                postal=data?.getStringExtra("postal")
                city=data?.getStringExtra("city")

                if (postal!=null){
                    request.pincode=postal

                }
                else{
                    request.pincode="201303"
                }


                Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                val Address = address
                txt_place_name!!.setText(address)
                Log.e("postal",postal+" "+city+" "+lat+" "+longitude)


                request.city=city
                request.fullAddress=address

                request.longtitude=Preferences.getPreference(this@ServiceBookingDetailActivity,PrefEntity.LONG)
                request.lat= Preferences.getPreference(this@ServiceBookingDetailActivity,PrefEntity.LAT)


            }

        }
    }

    fun getBookingDetails() {


        var request = ShowBookingRequest()

        request.transaction_id = transaction
        request.user_id = Preferences.getPreference(this, PrefEntity.USERID)


        apiUtility?.showBooking(this@ServiceBookingDetailActivity, request, true, object : APIUtility.APIResponseListener<ShowBookingWrapper> {
            override fun onReceiveResponse(response: ShowBookingWrapper?) {


                var servicename = response?.response?.getBookingresult?.booking?.service_name
                title?.text=servicename

                txt_servicename?.setText(servicename)

                price = response?.response?.getBookingresult?.booking?.price

                txt_amount_value?.setText(response?.response?.getBookingresult?.booking?.price.toString())

                txt_provider_name?.setText(response?.response?.getBookingresult?.booking?.service_provider_name)

                var jsonResponse =  Gson().toJson(response?.response?.getBookingresult?.booking)

                var jsonObject =  JSONObject(jsonResponse );


                if (jsonObject.has("from")){
                    var select_time=response?.response?.getBookingresult?.booking?.from
                    getConvertedTimeReverse(select_time!!)
                    selectdate_txt?.setText(convertedTime)


                }
                if (jsonObject.has("time"))
                    {

                     var datetime = response?.response?.getBookingresult?.booking?.time
                     img_to?.setText(datetime)

                    }

                txt_place_name?.setText(response?.response?.getBookingresult?.booking?.address?.fullAddress)


            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: ShowBookingWrapper?) {

            }

        })

    }

    fun getConfirmed(status: String){



        val request = AcceptDeclineRequest()
        request.user_id = Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID)
        request.transaction_id = transaction;
        request.status = status
        request.price = price.toString()


        apiUtility?.getAcceptDecline(this@ServiceBookingDetailActivity, request, true, object : APIUtility.APIResponseListener<AcceptDeclineWrapper> {
            override fun onReceiveResponse(response: AcceptDeclineWrapper?) {


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ServiceBookingDetailActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price",price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")

                    finish()


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {

            }

            override fun onStatusFalse(response: AcceptDeclineWrapper?) {

            }


        })


    }

}
