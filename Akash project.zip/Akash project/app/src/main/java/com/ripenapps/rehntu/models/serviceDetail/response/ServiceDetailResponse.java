package com.ripenapps.rehntu.models.serviceDetail.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class ServiceDetailResponse extends BaseResponse {

    @SerializedName("result")
    private ServiceDetailResponseResult result;

    public ServiceDetailResponseResult getResult() {
        return result;
    }

    public void setResult(ServiceDetailResponseResult result) {
        this.result = result;
    }
}
