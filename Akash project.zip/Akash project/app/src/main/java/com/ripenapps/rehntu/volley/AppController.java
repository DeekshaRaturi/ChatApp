package com.ripenapps.rehntu.volley;

import android.app.Application;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.google.gson.JsonArray;
import com.ripenapps.rehntu.R;


import java.io.File;
import java.util.ArrayList;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;


public final class AppController extends Application {

    public static final String TAG = AppController.class.getSimpleName();

    private RequestQueue mRequestQueue;
    private ImageLoader mImageLoader;

    public   String  from = null;
    public  String  to = null;
    public  String  service_type = null;
    public JsonArray status_value = new JsonArray();

    public ArrayList<Integer> getTotal_array() {
        return total_array;
    }

    public void setTotal_array(ArrayList<Integer> total_array) {
        this.total_array = total_array;
    }

    public ArrayList<Integer>total_array=new ArrayList<>();


    public JsonArray getStatus_value() {
        return status_value;
    }

    public void setStatus_value(JsonArray status_value) {
        this.status_value = status_value;
    }


    public    String getFrom() {
        return from;
    }

    public  void setFrom(String from) {
        this.from = from;
    }

    public  String getTo() {
        return to;
    }

    public  void setTo(String to) {
        this.to = to;
    }

    public  String getService_type() {
        return service_type;
    }

    public  void setService_type(String service_type) {
        this.service_type = service_type;
    }




    private static AppController mInstance;

    @Override
    public void onCreate() {
        super.onCreate();
////        Fabric.with(this, new Crashlytics());
      CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Montserrat_Light.otf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );

        mInstance = this;
    }

    public static synchronized AppController getInstance() {
        return mInstance;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = com.android.volley.toolbox.Volley.newRequestQueue(getApplicationContext());
        }

        return mRequestQueue;
    }

    public ImageLoader getImageLoader() {
        getRequestQueue();
        if (mImageLoader == null) {
            mImageLoader = new ImageLoader(this.mRequestQueue, new LruBitmapCache());
        }
        return this.mImageLoader;
    }

    public <T> void addToRequestQueue(Request<T> req, String tag) {
        // set the default tag if tag is empty
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
        getRequestQueue().add(req);
    }

    public <T> void addToRequestQueue(Request<T> req) {
        req.setTag(TAG);
        getRequestQueue().add(req);
    }

    public void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }

    public void clearApplicationData() {
        File cacheDirectory = getCacheDir();
        File applicationDirectory = new File(cacheDirectory.getParent());
        if (applicationDirectory.exists()) {
            String[] fileNames = applicationDirectory.list();
            for (String fileName : fileNames) {
                if (!fileName.equals("lib")) {
                    deleteFile(new File(applicationDirectory, fileName));
                }
            }
        }
    }
    public static boolean deleteFile(File file) {
        boolean deletedAll = true;
        if (file != null) {
            if (file.isDirectory()) {
                String[] children = file.list();
                for (int i = 0; i < children.length; i++) {
                    deletedAll = deleteFile(new File(file, children[i])) && deletedAll;
                }
            } else {
                deletedAll = file.delete();
            }
        }

        return deletedAll;
    }
}
