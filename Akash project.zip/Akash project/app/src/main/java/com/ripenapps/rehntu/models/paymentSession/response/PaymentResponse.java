package com.ripenapps.rehntu.models.paymentSession.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;
import com.ripenapps.rehntu.models.notification.response.NotificationResult;

public class PaymentResponse extends BaseResponse {

    public PaymentResult getGetPaymentResult() {
        return getPaymentResult;
    }

    public void setGetPaymentResult(PaymentResult getPaymentResult) {
        this.getPaymentResult = getPaymentResult;
    }

    @SerializedName("result")
    private PaymentResult getPaymentResult;



}
