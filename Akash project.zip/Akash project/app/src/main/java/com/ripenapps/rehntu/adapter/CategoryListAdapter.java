package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.category.response.Category;
import com.ripenapps.rehntu.my_util.Constants;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CategoryListAdapter extends RecyclerView.Adapter<CategoryListAdapter.ViewHolder> {

    private Context mContext;
    private List<Category> categoryList;
    public CategoryListAdapterCallback callback;


    public CategoryListAdapter(List<Category> streetList, Context mContext) {
        this.mContext = mContext;
        this.categoryList = streetList;
        this.callback=(CategoryListAdapterCallback)mContext;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_list, parent, false));
    }


    @Override
    public void onBindViewHolder(final CategoryListAdapter.ViewHolder holder, final int position) {


        holder.categoryName.setText(categoryList.get(position).getName());
        Picasso.with(mContext).load(Constants.IMG_URL + categoryList.get(position).getIcon()).placeholder(R.drawable.place_holder).into(holder.list);
        holder.list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.itemClick(position);
            }
        });
    }


    @Override
    public int getItemCount() {
        return categoryList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView list;
        TextView categoryName;


        ViewHolder(View itemView) {
            super(itemView);
            list = (ImageView) itemView.findViewById(R.id.iv_category);
            categoryName = (TextView) itemView.findViewById(R.id.tv_category_name);
        }


    }

    public interface CategoryListAdapterCallback {
        void itemClick(int Pos);
    }


}
