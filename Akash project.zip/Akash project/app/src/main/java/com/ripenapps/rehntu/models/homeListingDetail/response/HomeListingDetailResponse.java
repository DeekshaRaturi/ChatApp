package com.ripenapps.rehntu.models.homeListingDetail.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class HomeListingDetailResponse extends BaseResponse{


    @SerializedName("result")
    private HomeListingDetailResult result;


    public HomeListingDetailResult getResult() {
        return result;
    }

    public void setResult(HomeListingDetailResult result) {
        this.result = result;
    }
}
