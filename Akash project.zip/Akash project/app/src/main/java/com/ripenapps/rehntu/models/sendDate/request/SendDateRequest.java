package com.ripenapps.rehntu.models.sendDate.request;

import com.google.gson.annotations.SerializedName;

public class SendDateRequest {

    public String getBuyer_id() {
        return buyer_id;
    }

    public void setBuyer_id(String buyer_id) {
        this.buyer_id = buyer_id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @SerializedName("buyer_id")
    private String buyer_id;

    @SerializedName("transaction_id")
    private String transaction_id;

    @SerializedName("date")
    private String date;

    @SerializedName("price")
    private String price;

    @SerializedName("from")
    private String from;

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    @SerializedName("service_type")
    private String service_type;

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    @SerializedName("to")
    private String to;


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @SerializedName("time")
    private String time;
}
