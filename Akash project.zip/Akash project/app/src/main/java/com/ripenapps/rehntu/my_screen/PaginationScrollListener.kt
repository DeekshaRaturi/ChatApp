package com.ripenapps.rehntu.my_screen

import android.support.v7.widget.RecyclerView
import android.support.v7.widget.LinearLayoutManager


open class PaginationScrollListener: RecyclerView.OnScrollListener {


    var layoutManager:LinearLayoutManager?=null


    constructor(layoutManager: LinearLayoutManager?=null) {
        this.layoutManager = layoutManager
    }

    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
        super.onScrolled(recyclerView, dx, dy)


        val visibleItemCount = layoutManager?.getChildCount()
        val totalItemCount = layoutManager?.getItemCount()
        val firstVisibleItemPosition = layoutManager!!.findFirstVisibleItemPosition()

        if (!isLoading() && !isLastPage()) {
            if (visibleItemCount!! + firstVisibleItemPosition >= totalItemCount!! && firstVisibleItemPosition >= 0) {
                loadMoreItems()
            }
        }
    }

    fun loadMoreItems(){}

    fun getTotalPageCount(): Int{
        return 0
    }

    fun isLastPage(): Boolean{
        return false
    }

    fun isLoading(): Boolean{
        return false
    }

    override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
        super.onScrollStateChanged(recyclerView, newState)
    }
}