package com.ripenapps.rehntu.models.serviceDetail.request;


import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ServiceDetailRequest {

    @SerializedName("fullAddress")
    private String fullAddress;

    @SerializedName("services_type")
    private String serviceType;

    @SerializedName("description")
    private String description;

    @SerializedName("name")
    private String name;

    @SerializedName("securityDeposite")
    private String securityDeposite;

    @SerializedName("pincode")
    private String pincode;

    @SerializedName("long")
    private String long1;

    @SerializedName("yearPurchase")
    private String yearPurchase;

    @SerializedName("lat")
    private String lat;

    @SerializedName("categoryId")
    private String categoryId;

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("city")
    private String city;
    @SerializedName("subcategoryId")
    private ArrayList<String> subcategoryIdList = new ArrayList<>();

    @SerializedName("basePrice")
    private String basePrice;

    @SerializedName("ratePerHour")
    private String ratePerHour;

    @SerializedName("service_id")
    private String service_id;

    public String getService_id() {

        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(String ratePerHour) {
        this.ratePerHour = ratePerHour;
    }

    public ArrayList<String> getSubcategoryIdList() {
        return subcategoryIdList;
    }

    public void setSubcategoryIdList(ArrayList<String> subcategoryIdList) {
        this.subcategoryIdList = subcategoryIdList;
    }

    public String getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(String basePrice) {
        this.basePrice = basePrice;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSecurityDeposite() {
        return securityDeposite;
    }

    public void setSecurityDeposite(String securityDeposite) {
        this.securityDeposite = securityDeposite;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getLong1() {
        return long1;
    }

    public void setLong1(String long1) {
        this.long1 = long1;
    }

    public String getYearPurchase() {
        return yearPurchase;
    }

    public void setYearPurchase(String yearPurchase) {
        this.yearPurchase = yearPurchase;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }


}








