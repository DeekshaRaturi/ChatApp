package com.ripenapps.rehntu.models.homeListingDetail.response;

import com.google.gson.annotations.SerializedName;

public class HomeListingDetailResponseWrapper {

    @SerializedName("data")
    private HomeListingDetailResponse response;

    public HomeListingDetailResponse getResponse() {
        return response;
    }

    public void setResponse(HomeListingDetailResponse response) {
        this.response = response;
    }
}
