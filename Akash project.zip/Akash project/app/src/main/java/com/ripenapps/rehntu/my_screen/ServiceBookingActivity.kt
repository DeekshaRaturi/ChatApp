package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.CardView
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.Gson

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.bookNow.request.BooknowRequest
import com.ripenapps.rehntu.models.bookNow.response.BookNowWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.Constants
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import org.w3c.dom.Text
import java.lang.Exception
import java.net.URISyntaxException
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class ServiceBookingActivity : AppCompatActivity(), View.OnClickListener {

    private var edt_date: EditText? = null
    private var edt_time: EditText? = null
    private var mYear: Int = 0
    private var mMonth: Int = 0
    private var mDay: Int = 0
    private var service_name: String? = null
    private var title: AppCompatTextView? = null
    private var txt_amount: TextView? = null
    private var btn_book_now: Button? = null
    private var context: Context? = null
    private var apiUtility: APIUtility? = null
    private var transaction: String? = null
    private var service_type: String? = null
    private var serviceId: String? = null
    private var user_id: String? = null
    private var date: String? = null
    private var time: String? = null
    private var txt_amount_value: EditText? = null
    private var address: String? = null
    private var city: String? = null
    private var postal: String? = null
    private var lat: String? = null
    private var longitude: String? = null
    private var request = BooknowRequest()

    private var txt_place_name: TextView? = null
    private var place_cardview: CardView? = null
    private var txt_address: TextView? = null
    private var service_provider_name: String? = null
    private var txt_provider_name: TextView? = null
    private var value: Int? = null
    private var accept_btn: Button? = null
    private var decline_btn: Button? = null
    private var currenttime: String? = null

    private val socket_url = "http://18.216.101.125:3000"
    private var mcontext: Context? = null
    private var mSocket: Socket? = null
    private var back: ImageView? = null
    private var send_date:String?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        initView()
        // setResult(Activity.RESULT_OK)


    }

    private fun initView() {


        service_name = intent.getStringExtra("service_name")
        transaction = intent.getStringExtra("transaction")
        service_type = intent.getStringExtra("service_type")
        serviceId = intent.getStringExtra("serviceId")
        user_id = intent.getStringExtra("user_id")
        service_provider_name = intent.getStringExtra("serviceprovidername")

        Log.e("buyerid1", "" + user_id + " " + Preferences.getPreference(this@ServiceBookingActivity, PrefEntity.USERID))



        edt_time = findViewById<View>(R.id.img_to) as EditText
        edt_date = findViewById<View>(R.id.img_from) as EditText
        back = findViewById(R.id.back)
        back?.setOnClickListener(this)
        title = findViewById<View>(R.id.title) as AppCompatTextView
        txt_amount = findViewById(R.id.txt_amount) as TextView
        btn_book_now = findViewById(R.id.btn_book_now) as Button
        txt_amount_value = findViewById(R.id.txt_amount_value)
        txt_provider_name = findViewById(R.id.txt_provider_name)


        txt_provider_name?.setText(service_provider_name)

        txt_place_name = findViewById(R.id.txt_place_name)
        place_cardview = findViewById(R.id.place_cardview)
        txt_address = findViewById(R.id.txt_address)

        place_cardview?.setOnClickListener(this)

        context = this
        apiUtility = APIUtility(this)


        btn_book_now?.setOnClickListener(this)


        edt_date!!.setOnClickListener(this)
        edt_time!!.setOnClickListener(this)



        title?.text = service_name

        getConvertedTime()
        socketConnection()
        socketTestConnection()


    }

    fun getConvertedTime() {

        var currentTime = Calendar.getInstance().getTime()

        var dateFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
        // var dateFormatter =  SimpleDateFormat("dd-MM-yyyy HH:mm:ss")

        dateFormatter.setTimeZone(TimeZone.getDefault())
        currenttime = dateFormatter.format(currentTime)


    }

    fun getConvertedTime(strDate: String) {

        try {
            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            send_date=targetDateFormat.format(date)

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }


    fun socketConnection() {

        try {
            mSocket = IO.socket(socket_url)


        } catch (e: URISyntaxException) {

        }

        mSocket!!.connect()




        mSocket!!.on("connected") {

        }



        mSocket!!.on("socket") { args ->

            // `object` = args[0] as Any


        }

    }


    private fun socketTestConnection() {


        val jsonObject: JSONObject = JSONObject()

        jsonObject?.put("room", transaction)
        jsonObject?.put("user_id", Preferences.getPreference(this@ServiceBookingActivity, PrefEntity.USERID))

        mSocket?.emit("test", jsonObject)


        mSocket?.on("test") { args ->

            val data = args[0] as JSONObject


        }

    }


    fun Booknow() {

        request.buyer_id = Preferences.getPreference(context, PrefEntity.USERID)
       // request.buyer_name = Preferences.getPreference(context, PrefEntity.USER_NAME)

        request.from = date

        request.price = txt_amount_value?.text.toString()
        request.service_id = serviceId
        request.service_provider_id = user_id
        //request.service_name = service_name
        request.time = time
       // request.service_provider_name = service_provider_name

        request.transaction_id = transaction
        request.service_type = service_type
        var gson=Gson()
        Log.e("servicebook",""+gson.toJson(request))




        apiUtility?.getBookNow(this@ServiceBookingActivity, request, true, object : APIUtility.APIResponseListener<BookNowWrapper> {

            override fun onReceiveResponse(response: BookNowWrapper?) {

                Toast.makeText(context, "Service Booked Successfully", Toast.LENGTH_SHORT).show()

                var price = response?.response?.getBooknowresult?.price
                var code = response?.response?.getBooknowresult?.status
                var status=code.toString()


                intent.putExtra("price", price)
                intent.putExtra("status", status)
                intent.putExtra("status",status.toInt())

                setResult(Activity.RESULT_OK, intent)
                finish()

                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ServiceBookingActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ServiceBookingActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status", status)
                    jsonObject1.put("price", price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")


                } catch (e: Exception) {


                }
                mSocket?.emit("createMessage", jsonObject1, object1)


            }

            override fun onResponseFailed() {
            }

            override fun onStatusFalse(response: BookNowWrapper?) {
               // Toast.makeText(context, "Service Updated Successfully", Toast.LENGTH_SHORT).show()

            }

        })



    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == Constants.REQUESTCODE_2) {


            if (resultCode == Activity.RESULT_OK) {
                address = data!!.getStringExtra("fullAdress")

                postal = data?.getStringExtra("postal")
                city = data?.getStringExtra("city")

                if (postal != null) {
                    request.pincode = postal

                } else {
                    request.pincode = "201303"
                }


                Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                val Address = address
                txt_place_name!!.text = "" + address
                Log.e("postal", postal + " " + city + " " + lat + " " + longitude)


                request.city = city
                request.fullAddress = address

                request.longtitude = Preferences.getPreference(context, PrefEntity.LONG)
                request.lat = Preferences.getPreference(context, PrefEntity.LAT)



            }

        }


    }


    override fun onClick(v: View) {
        when (v.id) {

            R.id.btn_book_now -> {
                if (TextUtils.isEmpty(txt_amount_value?.text.toString()) || TextUtils.isEmpty(txt_place_name?.text.toString()) || TextUtils.isEmpty(edt_date?.text.toString()) || TextUtils.isEmpty(edt_time?.text.toString())) {

                    CommonUtils.AlertDialogDefault(context, "", "Enter all fields")

                } else {
                    Booknow()
                }


            }
            R.id.back -> {

                finish()
                mSocket?.disconnect()
                mSocket?.close()

            }
            R.id.place_cardview -> {


                val intent = Intent(this@ServiceBookingActivity, SelectLocationManually::class.java)
                intent.putExtra("requestFrom", "FILTER")

                startActivityForResult(intent, Constants.REQUESTCODE_2)


            }


            R.id.img_to -> {

//                val c = Calendar.getInstance()
//
//                val mHour = c.get(Calendar.HOUR_OF_DAY)
//                val mMinute = c.get(Calendar.MINUTE)

                val c = Calendar.getInstance()

                val mHour = c.get(Calendar.HOUR_OF_DAY)
                val mMinute = c.get(Calendar.MINUTE)


                val timePickerDialog = TimePickerDialog(this,
                        TimePickerDialog.OnTimeSetListener { view, hourOfDay, minute ->


                            var datetime = Calendar.getInstance();


                            val mHour = c.get(Calendar.HOUR_OF_DAY)
                            val mMinute = c.get(Calendar.MINUTE)

                            datetime.set(Calendar.HOUR_OF_DAY, hourOfDay)
                            datetime.set(Calendar.MINUTE, minute)


                            if (datetime.getTimeInMillis() >= c.getTimeInMillis()+1800000) {


                                var hour = hourOfDay % 12
                                Log.e("houre"," "+hour)


                                edt_time!!.setText(hourOfDay.toString() + ":" + minute)
                                time = hourOfDay.toString() + ":" + minute


                            } else {

                                Toast.makeText(getApplicationContext(), "Select valid Time", Toast.LENGTH_LONG).show();
                            }


                        }, mHour, mMinute, false)

                timePickerDialog.show()


            }

            R.id.img_from -> {

                val c = Calendar.getInstance()
                mYear = c.get(Calendar.YEAR)
                mMonth = c.get(Calendar.MONTH)
                mDay = c.get(Calendar.DAY_OF_MONTH)


                val datePickerDialog = DatePickerDialog(this,
                        DatePickerDialog.OnDateSetListener {
                            view, year, monthOfYear, dayOfMonth ->

                            val datenew:String = ""+year+"-"+String.format("%02d", (monthOfYear+1))+"-"+String.format("%02d", dayOfMonth)

                            getConvertedTime(datenew)
                            date=send_date

                            edt_date!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)

                        }, mYear, mMonth, mDay)
                datePickerDialog.show()
                datePickerDialog.getDatePicker().minDate=System.currentTimeMillis()-1000



            }
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        mSocket?.disconnect()
        mSocket?.close()
    }
}
