package com.ripenapps.rehntu.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.models.chat.response.Chat;
import com.ripenapps.rehntu.my_screen.OnLoadMoreListener;
import com.ripenapps.rehntu.my_util.OnClicklistener;

import java.util.ArrayList;


public class ChatAdapterr extends RecyclerView.Adapter<ChatAdapterr.ViewHolder>  {

    private ArrayList<Chat> chatArrayList;
    private Context context;
    private OnLoadMoreListener mOnLoadMoreListener = null;
    private OnClicklistener onClicklistener=null;

    private Boolean isLoading = false;
    private Boolean islastPage=false;

    private int visibleThreshold = 1;

    private int lastVisibleItem = 0;
    private int totalItemCount = 0;

    private LinearLayoutManager mLinearLayoutManager= null;

    private RecyclerView recyclerView=null;



    public ChatAdapterr(ArrayList<Chat>chatArrayList,Context context,RecyclerView recyclerView,OnClicklistener onClicklistener){

        this.chatArrayList=chatArrayList;
        this.context=context;

        this.recyclerView=recyclerView;
        this.onClicklistener=onClicklistener;
        mLinearLayoutManager=new LinearLayoutManager(recyclerView.getContext());

       // scroller();





    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new ChatAdapterr.ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.chat_item_send, viewGroup, false));

    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int i) {


        viewHolder.text_message_body_recieved.setText(chatArrayList.get(i).getMsg_recieve());
        viewHolder.text_message_body_send.setText(chatArrayList.get(i).getMsg_recieve());

        viewHolder.text_msg_special_send.setText(chatArrayList.get(i).getMsg_recieve());
        viewHolder.text_msg_special_recieve.setText(chatArrayList.get(i).getMsg_recieve());


        viewHolder.text_message_time_recieved.setText(chatArrayList.get(i).getMsg_recieve_time());
        viewHolder.text_message_time_send.setText(chatArrayList.get(i).getMsg_recieve_time());
        viewHolder.text_message_time_special_recieve.setText(chatArrayList.get(i).getMsg_recieve_time());
        viewHolder.text_message_time_special_send.setText(chatArrayList.get(i).getMsg_recieve_time());
        Log.e("price",""+chatArrayList.get(i).getPrice());



//        viewHolder.butn_accept_recieve.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//               if (chatArrayList.get(i).getStatus()==1){
//                   Log.e("click",chatArrayList.get(i).getPrice());
//
//                   onClicklistener.click(i,chatArrayList.get(i).getPrice());
//
//
//               }
//
//            }
//        });





//        viewHolder.butn_decline_recieve.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                onClicklistener.declineclick(i,chatArrayList.get(i).getPrice());
//
//
//            }
//        });
//
//        Log.e("statusmsg",""+chatArrayList.get(i).getStatus()+" "+chatArrayList.get(i).getSpecialmsg());


        if (chatArrayList.get(i).getStatus()==0){

            if (chatArrayList.get(i).getSpecialmsg().equals("1")){

                viewHolder.recieve_layout.setVisibility(View.GONE);
                viewHolder.send_layout.setVisibility(View.GONE);
                viewHolder.special_layout_send_layout.setVisibility(View.VISIBLE);
                viewHolder.special_layout_recieve_layout.setVisibility(View.GONE);


            }
            else {


                viewHolder.recieve_layout.setVisibility(View.GONE);
                viewHolder.send_layout.setVisibility(View.VISIBLE);
                viewHolder.special_layout_send_layout.setVisibility(View.GONE);
                viewHolder.special_layout_recieve_layout.setVisibility(View.GONE);

            }

        }

        else {

            if (chatArrayList.get(i).getSpecialmsg().equals("1")){

                viewHolder.recieve_layout.setVisibility(View.GONE);
                viewHolder.send_layout.setVisibility(View.GONE);
                viewHolder.special_layout_send_layout.setVisibility(View.GONE);
                viewHolder.special_layout_recieve_layout.setVisibility(View.VISIBLE);


            }
            else {
                viewHolder.recieve_layout.setVisibility(View.VISIBLE);
                viewHolder.send_layout.setVisibility(View.GONE);
                viewHolder.special_layout_send_layout.setVisibility(View.GONE);
                viewHolder.special_layout_recieve_layout.setVisibility(View.GONE);

            }
        }

    }


    private void scroller(){

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                Log.e("scroll"," "+dx+" "+dy);

                totalItemCount = mLinearLayoutManager.getItemCount();
                Integer childCount=mLinearLayoutManager.getChildCount();


                lastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();

                Integer firstvisibleItem=mLinearLayoutManager.findFirstVisibleItemPosition();

                Log.e("loading",""+totalItemCount+" "+firstvisibleItem+"  "+lastVisibleItem);

                if (!isLoading && !islastPage){
                    if ((childCount+firstvisibleItem)>=totalItemCount&&firstvisibleItem>=0) {

                        Log.e("more", "small");

                        setLoaded();
                    }

                }
                else{

                    Log.e("more","more");
                }
                Log.e("totola",""+totalItemCount);
            }

        });


    }

    public void setOnLoadMoreListener( OnLoadMoreListener mOnLoadMoreListener) {

        this.mOnLoadMoreListener = mOnLoadMoreListener;
    }

    public void setLoaded() {
        isLoading = false;
    }




    @Override
    public int getItemCount() {
        return chatArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView text_message_body_recieved,text_message_time_recieved;

        TextView text_message_body_send,text_message_time_send,text_msg_special_send,text_msg_special_recieve,text_message_time_special_recieve,text_message_time_special_send;

        RelativeLayout recieve_layout,send_layout,special_layout_recieve_layout,special_layout_send_layout;

        LinearLayout butn_layout_send,butn_layout_recieve;

        Button butn_accept_recieve,butn_decline_recieve;




        ViewHolder(View itemView) {
            super(itemView);

            text_message_body_send=(TextView)itemView.findViewById(R.id.text_message_body);
            text_message_time_send=(TextView)itemView.findViewById(R.id.text_message_time);
            send_layout=(RelativeLayout)itemView.findViewById(R.id.send_layout);


            text_message_body_recieved=(TextView)itemView.findViewById(R.id.text_message_body_recieved);
            text_message_body_recieved.setVisibility(View.VISIBLE);
            text_message_time_recieved=(TextView)itemView.findViewById(R.id.text_message_time_recieved);
            recieve_layout=(RelativeLayout)itemView.findViewById(R.id.recieve_layout);





            special_layout_recieve_layout=(RelativeLayout)itemView.findViewById(R.id.special_layout_recieve_layout);
            butn_layout_recieve=(LinearLayout)itemView.findViewById(R.id.butn_layout_recieve) ;
            text_msg_special_recieve=(TextView)itemView.findViewById(R.id.text_msg_special_recieve);
            text_message_time_special_recieve=(TextView)itemView.findViewById(R.id.text_message_time_special_recieve);
           // butn_decline_recieve=(Button)itemView.findViewById(R.id.butn_decline_recieve) ;




            special_layout_send_layout=(RelativeLayout)itemView.findViewById(R.id.special_layout_send_layout);
            text_msg_special_send=(TextView)itemView.findViewById(R.id.text_msg_special_send);
            text_message_time_special_send=(TextView)itemView.findViewById(R.id.text_message_time_special_send);
           // butn_accept_recieve=(Button)itemView.findViewById(R.id.butn_accept_recieve);
           // butn_layout_send=(LinearLayout) itemView.findViewById(R.id.butn_layout_send);



        }


    }

    public  void refresh(ArrayList<Chat>chatArrayList,Integer pos){
        this.chatArrayList = chatArrayList;
        recyclerView.smoothScrollToPosition(pos);
        notifyDataSetChanged();

    }

    public void hideview(Integer pos){
       // recyclerView.



    }
}
