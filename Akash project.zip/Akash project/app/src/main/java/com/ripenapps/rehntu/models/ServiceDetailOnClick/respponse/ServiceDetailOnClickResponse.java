package com.ripenapps.rehntu.models.ServiceDetailOnClick.respponse;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class ServiceDetailOnClickResponse extends BaseResponse {



    @SerializedName("result")
    private ServiceDetailOnClickResult result;


    public ServiceDetailOnClickResult getResult() {
        return result;
    }

    public void setResult(ServiceDetailOnClickResult result) {
        this.result = result;
    }
}
