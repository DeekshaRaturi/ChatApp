package com.ripenapps.rehntu.models.acceptDeclineChat.response;

import com.google.gson.annotations.SerializedName;

public class AcceptDeclineResult {




    public Double getRent() {
        return rent;
    }

    public void setRent(Double rent) {
        this.rent = rent;
    }

    @SerializedName("rent")
    private Double rent;

   /* public Double getRent() {
        return rent;
    }

    public void setRent(Double rent) {
        this.rent = rent;
    }



    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @SerializedName("price")
    private int price;*/
}
