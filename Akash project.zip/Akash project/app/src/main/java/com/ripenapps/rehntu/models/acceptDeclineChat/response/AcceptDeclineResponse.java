package com.ripenapps.rehntu.models.acceptDeclineChat.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class AcceptDeclineResponse extends BaseResponse {

    @SerializedName("result")
    private Rent rent;

    public Rent getRent() {
        return rent;
    }

    public void setRent(Rent rent) {
        this.rent = rent;
    }
}
