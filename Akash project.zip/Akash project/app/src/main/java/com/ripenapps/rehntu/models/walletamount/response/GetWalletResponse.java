package com.ripenapps.rehntu.models.walletamount.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;
import com.ripenapps.rehntu.models.showBooking.response.ShowBookingResult;

public class GetWalletResponse  extends BaseResponse {

    public GetWalletResult getGetWalletResult() {
        return getWalletResult;
    }

    public void setGetWalletResult(GetWalletResult getWalletResult) {
        this.getWalletResult = getWalletResult;
    }

    @SerializedName("result")
    private GetWalletResult getWalletResult;

//    public Integer getCode() {
//        return code;
//    }
//
//    public void setCode(Integer code) {
//        this.code = code;
//    }

//    @SerializedName("code")
//    private Integer code;

}
