package com.ripenapps.rehntu.models.getFeedback.response;

import com.google.gson.annotations.SerializedName;

public class Feedback {


    @SerializedName("_id")
    private String id;
    @SerializedName("service_id")
    private String service_id;
    @SerializedName("rating")
    private String rating;
    @SerializedName("review")
    private String review;
    @SerializedName("reviewed_At")
    private String reviewed_At;
    @SerializedName("user")
    UserDetail userDetail;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getReviewed_At() {
        return reviewed_At;
    }

    public void setReviewed_At(String reviewed_At) {
        this.reviewed_At = reviewed_At;
    }

    public UserDetail getUserDetail() {
        return userDetail;
    }

    public void setUserDetail(UserDetail userDetail) {
        this.userDetail = userDetail;
    }
}
