package com.ripenapps.rehntu.my_util;




import com.ripenapps.rehntu.models.ServiceDetailOnClick.respponse.ServiceDetailOnClickWrapper;
import com.ripenapps.rehntu.models.map.reguest.MapRequest;
import com.ripenapps.rehntu.models.map.response.MapResponseResult;
import com.ripenapps.rehntu.models.map.response.Service;

import java.util.ArrayList;
import java.util.List;

public class RhentoSingleton {
        // static variable single_instance of type Singleton
        private static RhentoSingleton single_instance = null;
        String name="";
        String email="";
        String mobile_num="";
        String password="";
        String social_id="";
        String login_type="";
        String countryCodeAndroid="+1";


    private ArrayList<Service> serviceArrayList=new ArrayList<>();

    private ArrayList<String> serviceImagesPath = new ArrayList<>();
    private ArrayList<String> imageurl = new ArrayList<>();

    public ArrayList<String> getImageurl() {
        return imageurl;
    }

    public void setImageurl(ArrayList<String> imageurl) {
        this.imageurl = imageurl;
    }

    public ArrayList<String> getServiceImagesPath() {
        return serviceImagesPath;
    }

    public void setServiceImagesPath(ArrayList<String> serviceImagesPath) {
        this.serviceImagesPath = serviceImagesPath;
    }

    public ArrayList<Service> getServiceArrayList() {
        return serviceArrayList;
    }

    public void setServiceArrayList(ArrayList<Service> serviceArrayList) {
        this.serviceArrayList = serviceArrayList;
    }

    public List<String> getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(List<String> selectedItem) {
        this.selectedItem = selectedItem;
    }

    List<String> selectedItem=new ArrayList<>();
    private List<UploadedImage> uploadedImages;

    public MapRequest mapRequest= new MapRequest();

    public MapRequest getMapRequest() {
        return mapRequest;
    }

    public void setMapRequest(MapRequest mapRequest) {
        this.mapRequest = mapRequest;
    }

    public MapResponseResult responseResult= new MapResponseResult();



    public MapResponseResult getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(MapResponseResult responseResult) {
        this.responseResult = responseResult;
    }

    public RhentoSingleton()
    {
        uploadedImages = new ArrayList<>();
    }

    public static RhentoSingleton getSingle_instance() {
        return single_instance;
    }

    public static void setSingle_instance(RhentoSingleton single_instance) {
        RhentoSingleton.single_instance = single_instance;
    }

    public List<UploadedImage> getUploadedImages() {
        return uploadedImages;
    }
    public void setUpLoadedImage(List<UploadedImage> uploadedImageList){
         uploadedImages=uploadedImageList;
    }

    public void setUploadedImages(List<UploadedImage> uploadedImages) {
        this.uploadedImages = uploadedImages;
    }

    // static method to create instance of Singleton class
        public static RhentoSingleton getInstance()
        {
            if (single_instance == null)
                single_instance = new RhentoSingleton();

            return single_instance;
        }

        public ServiceDetailOnClickWrapper wrapper= new ServiceDetailOnClickWrapper();

    public ServiceDetailOnClickWrapper getWrapper() {
        return wrapper;
    }

    public void setWrapper(ServiceDetailOnClickWrapper wrapper) {
        this.wrapper = wrapper;
    }

    public String getName() {
        return name;
    }

    public String getCountryCodeAndroid() {
        return countryCodeAndroid;
    }

    public void setCountryCodeAndroid(String countryCodeAndroid) {
        this.countryCodeAndroid = countryCodeAndroid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile_num() {
        return mobile_num;
    }

    public void setMobile_num(String mobile_num) {
        this.mobile_num = mobile_num;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSocial_id() {
        return social_id;
    }

    public void setSocial_id(String social_id) {
        this.social_id = social_id;
    }

    public String getLogin_type() {
        return login_type;
    }

    public void setLogin_type(String login_type) {
        this.login_type = login_type;
    }


}
