package com.ripenapps.rehntu.models.category.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class CategoryResponse extends BaseResponse {

    @SerializedName("result")
    private CategoryResponseResult result;

    public CategoryResponseResult getResult() {
        return result;
    }

    public void setResult(CategoryResponseResult result) {
        this.result = result;
    }
}
