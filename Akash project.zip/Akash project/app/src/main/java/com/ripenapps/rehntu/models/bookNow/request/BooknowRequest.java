package com.ripenapps.rehntu.models.bookNow.request;

import com.google.gson.annotations.SerializedName;

public class BooknowRequest {


    @SerializedName("service_id")
    private String service_id;

    @SerializedName("buyer_id")
    private String buyer_id;

    @SerializedName("service_provider_id")
    private String service_provider_id;

    @SerializedName("price")
    private String price;

    @SerializedName("service_type")
    private String service_type;

    @SerializedName("fullAddress")
    private String fullAddress;

    @SerializedName("city")
    private String city;

    @SerializedName("pincode")
    private String pincode;

    public String getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    @SerializedName("long")
    private String longtitude;

    @SerializedName("lat")
    private String lat;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @SerializedName("time")
    private String time;

    public String getRate_type() {
        return rate_type;
    }

    public void setRate_type(String rate_type) {
        this.rate_type = rate_type;
    }

    @SerializedName("rate_type")
    private String rate_type;

    public String getSecurity_deposite() {
        return security_deposite;
    }

    public void setSecurity_deposite(String security_deposite) {
        this.security_deposite = security_deposite;
    }

    @SerializedName("security_deposite")
    private String security_deposite;



    public String getService_id() {
        return service_id;
    }

    public void setService_id(String service_id) {
        this.service_id = service_id;
    }

    public String getBuyer_id() {
        return buyer_id;
    }

    public void setBuyer_id(String buyer_id) {
        this.buyer_id = buyer_id;
    }

    public String getService_provider_id() {
        return service_provider_id;
    }

    public void setService_provider_id(String service_provider_id) {
        this.service_provider_id = service_provider_id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getBuyer_name() {
        return buyer_name;
    }

    public void setBuyer_name(String buyer_name) {
        this.buyer_name = buyer_name;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public String getService_provider_name() {
        return service_provider_name;
    }

    public void setService_provider_name(String service_provider_name) {
        this.service_provider_name = service_provider_name;
    }

    @SerializedName("to")
    private String to;

    @SerializedName("from")
    private String from;

    @SerializedName("transaction_id")
    private String transaction_id;

    @SerializedName("buyer_name")
    private String buyer_name;

    @SerializedName("service_name")
    private String service_name;

    @SerializedName("service_provider_name")
    private String service_provider_name;



}
