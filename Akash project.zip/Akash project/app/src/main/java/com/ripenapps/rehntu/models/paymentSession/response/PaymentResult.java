package com.ripenapps.rehntu.models.paymentSession.response;

import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

public class PaymentResult {

    public String getPaymentSession() {
        return paymentSession;
    }

    public void setPaymentSession(String paymentSession) {
        this.paymentSession = paymentSession;
    }

    @SerializedName("paymentSession")
    private String paymentSession;

}
