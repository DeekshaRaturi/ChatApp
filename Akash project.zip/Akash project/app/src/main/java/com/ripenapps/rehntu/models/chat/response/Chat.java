package com.ripenapps.rehntu.models.chat.response;

public class Chat {

    private String msg_recieve;
    private String msg_recieve_time;
    private String specialmsg;
    private Integer status;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    private String price;

    public String getSpecialmsg() {
        return specialmsg;
    }

    public void setSpecialmsg(String specialmsg) {
        this.specialmsg = specialmsg;
    }




    public Chat(String msg_time,String msg_send,Integer status,String specialmsg,String price){


        this.msg_recieve=msg_send;
        this.msg_recieve_time=msg_time;
        this.status=status;
        this.specialmsg=specialmsg;
        this.price=price;


    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getMsg_recieve() {
        return msg_recieve;
    }

    public void setMsg_recieve(String msg_recieve) {
        this.msg_recieve = msg_recieve;
    }

    public String getMsg_recieve_time() {
        return msg_recieve_time;
    }

    public void setMsg_recieve_time(String msg_recieve_time) {
        this.msg_recieve_time = msg_recieve_time;
    }


}
