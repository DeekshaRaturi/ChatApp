package com.ripenapps.rehntu.models.homeListingDetail.request;

import com.google.gson.annotations.SerializedName;

public class HomeListingDetailRequest {

    @SerializedName("services_type")

    private String servicesType;

    @SerializedName("user_id")
    private String userId;

    @SerializedName("service_id")
    private String serviceId ;

    public void setServicesType(String servicesType) {
        this.servicesType = servicesType;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public void setServicesType() {
    }
}
