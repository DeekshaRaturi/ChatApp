package com.ripenapps.rehntu.models.map.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Service {
    @SerializedName("_id")
    @Expose
    private String id = "";

    @SerializedName("address")
    @Expose
    private Address address = new Address();

    @SerializedName("subcategoryId")
    @Expose
    private ArrayList<String> subcategoryIds = new ArrayList<>();

    @SerializedName("is_deleted")
    @Expose
    private boolean isDeleted = false;

    @SerializedName("images")
    @Expose
    private ArrayList<String> imageArrayList = new ArrayList<>();

    @SerializedName("user_id")
    @Expose
    private String userId = "";

    @SerializedName("name")
    @Expose
    private String name = "";

    @SerializedName("categoryId")
    @Expose
    private String categoryId = "";

    @SerializedName("basePrice")
    @Expose
    private String basePrice = "";

    @SerializedName("description")
    @Expose
    private String description = "";

    @SerializedName("created_at")
    @Expose
    private String createdAt = "";

    @SerializedName("distance")
    @Expose
    private String distance = "";

    @SerializedName("avg_rating")
    @Expose
    private String avgRating = "0.0";

    @SerializedName("ratePerHour")
    private String ratePerHour="0";


    @SerializedName("yearPurchase")
    private String yearPurchase="";


    @SerializedName("securityDeposite")
    private String securityDeposite="";

    @SerializedName("services_type")
    private String services_type="";


    public String getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(String ratePerHour) {
        this.ratePerHour = ratePerHour;
    }

    public String getYearPurchase() {
        return yearPurchase;
    }

    public void setYearPurchase(String yearPurchase) {
        this.yearPurchase = yearPurchase;
    }

    public String getSecurityDeposite() {
        return securityDeposite;
    }

    public void setSecurityDeposite(String securityDeposite) {
        this.securityDeposite = securityDeposite;
    }

    public String getServices_type() {
        return services_type;
    }

    public void setServices_type(String services_type) {
        this.services_type = services_type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<String> getSubcategoryIds() {
        return subcategoryIds;
    }

    public void setSubcategoryIds(ArrayList<String> subcategoryIds) {
        this.subcategoryIds = subcategoryIds;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public ArrayList<String> getImageArrayList() {
        return imageArrayList;
    }

    public void setImageArrayList(ArrayList<String> imageArrayList) {
        this.imageArrayList = imageArrayList;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(String basePrice) {
        this.basePrice = basePrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(String avgRating) {
        this.avgRating = avgRating;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
