package com.ripenapps.rehntu.models.transaction.response;

public class Transaction {

    private String servicename;
    private String location;
    private Boolean isexpanded;

    public String getService_location() {
        return service_location;
    }

    public void setService_location(String service_location) {
        this.service_location = service_location;
    }

    private String service_location;

    public String getProvidername() {
        return providername;
    }

    public void setProvidername(String providername) {
        this.providername = providername;
    }

    private String providername;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    private Integer status;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    private Integer count;


    public Boolean getIsexpanded() {
        return isexpanded;
    }

    public void setIsexpanded(Boolean isexpanded) {
        this.isexpanded = isexpanded;
    }



    public Transaction(String servicename,String location,Boolean isexpanded,Integer status,Integer count,String providername){

        this.servicename=servicename;
        this.isexpanded=isexpanded;
        this.location=location;
        this.status=status;
        this.count=count;
        this.providername=providername;
        this.service_location=service_location;

    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }





}
