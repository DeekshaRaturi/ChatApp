package com.ripenapps.rehntu.models.login.response;

import com.google.gson.annotations.SerializedName;

public class LoginResponseWrapper {

    @SerializedName("data")
    private LoginResponse response;


    public LoginResponse getResponse() {
        return response;
    }

    public void setResponse(LoginResponse response) {
        this.response = response;
    }
}
