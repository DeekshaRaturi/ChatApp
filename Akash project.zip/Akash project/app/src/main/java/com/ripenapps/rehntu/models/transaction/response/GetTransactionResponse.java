package com.ripenapps.rehntu.models.transaction.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;


public class GetTransactionResponse extends BaseResponse {

    @SerializedName("result")
    private GetTransactionResult getTransactionResult;


    public GetTransactionResult getGetTransactionResult() {

        return getTransactionResult;
    }

    public void setGetTransactionResult(GetTransactionResult getTransactionResult) {
        this.getTransactionResult = getTransactionResult;
    }

    private void SetResult(GetTransactionResult getTransactionResult){
        this.getTransactionResult=getTransactionResult;



    }


}
