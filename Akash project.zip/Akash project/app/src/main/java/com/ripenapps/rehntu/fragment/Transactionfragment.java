package com.ripenapps.rehntu.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.adapter.TabAdapter;
import com.ripenapps.rehntu.adapter.TransactionAdapter;
import com.ripenapps.rehntu.models.transaction.request.GetTransactionRequest;
import com.ripenapps.rehntu.models.transaction.response.GetTransactionResponseWrapper;
import com.ripenapps.rehntu.models.transaction.response.GetTransactionResult;
import com.ripenapps.rehntu.models.transaction.response.Transaction;
import com.ripenapps.rehntu.my_screen.OnLoadMoreListener;
import com.ripenapps.rehntu.my_util.CommonUtils;
import com.ripenapps.rehntu.my_util.DialogBoxs;
import com.ripenapps.rehntu.preferences.PrefEntity;
import com.ripenapps.rehntu.preferences.Preferences;
import com.ripenapps.rehntu.volley.APIUtility;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import static android.nfc.tech.MifareUltralight.PAGE_SIZE;
import static com.facebook.FacebookSdk.getApplicationContext;

public class Transactionfragment extends Fragment implements View.OnClickListener {
    View view;
    APIUtility apiUtility;
    private RecyclerView recyclerView;
    private ArrayList<Transaction>transactionlist=new ArrayList<>();
    private TransactionAdapter transactionAdapter;
    private Context context;
    private Button butn_book_now;
    private RecyclerView butn_book_details_recycler;
   // private ImageView filter;
    private String user_id;
    private ProgressBar progressBar;
    private String serviceId;
    private String servicename,buyer_id,is_buyer;
    private String servicetype,transaction_id,id,serviceprovidername,service_providerId,buyername;
    private DialogBoxs dialogBoxs;
    private int status;
    private TextView no_datafound;
    private SwipeRefreshLayout  swiper;
    private ArrayList<String>service_type_list=new ArrayList<>();
    private ArrayList<String>transaction_id_list=new ArrayList<>();
    private ArrayList<String>serviceprovidername_list=new ArrayList<>();
    private ArrayList<String>buyer_id_list=new ArrayList<>();
    private ArrayList<String>servicename_list=new ArrayList<>();
    private ArrayList<String>serviceId_list=new ArrayList<>();
    private ArrayList<String>id_list=new ArrayList<>();
    private ArrayList<String>is_buyer_list=new ArrayList<>();
    private ArrayList<Integer>status_list=new ArrayList<>();
    private ArrayList<Integer>price_list=new ArrayList<>();
    private ArrayList<String>Serviceproviderid_list=new ArrayList<>();
    private ArrayList<String>Buyer_name=new ArrayList<>();
    private final int interval = 1000; // 1 Second
    private Timer mTimer1;
    private TimerTask mTt1;
    private Handler mTimerHandler = new Handler();
    private Integer unseen_Count;
    private ArrayList<Integer>count_list=new ArrayList<>();
    private Boolean aBoolean=false;
    private LinearLayoutManager layoutManager;
    private Integer currentPage = 1;
    private Boolean NextPage=false;
    private  Integer firstVisiblesItems = 0;
    private  Integer lastVisiblesItems=0;
    private  Integer totalPages = 0 ;// get your total pages from web service first response

    private  Boolean canLoadMoreData = true ;
    private  Integer visibleItemCount = 0;
    private  Integer totalItemCount = 0;
    private  Integer PAGE_SIZE=10;

    private Integer PAGE_STARTED=1;
    private Integer PAGE_REFRESH=1;

    private TabAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;



    private Integer price;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_transection, container, false);
        apiUtility = new APIUtility(getActivity());
        InitView();
        return view;
    }

    @SuppressLint("ResourceType")
    private void InitView() {
        recyclerView=(RecyclerView)view.findViewById(R.id.transaction_recyclerview);

        viewPager = (ViewPager)view.findViewById(R.id.viewPager);
        tabLayout = (TabLayout)view.findViewById(R.id.tabLayout);

        adapter = new TabAdapter(getFragmentManager());
        adapter.addFragment(new FragmentOne(), "Tab 1");
        adapter.addFragment(new FragmentTwo(), "Tab 2");
        adapter.addFragment(new FragmentThree(), "Tab 3");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);


        tabLayout.getTabAt(0).setText("All");
        tabLayout.getTabAt(1).setText("Buy");
        tabLayout.getTabAt(2).setText("Sell");


        no_datafound=(TextView)view.findViewById(R.id.no_datafound) ;

        user_id= Preferences.getPreference(getApplicationContext(), PrefEntity.USERID);

        dialogBoxs=new DialogBoxs(getContext());

    }


    @Override
    public void onResume() {
        super.onResume();

    }





    @Override
    public void onClick(View v) {
        switch (v.getId()){




        }


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

//        if (requestCode==1200){
//
//            if (resultCode== Activity.RESULT_OK){
//
//                aBoolean=true;
//              //  transactionlist.clear();
//                count_list.clear();
//                transactionDetails(user_id);
//            }
//        }
    }


}
