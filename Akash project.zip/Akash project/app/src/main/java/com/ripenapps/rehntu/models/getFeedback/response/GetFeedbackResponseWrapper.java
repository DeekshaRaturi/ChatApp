package com.ripenapps.rehntu.models.getFeedback.response;

import com.google.gson.annotations.SerializedName;

public class GetFeedbackResponseWrapper {

    @SerializedName("data")
    private GetFeedbackResponse response;

    public GetFeedbackResponse getResponse() {
        return response;
    }

    public void setResponse(GetFeedbackResponse response) {
        this.response = response;
    }
}
