package com.ripenapps.rehntu.models.bankDetails.response;

import com.google.gson.annotations.SerializedName;

public class AccountDetails {

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getAccount_holder_name() {
        return account_holder_name;
    }

    public void setAccount_holder_name(String account_holder_name) {
        this.account_holder_name = account_holder_name;
    }

    public String getAccount_number() {
        return account_number;
    }

    public void setAccount_number(String account_number) {
        this.account_number = account_number;
    }

    public String getIfsc_code() {
        return ifsc_code;
    }

    public void setIfsc_code(String ifsc_code) {
        this.ifsc_code = ifsc_code;
    }

    public String getBranch_name() {
        return branch_name;
    }

    public void setBranch_name(String branch_name) {
        this.branch_name = branch_name;
    }

    @SerializedName("bank_name")
    private String bank_name;

    @SerializedName("account_holder_name")
    private String account_holder_name;

    @SerializedName("account_number")
    private String account_number;

    @SerializedName("ifsc_code")
    private String ifsc_code;

    @SerializedName("branch_name")
    private String branch_name;


}
