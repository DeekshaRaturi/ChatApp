package com.ripenapps.rehntu.models.category.request;

import com.google.gson.annotations.SerializedName;

public class CategoryRequest {


    @SerializedName("user_id")
    private String userId;

    @SerializedName("service_type")
    private String serviceType;

    @SerializedName("text")
    private String text;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
