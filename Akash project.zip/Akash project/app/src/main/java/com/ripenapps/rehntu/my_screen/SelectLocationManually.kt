package com.ripenapps.rehntu.my_screen

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.net.Uri
import android.provider.Settings
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.CardView
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast

import com.google.android.gms.common.GooglePlayServicesNotAvailableException
import com.google.android.gms.common.GooglePlayServicesRepairableException
import com.google.android.gms.location.places.ui.PlaceAutocomplete
import com.google.gson.GsonBuilder
import com.ripenapps.rehntu.BuildConfig
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.geo.GeoCoder
import com.ripenapps.rehntu.my_util.GPSTracker
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volleyMultipart.RetrofitClient
import com.ripenapps.rehntu.volleyMultipart.RetrofitInterface

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*

class SelectLocationManually : BaseActivity(), View.OnClickListener {
    private var back: ImageView? = null
    private var title: AppCompatTextView? = null
    private var cardViewSearchLocation: CardView? = null
    private var cardViewAllowAutoDetectLocation: CardView? = null
    private val PLACE_AUTOCOMPLETE_REQUEST_CODE = 1
    private val PLACE_AUTOCOMPLETE_REQUEST_CODE12 = 12
    private var gpsTracker: GPSTracker? = null
    private var lat: Double = 0.toDouble()
    private var lng: Double = 0.toDouble()
    private var pinCode:Int?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_select_location_manually)
        cardViewAllowAutoDetectLocation = findViewById(R.id.allow_auto_detect)
        cardViewSearchLocation = findViewById(R.id.search_location)
        cardViewSearchLocation!!.setOnClickListener(this)
        cardViewAllowAutoDetectLocation!!.setOnClickListener(this)
        initViews()
    }

    private fun initViews() {
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title!!.text = "Search Location"
        back!!.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.back -> finish()
           R.id.search_location -> openPlacesAutocompleteFragment()


            R.id.allow_auto_detect -> allowAutoDetect()
        }
    }

    private fun allowAutoDetect() {

        checkMyPermission()
        gpsTracker = GPSTracker(this@SelectLocationManually)
        lat = gpsTracker!!.latitude
        lng = gpsTracker!!.longitude

        Log.e("gps", " $lat $lng")

        if (lat == 0.0 && lng == 0.0) {

            gpsTracker!!.location
            Log.e("gpstracker"," "+gpsTracker!!.location)
            lat = gpsTracker!!.latitude
            lng = gpsTracker!!.longitude



            Toast.makeText(this, "Location Error ! Try Again", Toast.LENGTH_SHORT).show()
            //            Preferences.setPreference(getApplicationContext(), PrefEntity.LAT, String.valueOf(lat));
            //            Preferences.setPreference(getApplicationContext(), PrefEntity.LONG, String.valueOf(lng));

        } else {
            //            Preferences.setPreference(getApplicationContext(), PrefEntity.LAT, String.valueOf(lat));
            //            Preferences.setPreference(getApplicationContext(), PrefEntity.LONG, String.valueOf(lng));

            getAddressFromGeoApi(this@SelectLocationManually, lat, lng)



        }


    }

    private fun openPlacesAutocompleteFragment() {
        try {
            val intent = PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(this)
            startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE)
        } catch (e: GooglePlayServicesRepairableException) {
            // TODO: Handle the error.
        } catch (e: GooglePlayServicesNotAvailableException) {
            // TODO: Handle the error.
        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                  val place = PlaceAutocomplete.getPlace(this, data!!)
                Log.e("place",""+place.address+" "+place.latLng.latitude+" "+place.latLng.longitude+" "+place.name)

                  if (intent.hasExtra("activityName")) {
                    val intent = Intent()
                    Preferences.setPreference(applicationContext, PrefEntity.LAT1, place.latLng.latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG1, place.latLng.longitude.toString())
                    intent.putExtra("fullAdress", place.address)
                      intent.putExtra("lat",place.latLng.latitude)
                      intent.putExtra("lng",place.latLng.longitude)

                      Log.e("req","activity")

                    setResult(Activity.RESULT_OK, intent)
                    finish()
                } else if (intent.hasExtra("requestFrom")) {
                    val intent = Intent()
                    Preferences.setPreference(applicationContext, PrefEntity.LAT, place.latLng.latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, place.latLng.longitude.toString())
                    intent.putExtra("fullAdress", place.address)
                      intent.putExtra("lat",place.latLng.latitude)
                      intent.putExtra("lng",place.latLng.longitude)
                      intent.putExtra("city",place.name)

                    Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, place.address.toString())
                    Log.e("exampl"," "+place.address+" "+place)
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                } else {
                    Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, place.address.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LAT, place.latLng.latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, place.latLng.longitude.toString())
                    val intent = Intent(baseContext, DashBoardActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)
                }


            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                val status = PlaceAutocomplete.getStatus(this, data!!)
                Toast.makeText(this@SelectLocationManually, "locationError", Toast.LENGTH_SHORT).show()
            } else if (resultCode == Activity.RESULT_CANCELED) {
            }
        }
    }


    private fun getAddressFromGeoApi(context: Context, latitude: Double, longitude: Double) {
        val BASE_URL_GEO = "https://maps.googleapis.com/maps/api/geocode/"

        val retrofit = Retrofit.Builder().baseUrl(BASE_URL_GEO).addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create())).client(RetrofitClient.getOkHttpClient()).build()
        val retrofitInterface = retrofit.create(RetrofitInterface::class.java)


        retrofitInterface.getLocaationwithCoordinates(latitude.toString() + "," + longitude, context.resources.getString(R.string.geo_coder_Api_key)).enqueue(object : Callback<GeoCoder> {
            override fun onResponse(call: Call<GeoCoder>, response: Response<GeoCoder>) {
                var address = ""
                var postal=" "
                var city=""
                var lat:Double?=null
                var lng:Double?=null

                var geocoder = Geocoder(context, Locale.getDefault());
                Log.e("geocoder"," "+geocoder)
                try {
                   // address = response.body()!!.getResults()[3].getAddressComponents()[0].longName

                    if (geocoder!=null) {

                       var addressList = geocoder.getFromLocation(latitude, longitude, 1);

                      var  addresses = addressList.get(0)
                        address=addresses.getAddressLine(0)
                        postal=addresses.postalCode
                        city=addresses.locality
                        lat=addresses?.latitude
                        lng=addresses?.longitude
                        Log.e("postal",""+postal+" "+city+" "+lat+" "+ lng)



                    }

                } catch (e: Exception) {
                    e.printStackTrace()


                    var addressList = geocoder.getFromLocation(latitude, longitude, 1);

                    var  addresses = addressList.get(0)
                    postal=addresses.postalCode
                    city=addresses.locality
                    lat=addresses?.latitude
                    lng=addresses?.longitude
                    Log.e("postal1",""+postal+" "+city+" "+lat+" "+ lng)


                    //address = response.body()!!.getResults()[1].getAddressComponents()[0].longName
                    Log.e("exw",""+e.message+" "+e.cause)


                }

                if (intent.hasExtra("activityName")) {
                    Log.e("activity","name")
                    val intent = Intent()
                    Preferences.setPreference(applicationContext, PrefEntity.LAT1, latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG1, longitude.toString())
                    intent.putExtra("fullAdress", address)
                    intent.putExtra("postal",postal)
                    intent.putExtra("city",city)
                    intent.putExtra("lat",latitude)
                    intent.putExtra("long",longitude)

                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }
                else if (intent.hasExtra("requestFrom")) {
                    Log.e("request","name")

                    val intent = Intent()
                    Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                    Preferences.setPreference(applicationContext, PrefEntity.LAT, latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, longitude.toString())
                    intent.putExtra("fullAdress", address)
                    intent.putExtra("postal",postal)
                    intent.putExtra("city",city)
                    intent.putExtra("lat",latitude)
                    intent.putExtra("long",longitude)

                    Preferences.setPreference(applicationContext, PrefEntity.LAT, latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, longitude.toString())
                    setResult(Activity.RESULT_OK, intent)
                    finish()

                } else {
                    Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                    Preferences.setPreference(applicationContext, PrefEntity.LAT, latitude.toString())
                    Preferences.setPreference(applicationContext, PrefEntity.LONG, longitude.toString())
                    Preferences.setPreference(applicationContext,PrefEntity.CITY,city)
                    Preferences.setPreference(applicationContext,PrefEntity.POSTAL,postal)
                    val intent = Intent(baseContext, DashBoardActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)
                }


            }

            override fun onFailure(call: Call<GeoCoder>, throwable: Throwable) {

            }
        })
    }


    private fun checkMyPermission() {
        if (ContextCompat.checkSelfPermission(this@SelectLocationManually, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this@SelectLocationManually, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            1 -> if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
            } else {

                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + BuildConfig.APPLICATION_ID))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                this.startActivity(intent)


            }
        }
    }


}
