package com.ripenapps.rehntu.models.sendDate.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class SendDateResponse extends BaseResponse {

    @SerializedName("result")
    private SendDateResult sendDateResult;


    public SendDateResult getSendDateResult() {
        return sendDateResult;
    }

    public void setSendDateResult(SendDateResult sendDateResult) {
        this.sendDateResult = sendDateResult;
    }


}
