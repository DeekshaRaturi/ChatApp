package com.ripenapps.rehntu.adapter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.ListFragment;
import com.ripenapps.rehntu.models.map.response.Service;
import com.ripenapps.rehntu.my_screen.OnLoadMoreListener;
import com.ripenapps.rehntu.my_screen.ServiceAndProductDetailActivity;


import java.text.DecimalFormat;
import java.util.ArrayList;


public class MapListAdapter extends RecyclerView.Adapter<MapListAdapter.ViewHolder> {

    private ListFragment mContext;
    private ArrayList<Service> mapServiceList;
    DecimalFormat format = new DecimalFormat("##.##");
    private RecyclerView recyclerView;
    private OnLoadMoreListener mOnLoadMoreListener = null;
    private LinearLayoutManager mLinearLayoutManager;
    private Boolean isLoading = false;

    private Integer visibleThreshold = 1;

    private Integer lastVisibleItem=0;
    private Integer totalItemCount =0;




    public MapListAdapter(ArrayList<Service> streetList, ListFragment mContext,RecyclerView recyclerView) {
        this.mContext = mContext;
        this.mapServiceList = streetList;
        this.recyclerView=recyclerView;

          mLinearLayoutManager=new LinearLayoutManager(recyclerView.getContext());

        Log.e("recyclerview",""+recyclerView+" "+mLinearLayoutManager);

        scroller();

    }

    @Override
    public MapListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MapListAdapter.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.maplist, parent, false));
    }


    private void scroller() {

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                totalItemCount = mLinearLayoutManager.getItemCount();

                lastVisibleItem = mLinearLayoutManager.findLastVisibleItemPosition();

                Log.e("loading",""+totalItemCount+" "+"lastitem"+lastVisibleItem+visibleThreshold);

                if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThreshold )&& dy > 0) {

                    if (mOnLoadMoreListener != null) {

                        mOnLoadMoreListener.onLoadMore();


                    }

                    isLoading = true;

                }

                mLinearLayoutManager.scrollToPosition(totalItemCount);
                Log.e("totola",""+totalItemCount);
            }

        });



    }
    public void setOnLoadMoreListener(OnLoadMoreListener mOnLoadMoreListener ) {

        this.mOnLoadMoreListener = mOnLoadMoreListener;
    }

    public void setLoaded() {
        isLoading = false;
    }


    @Override
    public void onBindViewHolder(final MapListAdapter.ViewHolder holder, final int i) {
        if(mapServiceList.get(i).getServices_type().equals("service")){
        holder.textViewName.setText(mapServiceList.get(i).getName());
        holder.textViewAddress.setText(mapServiceList.get(i).getAddress().getFullAddress());
        if (mapServiceList.get(i).getDistance() != null) {
            holder.textViewDistance.setText(format.format(Double.parseDouble(mapServiceList.get(i).getDistance())) + " miles");

            } else {
            holder.textViewDistance.setText("0.00" + " miles");
            }

        holder.textViewRating.setText(mapServiceList.get(i).getAvgRating());
        holder.textViewPrice.setText(mapServiceList.get(i).getBasePrice() + " +");
        holder.detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(mContext.getActivity(), ServiceAndProductDetailActivity.class);
                intent.putExtra("id",mapServiceList.get(i).getId());
                intent.putExtra("productType","service");
                Log.e("iddd"," "+mapServiceList.get(i).getUserId());
                intent.putExtra("userid",mapServiceList.get(i).getUserId());
                mContext.startActivity(intent);

            }
        });

    }else{
            holder.textViewName.setText(mapServiceList.get(i).getName());
            holder.textViewAddress.setText(mapServiceList.get(i).getAddress().getFullAddress());
            if (mapServiceList.get(i).getDistance() != null) {
                holder.textViewDistance.setText(format.format(Double.parseDouble(mapServiceList.get(i).getDistance())) + " miles");

            } else {
                holder.textViewDistance.setText("0.00" + " miles");
            }

            holder.textViewRating.setText("0.00");
            holder.textViewPrice.setText(mapServiceList.get(i).getRatePerHour() + "/h");
            holder.detail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent= new Intent(mContext.getActivity(), ServiceAndProductDetailActivity.class);
                    intent.putExtra("id",mapServiceList.get(i).getId());
                    intent.putExtra("productType","product");
                    intent.putExtra("userid",mapServiceList.get(i).getUserId());


                    mContext.startActivity(intent);

                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return (mapServiceList.size());
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textViewName, textViewAddress, textViewDistance, textViewRating, textViewPrice;
        private CardView detail;

        public ViewHolder(View itemView) {
            super(itemView);

            textViewName = itemView.findViewById(R.id.tv_name);
            detail = itemView.findViewById(R.id.detail);
            textViewAddress = itemView.findViewById(R.id.tv_address);
            textViewDistance = itemView.findViewById(R.id.tv_distance);
            textViewRating = itemView.findViewById(R.id.tv_rating);
            textViewPrice = itemView.findViewById(R.id.tv_price);
        }


    }


}
