package com.ripenapps.rehntu.models.sendDate.response;

public class SendDateResult {
}
