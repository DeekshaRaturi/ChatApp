package com.ripenapps.rehntu.my_screen

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.support.v7.widget.CardView
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.facebook.appevents.internal.AppEventUtility
import com.google.gson.Gson

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.bookNow.request.BooknowRequest
import com.ripenapps.rehntu.models.bookNow.response.BookNowWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.Constants
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.lang.Exception
import java.net.URISyntaxException
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class ProductBookingActivity : AppCompatActivity(), View.OnClickListener {

    private var img_from: EditText? = null
    private var img_to: EditText? = null
    private var mYear: Int = 0
    private var mMonth: Int = 0
    private var mDay: Int = 0
    private var address_cardview: CardView? = null
    private var txt_address_place: TextView? = null
    private var back: ImageView? = null
    private var title: AppCompatTextView? = null
    private var service_name:String?=null
    private var btn_book_now:Button?=null
    private var apiUtility: APIUtility?=null
    private var context: Context?=null
    private var transaction:String?=null
    private var service_type:String?=null
    private var txt_amount_value:EditText?= null
    private var serviceId:String?=null
    private var user_id:String?=null
    private var day:String?=null
    private var time:String?=null
    private var address:String?=null
    private var city:String?=null
    private var postal:String?=null
    private var lat:String?=null
    private var longitude:String?=null
    private var request=BooknowRequest()
    private var txt_securitydeposit_value:TextView?=null
    private var service_provider_name:String?=null
    private var txt_product_owner:TextView?=null
    private var price:Int?=null
    private var status:String?=null
    private val socket_url = "http://18.216.101.125:3000"
    private var mcontext: Context? = null
    private var mSocket: Socket? = null
    private var currenttime:String?=null
    private var datetime:String?=null
    private var fromdate:Long?=null
    private var securityDeposite:String?=null
    private var rate_type:String?=null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_booking)

        initViews()
    }



    private fun initViews() {


        service_name=intent.getStringExtra("service_name")
        transaction=intent.getStringExtra("transaction")
        service_type=intent.getStringExtra("service_type")
        serviceId=intent.getStringExtra("serviceId")
        user_id=intent.getStringExtra("user_id")
        service_provider_name=intent.getStringExtra("serviceprovidername")
        securityDeposite=intent.getStringExtra("securityDeposite")
        rate_type=intent.getStringExtra("rate_type")

        Log.e("securit",""+securityDeposite)
        setResult(Activity.RESULT_OK)



        img_from = findViewById<View>(R.id.img_from) as EditText
        img_to = findViewById<View>(R.id.img_to) as EditText
        address_cardview = findViewById<View>(R.id.address_cardview) as CardView
        txt_address_place = findViewById<View>(R.id.txt_address_place) as TextView
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        btn_book_now=findViewById(R.id.btn_book_now)as Button

        txt_securitydeposit_value=findViewById(R.id.txt_securitydeposit_value)
        txt_securitydeposit_value?.setText(securityDeposite)
        txt_product_owner=findViewById<TextView>(R.id.txt_product_owner_text)

        txt_product_owner?.setText(service_provider_name)

        txt_amount_value=findViewById(R.id.txt_amount_value)
        context=this

        apiUtility = APIUtility(context)

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        img_from?.setOnClickListener(this)

        img_to?.setOnClickListener(this)
        address_cardview?.setOnClickListener(this)
        back?.setOnClickListener(this)
        btn_book_now?.setOnClickListener(this)
        title!!.text = service_name


        socketConnection()
        socketTestConnection()

        getConvertedTime()

        socketConnected()



    }

    fun getConvertedTime() {

        var currentTime = Calendar.getInstance().getTime()

        var dateFormatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ")

        dateFormatter.setTimeZone(TimeZone.getDefault())
        currenttime = dateFormatter.format(currentTime)


    }

    fun socketConnection() {

        try {
            mSocket = IO.socket(socket_url)


        } catch (e: URISyntaxException) {

        }

        mSocket!!.connect()

    }

    fun socketConnected(){

        mSocket!!.on("connected") {

        }


        mSocket!!.on("socket") { args ->


        }

    }


    private fun socketTestConnection() {


        val jsonObject: JSONObject = JSONObject()

        jsonObject?.put("room", transaction)
        jsonObject?.put("user_id", Preferences.getPreference(this@ProductBookingActivity, PrefEntity.USERID))

        mSocket?.emit("test", jsonObject)


        mSocket?.on("test") { args ->

            val data = args[0] as JSONObject


            if (data.has("user_id")) {

                runOnUiThread(object : Runnable {
                    override fun run() {

                    }

                })

            }

        }

    }


    override fun onClick(v: View) {

        when (v.id) {


            R.id.address_cardview -> {

                val intent = Intent(this@ProductBookingActivity, SelectLocationManually::class.java)
                intent.putExtra("requestFrom", "FILTER")

                startActivityForResult(intent, Constants.REQUESTCODE_1)


            }

            R.id.back -> {
                finish()
                mSocket?.disconnect()
                mSocket?.close()


            }

            R.id.btn_book_now->{

                if(TextUtils.isEmpty(txt_amount_value?.text.toString())||TextUtils.isEmpty(txt_address_place?.text.toString())||TextUtils.isEmpty(img_from?.text.toString())||TextUtils.isEmpty(img_to?.text.toString())){

                    CommonUtils.AlertDialogDefault(context,"","Enter all fields")


                }
                else{
                    Booknow()
                }


            }

            R.id.img_from -> {

                val c = Calendar.getInstance()
                mYear = c.get(Calendar.YEAR)
                mMonth = c.get(Calendar.MONTH)
                mDay = c.get(Calendar.DAY_OF_MONTH)


                val datePickerDialog = DatePickerDialog(this,
                        DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                            val daytime:String = ""+year+"-"+String.format("%02d", (monthOfYear+1))+"-"+String.format("%02d", dayOfMonth)

                            getConvertedTime(daytime)
                            day=datetime

                            var formatter =  SimpleDateFormat("yyyy-MM-dd")
                            var date = formatter!!.parse(daytime)
                            Log.e("Today is ","" +date.getTime())
                            fromdate=date.time




                            img_from!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year) }, mYear, mMonth, mDay)
                datePickerDialog.show()
                datePickerDialog.getDatePicker().minDate=System.currentTimeMillis()-1000
                Log.e("datesys",""+System.currentTimeMillis())



            }

            R.id.img_to -> {

                if (!img_from?.text.toString().equals("")) {


                    val c = Calendar.getInstance()
                    mYear = c.get(Calendar.YEAR)
                    mMonth = c.get(Calendar.MONTH)
                    mDay = c.get(Calendar.DAY_OF_MONTH)


                    val datePickerDialog = DatePickerDialog(this,
                            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                                val daytime: String = "" + year + "-" + String.format("%02d", (monthOfYear + 1)) + "-" + String.format("%02d", dayOfMonth)

                                getConvertedTime(daytime)
                                time = datetime


                                img_to!!.setText(dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year)
                            }, mYear, mMonth, mDay)
                    datePickerDialog.show()
                    datePickerDialog.getDatePicker().minDate = fromdate!!
                }
                else{

                    Toast.makeText(applicationContext,"Please Select from date",Toast.LENGTH_SHORT).show()
                }


            }
        }

    }

    fun getConvertedTime(strDate: String) {

        try {
            val sourceDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd");

            val date: Date = sourceDateFormat.parse(strDate);


            val targetDateFormat: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            datetime=targetDateFormat.format(date)
            Log.e("datetime", " " + targetDateFormat.format(date))

        } catch (e: ParseException) {
            e.printStackTrace();
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        mSocket?.disconnect()
        mSocket?.close()
    }

    fun Booknow(){

        request.buyer_id=Preferences.getPreference(context,PrefEntity.USERID)
        //request.buyer_name=Preferences.getPreference(context,PrefEntity.USER_NAME)
        request.from=day
        request.price=txt_amount_value?.text.toString()
        request.service_id=serviceId
        request.service_provider_id=user_id
        request.rate_type=rate_type
        //request.service_name=service_name
       // request.service_provider_name=service_provider_name
        request.to=time
        request.security_deposite=securityDeposite
//        request.security_deposite=txt_securitydeposit_value?.text.toString()


        request.transaction_id=transaction
        request.service_type=service_type


        var gson=Gson()

        apiUtility?.getBookNow(this@ProductBookingActivity, request, true, object : APIUtility.APIResponseListener<BookNowWrapper> {


            override fun onReceiveResponse(response: BookNowWrapper?) {

                price=response?.response?.getBooknowresult?.price
                var code=response?.response?.getBooknowresult?.status
                status=code.toString()

                Toast.makeText(context,"New booking added",Toast.LENGTH_SHORT).show()

                intent.putExtra("price",price)
                intent.putExtra("status",status)
                intent.putExtra("status",status?.toInt())


                setResult(Activity.RESULT_OK, intent)
                finish()


                val jsonObject1 = JSONObject()

                val object1 = JSONObject()


                try {
                    jsonObject1.put("name", Preferences.getPreference(this@ProductBookingActivity, PrefEntity.USER_NAME))

                    jsonObject1.put("message", "")
                    jsonObject1.put("user_id", Preferences.getPreference(this@ProductBookingActivity, PrefEntity.USERID))
                    jsonObject1.put("service_id", serviceId)
                    jsonObject1.put("service_type", service_type)
                    jsonObject1.put("special_msg", "2")
                    jsonObject1.put("time", currenttime)
                    jsonObject1.put("service_name", service_name)
                    jsonObject1.put("status",status)
                    jsonObject1.put("price",price.toString())

                    object1.put("receiver_id", user_id)

                    object1.put("receiver_name", "rishab")



                }
                catch (e:Exception){


                }
                mSocket?.emit("createMessage", jsonObject1, object1)

            }

            override fun onResponseFailed() {
            }

            override fun onStatusFalse(response: BookNowWrapper?) {
            }

        })


    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == Constants.REQUESTCODE_1) {

            if (resultCode == Activity.RESULT_OK) {
                 address = data!!.getStringExtra("fullAdress")

                 postal=data?.getStringExtra("postal")
                 city=data?.getStringExtra("city")

                Preferences.setPreference(applicationContext, PrefEntity.ADDRESS, address)
                val Address = address
                txt_address_place!!.text = "" + address

                request.longtitude=Preferences.getPreference(context,PrefEntity.LONG)
                request.lat=Preferences.getPreference(context,PrefEntity.LAT)
                if (postal!=null){
                    request.pincode=postal

                }
                else{
                    request.pincode="201303"

                }

                request.city=city
                request.fullAddress=address
            }

        }


    }
}

