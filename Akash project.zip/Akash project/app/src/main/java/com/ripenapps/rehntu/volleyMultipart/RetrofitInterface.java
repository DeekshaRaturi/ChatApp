package com.ripenapps.rehntu.volleyMultipart;

import com.ripenapps.rehntu.models.geo.GeoCoder;
import com.ripenapps.rehntu.models.serviceDetail.response.ServiceDetailResponseWrapper;


import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface RetrofitInterface {
    @POST("add_services")
    Call<ServiceDetailResponseWrapper> uploadMultiFile(@Body RequestBody file);

    @POST("updated_services")
    Call<ServiceDetailResponseWrapper> uploadMultiFile1(@Body RequestBody file);


    @GET("json")
    Call<GeoCoder> getLocaationwithCoordinates(@Query("latlng") String latlng, @Query("key") String key);

}
