package com.ripenapps.rehntu.models.subcategory.response;

import com.google.gson.annotations.SerializedName;

public class SubCategoryResponseWrapper {

    @SerializedName("data")
    private SubCategoryResponse response;

    public SubCategoryResponse getResponse() {
        return response;
    }

    public void setResponse(SubCategoryResponse response) {
        this.response = response;
    }
}
