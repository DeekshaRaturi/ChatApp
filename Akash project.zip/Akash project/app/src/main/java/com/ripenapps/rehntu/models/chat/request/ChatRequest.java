package com.ripenapps.rehntu.models.chat.request;

import com.google.gson.annotations.SerializedName;

public class ChatRequest

{
    @SerializedName("user_id")
    private String user_id;

    @SerializedName("receiver_id")
    private String receiver_id;

    @SerializedName("transaction_id")
    private String transaction_id;

    @SerializedName("scroll")
    private String scroll;

    @SerializedName("time")
    private String time;

    @SerializedName("page_size")
    private Integer page_size;

    public Integer getPage_size() {
        return page_size;
    }

    public void setPage_size(Integer page_size) {
        this.page_size = page_size;
    }

    public Integer getPage_number() {
        return page_number;
    }

    public void setPage_number(Integer page_number) {
        this.page_number = page_number;
    }

    @SerializedName("page_number")
    private Integer page_number;



    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getReceiver_id() {
        return receiver_id;
    }

    public void setReceiver_id(String receiver_id) {
        this.receiver_id = receiver_id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getScroll() {
        return scroll;
    }

    public void setScroll(String scroll) {
        this.scroll = scroll;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }



}
