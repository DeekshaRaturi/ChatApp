package com.ripenapps.rehntu.models.map.reguest;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class MapRequest {

        @SerializedName("services_type")
        private String servicesType = "";

        @SerializedName("text")
        private String text = "";

        @SerializedName("lat")
        private String lat = "";

        @SerializedName("long")
        private String lng = "";

        @SerializedName("categoryId")
        private String categoryId = "";


        @SerializedName("page_size")
        private Integer page_size;

        @SerializedName("page_number")
        private Integer page_number;


        @SerializedName("rating")
        private int rating ;

        @SerializedName("user_id")
        private String userId = "";

        @SerializedName("maxPrice")
        private Number maxPrice ;

        @SerializedName("minPrice")
        private Number minPrice ;

        @SerializedName("maxMile")
        private Number maxMile ;

        @SerializedName("minMile")
        private Number minMile ;

        @SerializedName("subcategoryId")
        private ArrayList<String> subcategoryId = new ArrayList<>();

        private String address="";

        public Integer getPage_size() {
                return page_size;
        }

        public void setPage_size(Integer page_size) {
                this.page_size = page_size;
        }

        public Integer getPage_number() {
                return page_number;
        }

        public void setPage_number(Integer page_number) {
                this.page_number = page_number;
        }

        public String getAddress() {
                return address;
        }

        public void setAddress(String address) {
                this.address = address;
        }

        public String getServicesType() {
                return servicesType;
        }

        public void setServicesType(String servicesType) {
                this.servicesType = servicesType;
        }

        public String getText() {
                return text;
        }

        public void setText(String text) {
                this.text = text;
        }

        public String getLat() {
                return lat;
        }

        public void setLat(String lat) {
                this.lat = lat;
        }

        public String getLng() {
                return lng;
        }

        public void setLng(String lng) {
                this.lng = lng;
        }

        public String getCategoryId() {
                return categoryId;
        }

        public void setCategoryId(String categoryId) {
                this.categoryId = categoryId;
        }

        public int getRating() {
                return rating;
        }

        public void setRating(int rating) {
                this.rating = rating;
        }

        public String getUserId() {
                return userId;
        }

        public void setUserId(String userId) {
                this.userId = userId;
        }

        public Number getMaxPrice() {
                return maxPrice;
        }

        public void setMaxPrice(Number maxPrice) {
                this.maxPrice = maxPrice;
        }

        public Number getMinPrice() {
                return minPrice;
        }

        public void setMinPrice(Number minPrice) {
                this.minPrice = minPrice;
        }

        public Number getMaxMile() {
                return maxMile;
        }

        public void setMaxMile(Number maxMile) {
                this.maxMile = maxMile;
        }

        public Number getMinMile() {
                return minMile;
        }

        public void setMinMile(Number minMile) {
                this.minMile = minMile;
        }

        public ArrayList<String> getSubcategoryId() {
                return subcategoryId;
        }

        public void setSubcategoryId(ArrayList<String> subcategoryId) {
                this.subcategoryId = subcategoryId;
        }
}
