package com.ripenapps.rehntu.models.services.respponse;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class ServiceResponse extends BaseResponse {



    @SerializedName("result")
    private ServiceResponseResult result;


    public ServiceResponseResult getResult() {
        return result;
    }

    public void setResult(ServiceResponseResult result) {
        this.result = result;
    }
}
