package com.ripenapps.rehntu.models.getFeedback.response;

import com.google.gson.annotations.SerializedName;

public class UserDetail {

    @SerializedName("profile_img")
   private String profile_img;

    @SerializedName("_id")
    private String  ratinguserId;

    @SerializedName("name")
    private String name;


    public String getProfile_img() {
        return profile_img;
    }

    public void setProfile_img(String profile_img) {
        this.profile_img = profile_img;
    }

    public String getRatinguserId() {
        return ratinguserId;
    }

    public void setRatinguserId(String ratinguserId) {
        this.ratinguserId = ratinguserId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
