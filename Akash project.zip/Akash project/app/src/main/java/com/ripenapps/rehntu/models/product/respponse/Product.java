package com.ripenapps.rehntu.models.product.respponse;


import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Product {

    @SerializedName("address")
    private Address address;

    @SerializedName("subcategoryId")
    private ArrayList<String> subcategories = new ArrayList<>();

    @SerializedName("is_deleted")
    private boolean isDeleted;

    @SerializedName("images")
    private ArrayList<String> images = new ArrayList<>();

    @SerializedName("_id")
    private String _id;

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("name")
    private String name;

    @SerializedName("categoryId")
    private String categoryId;

    @SerializedName("ratePerHour")
    private String ratePerHour="0";


    @SerializedName("yearPurchase")
    private String yearPurchase;


    @SerializedName("securityDeposite")
    private String securityDeposite;


    @SerializedName("description")
    private String description;

    @SerializedName("created_at")
    private String created_at;

    @SerializedName("distance")
    private String distance;

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public ArrayList<String> getSubcategories() {
        return subcategories;
    }

    public void setSubcategories(ArrayList<String> subcategories) {
        this.subcategories = subcategories;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public ArrayList<String> getImages() {
        return images;
    }

    public void setImages(ArrayList<String> images) {
        this.images = images;
    }

    public String getId() {
        return _id;
    }

    public void setId(String _id) {
        this._id = _id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(String ratePerHour) {
        this.ratePerHour = ratePerHour;
    }

    public String getYearPurchase() {
        return yearPurchase;
    }

    public void setYearPurchase(String yearPurchase) {
        this.yearPurchase = yearPurchase;
    }

    public String getSecurityDeposite() {
        return securityDeposite;
    }

    public void setSecurityDeposite(String securityDeposite) {
        this.securityDeposite = securityDeposite;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}

