package com.ripenapps.rehntu.adapter;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.ripenapps.rehntu.R;
import com.ripenapps.rehntu.fragment.UploadImageFragment1Two;
import com.ripenapps.rehntu.my_util.Constants;
import com.ripenapps.rehntu.my_util.RhentoSingleton;
import com.ripenapps.rehntu.my_util.UploadedImage;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ImageListAdapter1 extends RecyclerView.Adapter<ImageListAdapter1.ViewHolder> {

    private UploadImageFragment1Two mContext;
    private List<Bitmap> imageList;
    private List<String> imageList1;
    public ImageListAdapterCallback callback;
    public ImageListAdapterCallback1 callback1;


    public ImageListAdapter1(List<Bitmap> imageList,List<String> imageList1, UploadImageFragment1Two mContext) {
        this.mContext = mContext;
        this.imageList = imageList;
        this.imageList1=imageList1;
        this.callback = (ImageListAdapterCallback) mContext;
        this.callback1 = (ImageListAdapterCallback1) mContext;
    }

    @Override
    public ImageListAdapter1.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ImageListAdapter1.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.imagelist, parent, false));
    }


    @Override
    public void onBindViewHolder(final ImageListAdapter1.ViewHolder holder, final int position) {


        if(position<5) {
            holder.cvImage.setVisibility(View.VISIBLE);
            holder.cancleImage.setVisibility(View.VISIBLE);


            if (position == (imageList.size()+imageList1.size()) - 1) {
                holder.cancleImage.setVisibility(View.INVISIBLE);
                holder.cvImage.setRadius(0);
                holder.cvImage.setTranslationZ(0);
                holder.cvImage.setCardBackgroundColor(Color.TRANSPARENT);
                holder.cvImage.setElevation(0);
                holder.list.getLayoutParams().width = 130;
                holder.list.getLayoutParams().height = 130;
                holder.list.requestLayout();
                Bitmap bitmap = imageList.get((position-imageList1.size()));
                holder.list.setImageBitmap(bitmap);

            } else {
                if(position<imageList1.size()){
                    Picasso.with(mContext.getActivity().getApplicationContext()).load(Constants.IMG_URL + imageList1.get(position)).placeholder(R.drawable.place_holder).into(holder.list);

                }else {

                    Bitmap bitmap = imageList.get(position-imageList1.size());
                    holder.list.setImageBitmap(bitmap);
                }
                holder.list.getLayoutParams().width = RecyclerView.LayoutParams.MATCH_PARENT;
                holder.list.getLayoutParams().height = RecyclerView.LayoutParams.MATCH_PARENT;
                holder.cvImage.setCardBackgroundColor(Color.WHITE);
                holder.cancleImage.setVisibility(View.VISIBLE);
                holder.list.requestLayout();
                holder.cvImage.setRadius(15);
                holder.cvImage.setTranslationZ(2);
                holder.cvImage.setElevation(2);
            }
        }else{

            holder.cvImage.setVisibility(View.GONE);
            holder.cancleImage.setVisibility(View.GONE);

        }

        holder.cancleImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(position<imageList1.size()){
                    ArrayList<String> list1=RhentoSingleton.getInstance().getImageurl();
                    callback1.onItemClick(position,list1.get(position));
                    list1.remove(position);
                    RhentoSingleton.getInstance().setImageurl(list1);
                    imageList1.remove(position);
                    notifyDataSetChanged();

                }else{
                    List<UploadedImage> list = RhentoSingleton.getInstance().getUploadedImages();
                    list.remove(position-imageList1.size());
                    RhentoSingleton.getInstance().setUploadedImages(list);
                    imageList.remove(position-imageList1.size());
                    notifyDataSetChanged();
                    callback1.onItemClick(position,"-1");
                }


            }
        });

        holder.list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position == (imageList.size()+imageList1.size()) - 1) {
                    callback.onItemClick(position);
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return (imageList.size()+imageList1.size());
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView list, cancleImage;
        private CardView cvImage;


        ViewHolder(View itemView) {
            super(itemView);
            cvImage = (CardView) itemView.findViewById(R.id.cv_image);
            list = (ImageView) itemView.findViewById(R.id.uploaded_image_imageview);
            cancleImage = (ImageView) itemView.findViewById(R.id.iv_remove_image);
        }


    }

    public interface ImageListAdapterCallback {
        void onItemClick(int pos);
    }

    public interface ImageListAdapterCallback1 {
        void onItemClick(int pos,String pos1);
    }
}

