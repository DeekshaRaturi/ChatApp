package com.ripenapps.rehntu.models.bookNow.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Booking {

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @com.google.gson.annotations.SerializedName("address")
    @Expose
    Address address = new Address();

    public Double getPaid_amount() {
        return paid_amount;
    }

    public void setPaid_amount(Double paid_amount) {
        this.paid_amount = paid_amount;
    }

    @SerializedName("paid_amount")
    private Double paid_amount;



    @SerializedName("service_name")
    private String service_name;

    @SerializedName("service_provider_name")
    private String service_provider_name;

    @SerializedName("price")
    private int price;

    @SerializedName("from")
    private String from;

    @SerializedName("time")
    private String time;

    @SerializedName("to")
    private String to;

    public Double getRent() {
        return rent;
    }

    public void setRent(Double rent) {
        this.rent = rent;
    }

    @SerializedName("rent")
    private Double rent;


    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }


    @SerializedName("security_deposite")
    private String security_deposit;

    public String getSecurity_deposit() {
        return security_deposit;
    }

    public void setSecurity_deposit(String security_deposit) {
        this.security_deposit = security_deposit;
    }



    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    @SerializedName("service_type")
    private String service_type;

    public String getService_provider_name() {
        return service_provider_name;
    }

    public void setService_provider_name(String service_provider_name) {
        this.service_provider_name = service_provider_name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }




}
