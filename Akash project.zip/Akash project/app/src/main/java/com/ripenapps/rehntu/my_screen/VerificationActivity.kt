package com.ripenapps.rehntu.my_screen

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.support.v4.content.LocalBroadcastManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

import com.facebook.login.LoginManager
import com.goodiebag.pinview.Pinview
import com.google.gson.Gson
import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.models.VerifieMobile.REQUEST.VerifiesMobileRequest
import com.ripenapps.rehntu.models.VerifieMobile.RESPONSE.VerifieMobileResponseWrapper
import com.ripenapps.rehntu.models.login.request.LoginRequest
import com.ripenapps.rehntu.models.login.response.LoginResponseWrapper
import com.ripenapps.rehntu.models.notification.request.NotificationRequest
import com.ripenapps.rehntu.models.notification.response.NotificationWrapper
import com.ripenapps.rehntu.models.registration.request.SignUpRequest
import com.ripenapps.rehntu.models.registration.respponse.SignUpResponseWrapper
import com.ripenapps.rehntu.my_util.CommonUtils
import com.ripenapps.rehntu.my_util.RhentoSingleton
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences
import com.ripenapps.rehntu.volley.APIUtility

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class VerificationActivity : BaseActivity(), View.OnClickListener {
    private var pinview: Pinview? = null
    private var mobile_num: String? = null
    private var email: String? = null
    private var county_code: String? = null
    private var name: String? = null
    private var pass: String? = null
    private var loginType: String? = null
    private var btn_submit: Button? = null
    private var apiUtility: APIUtility? = null
    private var resend: TextView? = null
    private var back: ImageView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)
        apiUtility = APIUtility(this)
        initViews()

        if (intent != null && intent.hasExtra("comeFrom")) {
            email = intent.getStringExtra("email")
            name = intent.getStringExtra("name")
            pass = intent.getStringExtra("pass")
            mobile_num = intent.getStringExtra("mobile")
            county_code = intent.getStringExtra("county_code")
        }


        if (intent != null && intent.hasExtra("comefrom")) {
            email = intent.getStringExtra("email")
            name = intent.getStringExtra("name")
            mobile_num = intent.getStringExtra("mobile")
            county_code = intent.getStringExtra("county_code")
            if (intent.getStringExtra("loginType") != null);
            loginType = intent.getStringExtra("loginType")
        }

    }

    private fun initViews() {
        pinview = findViewById<View>(R.id.pinview) as Pinview
        btn_submit = findViewById<View>(R.id.btn_submit) as Button
        resend = findViewById<View>(R.id.resend) as TextView
        back = findViewById<View>(R.id.back) as ImageView
        back!!.setOnClickListener(this)
        resend!!.setOnClickListener(this)
        btn_submit!!.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.back -> finish()

            R.id.resend -> showDialog()

            R.id.btn_submit -> validation()
        }
    }


    internal fun validation() {
        if (pinview!!.value == "" || pinview!!.value == null || pinview!!.value.isEmpty()) {
            CommonUtils.alert(this@VerificationActivity, "Please enter a valid verification code ")
        }
        else {
            if (pinview!!.value == "1234") {

                //getNotification()

                if (intent != null && intent.hasExtra("activity")) {
                    verification(Preferences.getPreference(applicationContext, PrefEntity.USERID), Preferences.getPreference(applicationContext, PrefEntity.COUNTRYCODE), Preferences.getPreference(applicationContext, PrefEntity.PHONE_NUMBER))
                } else if (intent != null && intent.hasExtra("comeFrom1")) {
                    verification(Preferences.getPreference(applicationContext, PrefEntity.USERID), intent.getStringExtra("county_code"), Preferences.getPreference(applicationContext, PrefEntity.PHONE_NUMBER))
                } else if (intent != null && intent.hasExtra("comefrom")) {
                    LoginAttempt(loginType, name, email, "", mobile_num, county_code, RhentoSingleton.getInstance().social_id)
                }
                else if (intent!=null && intent.hasExtra("verification")){


                }
                else {
                    signUp(name, email, mobile_num, county_code, pass)

                }
            } else {
                CommonUtils.alert(this@VerificationActivity, "Please enter a valid verification code ")
            }
        }
    }
    private fun getNotification() {

        val request = NotificationRequest()
        request.device_token = Preferences.getPreference(applicationContext, "token")
        request.user_id = Preferences.getPreference(applicationContext, PrefEntity.USERID)
        request.device_type = "Android"
        val gson = Gson()
        Log.e("notifyreq", gson.toJson(request))



        apiUtility?.showNotification(this, request, true, object : APIUtility.APIResponseListener<NotificationWrapper> {
            override fun onReceiveResponse(response: NotificationWrapper?) {
                if (response != null) {

                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@VerificationActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: NotificationWrapper) {
                CommonUtils.alert(this@VerificationActivity, response.response.message)
            }
        })


    }

    private fun signUp(name: String?, email: String?, phone: String?, county_code: String?, pass: String?) {

        val request = SignUpRequest()
        request.country_code = county_code
        request.email = email
        request.name = name
        request.password = pass
        request.phone = phone

        apiUtility!!.signUp(this@VerificationActivity, request, true, object : APIUtility.APIResponseListener<SignUpResponseWrapper> {
            override fun onReceiveResponse(response: SignUpResponseWrapper?) {
                if (response != null) {
                    setUserDetails(response.response.result.email, response.response.result.mobile_no, response.response.result.name, response.response.result._id, response.response.result.isIs_verified, response.response.result.doc_Verify, response.response.result.country_code)

                    verification(response.response.result._id, response.response.result.country_code, response.response.result.mobile_no)
                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@VerificationActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: SignUpResponseWrapper) {
                CommonUtils.alert(this@VerificationActivity, response.response.message)
            }
        })
    }


    internal fun verification(id: String, county_code: String, mobile_num: String) {
        val verifiesMobileRequest = VerifiesMobileRequest()
        verifiesMobileRequest.country_code = county_code
        verifiesMobileRequest.user_id = id
        verifiesMobileRequest.mobile_no = mobile_num

        apiUtility!!.verifyNumber(this@VerificationActivity, verifiesMobileRequest, true, object : APIUtility.APIResponseListener<VerifieMobileResponseWrapper> {
            override fun onReceiveResponse(response: VerifieMobileResponseWrapper?) {
                if (response != null) {

                    if (intent.hasExtra("comeFrom1")) {
                        val intent = Intent("startUpload")
                        LocalBroadcastManager.getInstance(this@VerificationActivity).sendBroadcast(intent)
                        finish()

                    } else {
                        Preferences.setPreference(applicationContext, PrefEntity.IS_PHONE_VERIFIED, true)
                        val intent = Intent(this@VerificationActivity, GetCurrentLocationActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                    }


                }
            }

            override fun onResponseFailed() {
                CommonUtils.alert(this@VerificationActivity, getString(R.string.VolleyError))
            }

            override fun onStatusFalse(response: VerifieMobileResponseWrapper) {
                CommonUtils.alert(this@VerificationActivity, response.response.message)

            }
        })

    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }


    internal fun LoginAttempt(loginType: String?, name: String?, email: String?, password: String, mobile: String?, county_code: String?, socialid: String) {

        val request = LoginRequest()
        request.email = email
        request.mobile = mobile
        request.loginType = loginType
        request.name = name
        request.password = password
        request.country_code = county_code
        request.socialID = socialid
        apiUtility!!.userLogin(this@VerificationActivity, request, true, object : APIUtility.APIResponseListener<LoginResponseWrapper> {
            override fun onReceiveResponse(response: LoginResponseWrapper?) {
                if (response != null) {
                    setUserDetails(response.response.result.email, response.response.result.mobile, response.response.result.name, response.response.result.id, response.response.result.isVerified, response.response.result.doc_Verify, response.response.result.country_code)

                    if (!response.response.result.isVerified) {
                        verification(response.response.result.id, response.response.result.country_code, response.response.result.mobile)
                    } else {
                        val intent = Intent(this@VerificationActivity, GetCurrentLocationActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                    }
                }
            }

            override fun onResponseFailed() {
                LoginManager.getInstance().logOut()
                CommonUtils.alert(this@VerificationActivity, getString(R.string.VolleyError))

            }

            override fun onStatusFalse(response: LoginResponseWrapper) {

                when (response.response.status) {
                    0 -> CommonUtils.alert(this@VerificationActivity, response.response.message)
                }

            }
        })


    }

    internal fun showDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage("Do you want to resend the OTP?")
        builder.setPositiveButton("yes") { dialog, which -> dialog.dismiss() }.setNegativeButton("no") { dialog, which -> dialog.dismiss() }
        builder.setCancelable(false)
        builder.create()
        builder.show()

    }

}