package com.ripenapps.rehntu.models.notification.request;

import com.google.gson.annotations.SerializedName;

public class NotificationRequest {

    @SerializedName("user_id")
    String user_id;

    @SerializedName("device_type")
    String device_type;

    @SerializedName("device_token")
    String device_token;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDevice_type() {
        return device_type;
    }

    public void setDevice_type(String device_type) {
        this.device_type = device_type;
    }

    public String getDevice_token() {
        return device_token;
    }

    public void setDevice_token(String device_token) {
        this.device_token = device_token;
    }


}
