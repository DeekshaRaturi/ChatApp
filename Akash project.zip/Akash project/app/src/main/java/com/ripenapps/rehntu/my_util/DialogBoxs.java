package com.ripenapps.rehntu.my_util;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import com.ripenapps.rehntu.R;


/**
 * TODO: Add a class header comment!
 */
public class DialogBoxs {

    private Context context;
    private ProgressDialog prgDialog;

    public DialogBoxs(Context context) {
        this.context = context;
    }


    public void showProgressBarDialog(){
        // setting progress_bar bar dialog
        prgDialog = new ProgressDialog(context);
        try {
            prgDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        prgDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.MAGENTA));
        prgDialog.setContentView(R.layout.progress_bar);
        prgDialog.setCancelable(false);
    }

    public void hideProgressBar(){
        if(prgDialog != null){
            prgDialog.hide();
        }
    }



}
