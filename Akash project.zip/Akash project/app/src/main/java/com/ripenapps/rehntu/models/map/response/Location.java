package com.ripenapps.rehntu.models.map.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Location {
    @SerializedName("type")
    private String type = "";

    @SerializedName("coordinates")
    private ArrayList<String> coordinateArrayList = new ArrayList<>();

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ArrayList<String> getCoordinateArrayList() {
        return coordinateArrayList;
    }

    public void setCoordinateArrayList(ArrayList<String> coordinateArrayList) {
        this.coordinateArrayList = coordinateArrayList;
    }
}

