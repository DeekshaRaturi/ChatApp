package com.ripenapps.rehntu.models.paymentSession.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.notification.response.NotificationResponse;

public class PaymentWrapper {

    public PaymentResponse getResponse() {
        return response;
    }

    public void setResponse(PaymentResponse response)
    {
        this.response = response;
    }

    @SerializedName("data")
    private PaymentResponse response;
}
