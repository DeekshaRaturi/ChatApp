package com.ripenapps.rehntu.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.ripenapps.rehntu.fragment.AllFragment;
import com.ripenapps.rehntu.fragment.EarnFragment;
import com.ripenapps.rehntu.fragment.SpendFragment;

import java.util.ArrayList;
import java.util.List;

public class ViewPagerAdapter extends FragmentPagerAdapter {

    private final List<Fragment> mFragmentList = new ArrayList<>();
    private final List<String> mFragmentTitleList = new ArrayList<>();


    public ViewPagerAdapter(FragmentManager manager) {
        super(manager);
    }



    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                return new AllFragment();
            case 1:
                return new SpendFragment();
            case 2:
                return new EarnFragment();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
       // return title.length;
       // return mFragmentList.size();
        return 3;

    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "All";
            case 1:
                return "Spent";
            case 2:
                return "Earn";
        }
        return null;
    }
}
