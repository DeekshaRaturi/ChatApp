package com.ripenapps.rehntu.models.registration.respponse;

import com.google.gson.annotations.SerializedName;

public class SignUpResponseWrapper {

    @SerializedName("data")
    SignUpResponse response;

    public SignUpResponse getResponse() {
        return response;
    }

    public void setResponse(SignUpResponse response) {
        this.response = response;
    }
}
