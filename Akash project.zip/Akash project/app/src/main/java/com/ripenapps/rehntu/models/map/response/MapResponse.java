package com.ripenapps.rehntu.models.map.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class MapResponse extends BaseResponse{

    @SerializedName("result")

    private MapResponseResult result;

    public MapResponseResult getResult() {
        return result;
    }

    public void setResult(MapResponseResult result) {
        this.result = result;
    }
}
