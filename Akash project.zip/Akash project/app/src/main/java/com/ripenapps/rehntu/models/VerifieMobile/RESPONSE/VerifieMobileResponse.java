package com.ripenapps.rehntu.models.VerifieMobile.RESPONSE;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class VerifieMobileResponse extends BaseResponse {
    @SerializedName("result")
    VerifieMobileResult result;

    public VerifieMobileResult getResult() {
        return result;
    }

    public void setResult(VerifieMobileResult result) {
        this.result = result;
    }
}
