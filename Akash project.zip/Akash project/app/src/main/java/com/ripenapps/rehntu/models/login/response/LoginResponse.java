package com.ripenapps.rehntu.models.login.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class LoginResponse  extends BaseResponse{

    @SerializedName("result")

    private LoginResponseResult result;

    public LoginResponseResult getResult() {
        return result;
    }

    public void setResult(LoginResponseResult result) {
        this.result = result;
    }
}
