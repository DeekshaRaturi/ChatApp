package com.ripenapps.rehntu.models.bookNow.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class BookNowResponse extends BaseResponse {

    @SerializedName("result")
    private BookNowResult getBooknowresult;

    public BookNowResult getGetBooknowresult() {
        return getBooknowresult;
    }

    public void setGetBooknowresult(BookNowResult getBooknowresult) {
        this.getBooknowresult = getBooknowresult;
    }



}
