package com.ripenapps.rehntu.models.checkRegistration.response;

import com.google.gson.annotations.SerializedName;
import com.ripenapps.rehntu.models.BaseResponse;

public class CheckRegistrationRes  extends BaseResponse{


    @SerializedName("result")
    private CheckRegistrationResult result;


    public CheckRegistrationResult getResult() {
        return result;
    }

    public void setResult(CheckRegistrationResult result) {
        this.result = result;
    }
}
