package com.ripenapps.rehntu.models.product.respponse;

import com.google.gson.annotations.SerializedName;

public class ProductResponseWrapper {

    @SerializedName("data")
    ProductResponse response;

    public ProductResponse getResponse() {
        return response;
    }

    public void setResponse(ProductResponse response) {
        this.response = response;
    }
}
