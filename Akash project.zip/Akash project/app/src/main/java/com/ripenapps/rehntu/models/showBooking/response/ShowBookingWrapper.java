package com.ripenapps.rehntu.models.showBooking.response;

import com.google.gson.annotations.SerializedName;

public class ShowBookingWrapper {

    @SerializedName("data")
    private ShowBookingResponse response;

    public ShowBookingResponse getResponse() {
        return response;
    }

    public void setResponse(ShowBookingResponse response) {
        this.response = response;
    }

   ;


}
