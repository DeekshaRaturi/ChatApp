package com.ripenapps.rehntu.models.paymentSession.request;

import com.google.gson.annotations.SerializedName;

public class amount {

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @SerializedName("currency")
    String currency;

    @SerializedName("value")
    Double value;

}
