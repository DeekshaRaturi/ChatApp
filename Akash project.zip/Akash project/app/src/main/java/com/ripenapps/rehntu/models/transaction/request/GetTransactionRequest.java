package com.ripenapps.rehntu.models.transaction.request;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

public class GetTransactionRequest {

    @SerializedName("user_id")
    private String user_id;

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    @SerializedName("service_type")
    private String service_type;

    @SerializedName("from")
    private String from;

    @SerializedName("customer")
    private String customer;

    @SerializedName("to")
    private String to;


    public JsonArray getStatus() {
        return status;
    }

    public void setStatus(JsonArray status) {
        this.status = status;
    }

    @SerializedName("status")
    private JsonArray status;














    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }


}
