package com.ripenapps.rehntu.models.services.respponse;

import com.google.gson.annotations.SerializedName;

public class ServiceResponseWrapper {

    @SerializedName("data")
    ServiceResponse response;

    public ServiceResponse getResponse() {
        return response;
    }

    public void setResponse(ServiceResponse response) {
        this.response = response;
    }
}
