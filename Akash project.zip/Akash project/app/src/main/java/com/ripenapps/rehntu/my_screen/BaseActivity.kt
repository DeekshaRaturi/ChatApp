package com.ripenapps.rehntu.my_screen

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity

import android.view.inputmethod.InputMethodManager

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.preferences.PrefEntity
import com.ripenapps.rehntu.preferences.Preferences


open class BaseActivity : AppCompatActivity() {
    private var dialog: ProgressDialog? = null

    var fragManager: android.support.v4.app.FragmentManager?=null
    var fragTransaction: FragmentTransaction?=null
    var mLastClickTime: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = this@BaseActivity

        fragManager = supportFragmentManager
        fragTransaction = fragManager?.beginTransaction()

    }

    override fun onPause() {
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        //Toast.makeText(getApplicationContext(),"onresume",Toast.LENGTH_SHORT).show();
    }

    fun showProgressDialog() {
        dialog = ProgressDialog(this@BaseActivity)
        //        dialog.setMessage(getString(R.string.));
        dialog!!.setCancelable(false)
        dialog!!.show()
    }

    fun showProgressDialog(Message: String) {
        dialog = ProgressDialog(this@BaseActivity)
        dialog!!.setMessage(Message)
        dialog!!.setCancelable(false)
        dialog!!.show()
    }

    //This function is cancel progress dialog
    fun cancelProgressDialog() {
        dialog!!.dismiss()
    }

    // Avoid Multiple click
    fun issingleClick(): Boolean {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
            return false
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        return true
    }

    fun hideKeyboard() {

        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            if (imm.isAcceptingText) {
                imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
            }
        } catch (e: Exception) {

        }

    }

    fun callAlertDialog(message: Int, context: Context) {
        val builder = AlertDialog.Builder(context)
        builder.setMessage(message)
                .setTitle(resources.getString(R.string.app_name))
                .setCancelable(false)
                .setPositiveButton("ok") { dialog, id -> dialog.dismiss() }

        val alert = builder.create()
        alert.show()
    }

    fun callAlertDialog(message: String, context: Context) {
        val builder = AlertDialog.Builder(context)
        builder.setMessage(message)
                .setTitle(resources.getString(R.string.app_name))
                .setCancelable(false)

        val alert = builder.create()
        alert.show()
    }


    fun setUserDetails(email: String, phone: String, name: String, userID: String, is_Phone_Verified: Boolean, docVerified: String, CountryCode: String) {
        Preferences.setPreference(applicationContext, PrefEntity.USER_EMAIL, email)
        Preferences.setPreference(applicationContext, PrefEntity.USER_NAME, name)
        Preferences.setPreference(applicationContext, PrefEntity.PHONE_NUMBER, phone)
        Preferences.setPreference(applicationContext, PrefEntity.USERID, userID)
        Preferences.setPreference(applicationContext, PrefEntity.IS_PHONE_VERIFIED, is_Phone_Verified)
        Preferences.setPreference(applicationContext, PrefEntity.DOCVERIFY, docVerified)
        Preferences.setPreference(applicationContext, PrefEntity.COUNTRYCODE, CountryCode)
        Preferences.setPreference_int(applicationContext, PrefEntity.IS_LOGIN, 1)


    }

    fun clearUserDetails() {
        Preferences.removePreference(applicationContext, PrefEntity.ISFILTER)
        Preferences.removePreference(applicationContext, PrefEntity.USER_EMAIL)
        Preferences.removePreference(applicationContext, PrefEntity.USER_NAME)
        Preferences.removePreference(applicationContext, PrefEntity.PHONE_NUMBER)
        Preferences.removePreference(applicationContext, PrefEntity.USERID)
        Preferences.removePreference(applicationContext, PrefEntity.IS_LOGIN)
        Preferences.removePreference(applicationContext, PrefEntity.COUNTRYCODE)
        Preferences.removePreference(applicationContext, PrefEntity.IS_PHONE_VERIFIED)
        Preferences.removePreference(applicationContext, PrefEntity.DOCVERIFY)
        Preferences.removePreference(applicationContext, PrefEntity.COMEFROM)
        Preferences.removePreference(applicationContext, PrefEntity.TYPE)
        Preferences.removePreference(applicationContext, PrefEntity.LAT)
        Preferences.removePreference(applicationContext, PrefEntity.LONG)
        Preferences.removePreference(applicationContext, PrefEntity.CATEGORYID)
        Preferences.removePreference(applicationContext, PrefEntity.CATEGORY)
        Preferences.removePreference(applicationContext, PrefEntity.LAT1)
        Preferences.removePreference(applicationContext, PrefEntity.LONG1)
        Preferences.removePreference(applicationContext, PrefEntity.COMEFROM1)


    }

    companion object {

        var mContext: Context?=null
    }


}
