package com.ripenapps.rehntu.my_screen

import android.content.Context
import android.os.Bundle
import android.support.v7.widget.AppCompatTextView
import android.view.View
import android.widget.ImageView

import com.ripenapps.rehntu.R
import com.ripenapps.rehntu.fragment.UploadImageFragmentOne

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper

class UploadImageActivity : BaseActivity(), View.OnClickListener {
    private var title: AppCompatTextView? = null
    private var back: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_uplaod_image)
        initViews()

    }

    private fun initViews() {
        back = findViewById<View>(R.id.back) as ImageView
        title = findViewById<View>(R.id.title) as AppCompatTextView
        title!!.text = "Upload Image"
        back!!.setOnClickListener(this)
        val fragment = UploadImageFragmentOne()
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.container, fragment)
        fragmentTransaction.commit()

    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase))
    }

    override fun onClick(v: View) {
        finish()
    }
}
