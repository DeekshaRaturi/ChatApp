package com.ripenapps.rehntu.models.bankDetails.response;

import com.google.gson.annotations.Expose;

public class BankDetailResult {

    public AccountDetails getDetails() {
        return details;
    }

    public void setDetails(AccountDetails details) {
        this.details = details;
    }

    @com.google.gson.annotations.SerializedName("account_details")
    @Expose

    AccountDetails details=new AccountDetails();

}
